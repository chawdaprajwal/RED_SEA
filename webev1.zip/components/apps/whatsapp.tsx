"use client"

import { useState, useRef, useEffect } from "react"
import { Send, Search, MoreVertical, Plus, Phone, Video } from "lucide-react"
import { PhishingMessageInteractive } from "@/components/whatsapp-trainer/phishing-message-interactive"
import { PhishingScenarioVerification } from "@/components/whatsapp-trainer/phishing-scenario-verification"
import { PhishingScenarioGiftcard } from "@/components/whatsapp-trainer/phishing-scenario-giftcard"

interface Chat {
  id: string
  name: string
  avatar: string
  lastMessage: string
  timestamp: string
  unread: number
  isPhishing?: boolean
  scenarioType?: string
}

interface Message {
  id: string
  chatId: string
  sender: "user" | "other"
  text: string
  timestamp: string
  isPhishing?: boolean
}

export default function WhatsApp() {
  const [chats, setChats] = useState<Chat[]>([
    {
      id: "phishing-1",
      name: "+91 98765 43210",
      avatar: "👨",
      lastMessage: "Mom/Dad, my phone fell in water...",
      timestamp: "now",
      unread: 1,
      isPhishing: true,
      scenarioType: "emergency",
    },
    {
      id: "phishing-2",
      name: "+91 87654 32109",
      avatar: "👩",
      lastMessage: "Hi! Can you help me? I'm trying to login...",
      timestamp: "2 min",
      unread: 1,
      isPhishing: true,
      scenarioType: "verification",
    },
    {
      id: "phishing-3",
      name: "+91 76543 21098",
      avatar: "👨‍💼",
      lastMessage: "🎉 CONGRATULATIONS! You won...",
      timestamp: "5 min",
      unread: 1,
      isPhishing: true,
      scenarioType: "giftcard",
    },
    {
      id: "1",
      name: "Sarah Johnson",
      avatar: "👩‍💼",
      lastMessage: "That sounds great! See you tomorrow",
      timestamp: "2:30 PM",
      unread: 0,
    },
    {
      id: "2",
      name: "Alex Chen",
      avatar: "👨‍💻",
      lastMessage: "Let's catch up soon",
      timestamp: "1:15 PM",
      unread: 0,
    },
    {
      id: "3",
      name: "Emma Wilson",
      avatar: "👩‍🎨",
      lastMessage: "The project looks amazing!",
      timestamp: "11:45 AM",
      unread: 0,
    },
  ])

  const [messages, setMessages] = useState<Message[]>([
    { id: "1", chatId: "1", sender: "other", text: "Hey! How are you?", timestamp: "2:15 PM" },
    { id: "2", chatId: "1", sender: "user", text: "I'm doing great! How about you?", timestamp: "2:18 PM" },
    { id: "3", chatId: "1", sender: "other", text: "Really good! Want to grab coffee?", timestamp: "2:25 PM" },
    { id: "4", chatId: "1", sender: "user", text: "When?", timestamp: "2:28 PM" },
    { id: "5", chatId: "1", sender: "other", text: "That sounds great! See you tomorrow", timestamp: "2:30 PM" },
    { id: "6", chatId: "2", sender: "other", text: "Did you see the new design?", timestamp: "1:10 PM" },
    { id: "7", chatId: "2", sender: "user", text: "Not yet, I'll check it out", timestamp: "1:12 PM" },
    { id: "8", chatId: "2", sender: "other", text: "Let's catch up soon", timestamp: "1:15 PM" },
    { id: "9", chatId: "3", sender: "user", text: "I finished the artwork!", timestamp: "11:40 AM" },
    { id: "10", chatId: "3", sender: "other", text: "The project looks amazing!", timestamp: "11:45 AM" },
  ])

  const [selectedChatId, setSelectedChatId] = useState<string>("phishing-1")
  const [messageInput, setMessageInput] = useState("")
  const [searchQuery, setSearchQuery] = useState("")
  const messagesEndRef = useRef<HTMLDivElement>(null)

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }

  useEffect(() => {
    scrollToBottom()
  }, [messages, selectedChatId])

  const handleSendMessage = () => {
    if (messageInput.trim()) {
      const newMessage: Message = {
        id: Date.now().toString(),
        chatId: selectedChatId,
        sender: "user",
        text: messageInput,
        timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
      }
      setMessages([...messages, newMessage])
      setMessageInput("")

      if (selectedChatId !== "phishing-1" && selectedChatId !== "phishing-2" && selectedChatId !== "phishing-3") {
        // Simulate reply for normal chats
        setTimeout(() => {
          const replyMessage: Message = {
            id: (Date.now() + 1).toString(),
            chatId: selectedChatId,
            sender: "other",
            text: "Thanks for the message! 😊",
            timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
          }
          setMessages((prev) => [...prev, replyMessage])
        }, 1500)
      }
    }
  }

  const selectedChat = chats.find((c) => c.id === selectedChatId)
  const chatMessages = messages.filter((m) => m.chatId === selectedChatId)
  const filteredChats = chats.filter((c) => c.name.toLowerCase().includes(searchQuery.toLowerCase()))

  const renderPhishingContent = () => {
    if (selectedChat?.scenarioType === "verification") {
      return <PhishingScenarioVerification onChoice={() => {}} />
    } else if (selectedChat?.scenarioType === "giftcard") {
      return <PhishingScenarioGiftcard onChoice={() => {}} />
    } else {
      return <PhishingMessageInteractive onChoice={() => {}} />
    }
  }

  return (
    <div className="flex h-full w-full bg-white">
      {/* Left Sidebar */}
      <div className="w-80 border-r border-gray-200 flex flex-col bg-white">
        {/* Header */}
        <div className="p-4 border-b border-gray-200">
          <div className="flex items-center justify-between mb-4">
            <h1 className="text-2xl font-bold text-gray-900">Chats</h1>
            <div className="flex gap-1">
              <button className="p-2 hover:bg-gray-100 rounded-full transition-colors">
                <Plus size={20} className="text-gray-600" />
              </button>
              <button className="p-2 hover:bg-gray-100 rounded-full transition-colors">
                <MoreVertical size={20} className="text-gray-600" />
              </button>
            </div>
          </div>

          {/* Search Bar */}
          <div className="relative">
            <Search size={16} className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
            <input
              type="text"
              placeholder="Search or start new chat"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-9 pr-4 py-2 bg-gray-100 border border-gray-200 rounded-full text-sm focus:outline-none focus:ring-2 focus:ring-green-500 text-gray-900"
            />
          </div>
        </div>

        {/* Chat List */}
        <div className="flex-1 overflow-y-auto scroll-smooth">
          {filteredChats.map((chat) => (
            <button
              key={chat.id}
              onClick={() => setSelectedChatId(chat.id)}
              className={`w-full p-3 px-6 flex items-center gap-3 transition-colors hover:bg-gray-50 border-b border-gray-100 ${
                selectedChatId === chat.id ? "bg-gray-100" : ""
              }`}
            >
              <div className={`text-3xl flex-shrink-0 ${chat.isPhishing ? "animate-pulse" : ""}`}>{chat.avatar}</div>
              <div className="flex-1 min-w-0 text-left">
                <div className="flex justify-between items-start gap-2">
                  <p className="font-medium text-sm text-gray-900 truncate">{chat.name}</p>
                  <span className="text-xs text-gray-500 flex-shrink-0">{chat.timestamp}</span>
                </div>
                <p className={`text-xs truncate ${chat.isPhishing ? "text-red-600 font-medium" : "text-gray-600"}`}>
                  {chat.lastMessage}
                </p>
              </div>
              {chat.unread > 0 && (
                <div className="w-5 h-5 rounded-full bg-green-500 text-white text-xs flex items-center justify-center font-semibold flex-shrink-0">
                  {chat.unread}
                </div>
              )}
            </button>
          ))}
        </div>
      </div>

      {/* Chat View */}
      <div className="flex-1 flex flex-col bg-white">
        {selectedChat ? (
          <>
            {/* Chat Header */}
            <div className="h-14 border-b border-gray-200 px-6 flex items-center justify-between bg-white">
              <div className="flex items-center gap-3">
                <div className={`text-3xl ${selectedChat.isPhishing ? "animate-pulse" : ""}`}>
                  {selectedChat.avatar}
                </div>
                <div>
                  <p className="font-semibold text-sm text-gray-900">{selectedChat.name}</p>
                  <p className="text-xs text-gray-500">{selectedChat.isPhishing ? "⚠️ Unknown Number" : "Active now"}</p>
                </div>
              </div>
              <div className="flex items-center gap-1">
                <button className="p-2 hover:bg-gray-100 rounded-full transition-colors">
                  <Phone size={18} className="text-green-600" />
                </button>
                <button className="p-2 hover:bg-gray-100 rounded-full transition-colors">
                  <Video size={18} className="text-green-600" />
                </button>
                <button className="p-2 hover:bg-gray-100 rounded-full transition-colors">
                  <MoreVertical size={18} className="text-gray-600" />
                </button>
              </div>
            </div>

            {/* Messages Area */}
            <div className="flex-1 overflow-y-auto scroll-smooth p-4 space-y-4 bg-white">
              {selectedChat.isPhishing
                ? renderPhishingContent()
                : chatMessages.map((msg) => (
                    <div key={msg.id} className={`flex ${msg.sender === "user" ? "justify-end" : "justify-start"}`}>
                      <div
                        className={`max-w-xs px-4 py-2 rounded-2xl ${
                          msg.sender === "user"
                            ? "bg-green-500 text-white rounded-br-none"
                            : "bg-gray-200 text-gray-900 rounded-bl-none"
                        }`}
                      >
                        <p className="text-sm break-words">{msg.text}</p>
                        <p className={`text-xs mt-1 ${msg.sender === "user" ? "text-green-100" : "text-gray-600"}`}>
                          {msg.timestamp}
                        </p>
                      </div>
                    </div>
                  ))}
              <div ref={messagesEndRef} />
            </div>

            {/* Message Input */}
            {!selectedChat.isPhishing && (
              <div className="h-16 border-t border-gray-200 px-4 py-3 bg-white flex items-center gap-3">
                <button className="p-2 hover:bg-gray-100 rounded-full transition-colors flex-shrink-0">
                  <Plus size={20} className="text-green-600" />
                </button>
                <input
                  type="text"
                  placeholder="Type a message..."
                  value={messageInput}
                  onChange={(e) => setMessageInput(e.target.value)}
                  onKeyPress={(e) => e.key === "Enter" && handleSendMessage()}
                  className="flex-1 px-4 py-2 border border-gray-300 rounded-full bg-white text-sm focus:outline-none focus:ring-2 focus:ring-green-500 text-gray-900"
                />
                <button
                  onClick={handleSendMessage}
                  disabled={!messageInput.trim()}
                  className="p-2 hover:bg-gray-100 rounded-full transition-colors disabled:opacity-50 flex-shrink-0"
                >
                  <Send size={20} className="text-green-600" />
                </button>
              </div>
            )}
          </>
        ) : (
          <div className="flex items-center justify-center h-full text-gray-500">
            <p>Select a chat to start messaging</p>
          </div>
        )}
      </div>
    </div>
  )
}
