export default function TelegramLogo() {
  return <img src="/telegram-logo.webp" alt="Telegram" className="w-full h-full object-contain" />
}
