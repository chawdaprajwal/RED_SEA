export default function LinkedInLogo() {
  return <img src="/linkedin-logo.png" alt="LinkedIn" className="w-full h-full object-contain" />
}
