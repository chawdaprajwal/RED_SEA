export default function FacebookLogo() {
  return <img src="/facebook-logo.png" alt="Facebook" className="w-full h-full object-contain" />
}
