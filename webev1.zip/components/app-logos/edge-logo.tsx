export default function EdgeLogo() {
  return <img src="/edge-logo.jfif" alt="Edge" className="w-full h-full object-contain" />
}
