export default function ChromeLogo() {
  return <img src="/chrome-logo.jpg" alt="Chrome" className="w-10 h-10 object-contain" />
}
