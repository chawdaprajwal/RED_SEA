export default function WhatsAppLogo() {
  return <img src="/whatsapp-logo.png" alt="WhatsApp" className="w-full h-full object-contain" />
}
