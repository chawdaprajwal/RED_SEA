export default function TwitterLogo() {
  return <img src="/twitter-logo.png" alt="X (Twitter)" className="w-10 h-10 object-contain" />
}
