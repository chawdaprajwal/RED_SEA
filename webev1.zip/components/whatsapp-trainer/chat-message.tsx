import { CheckCircle2, XCircle } from "lucide-react"

interface ChatMessageProps {
  role: "user" | "contact"
  content: string
  timestamp: string
  isCorrect?: boolean
  showFeedback?: boolean
}

export function ChatMessage({ role, content, timestamp, isCorrect, showFeedback }: ChatMessageProps) {
  return (
    <div className={`flex ${role === "user" ? "justify-end" : "justify-start"} mb-4`}>
      <div
        className={`max-w-xs px-4 py-2 rounded-lg ${
          role === "user" ? "bg-green-500 text-white rounded-br-none" : "bg-gray-200 text-gray-900 rounded-bl-none"
        }`}
      >
        <p className="text-sm">{content}</p>
        <p className={`text-xs mt-1 ${role === "user" ? "text-green-100" : "text-gray-600"}`}>{timestamp}</p>
        {showFeedback && (
          <div className="flex items-center gap-2 mt-2 pt-2 border-t border-opacity-30">
            {isCorrect ? (
              <>
                <CheckCircle2 className="w-4 h-4 text-green-600" />
                <span className="text-xs font-semibold">Correct!</span>
              </>
            ) : (
              <>
                <XCircle className="w-4 h-4 text-red-600" />
                <span className="text-xs font-semibold">Incorrect</span>
              </>
            )}
          </div>
        )}
      </div>
    </div>
  )
}
