"use client"

import { useState } from "react"
import { AlertTriangle, CheckCircle, XCircle, Phone, Shield } from "lucide-react"

interface PhishingMessageProps {
  onChoice: (choice: string) => void
}

export function PhishingMessageInteractive({ onChoice }: PhishingMessageProps) {
  const [selectedChoice, setSelectedChoice] = useState<string | null>(null)
  const [showFeedback, setShowFeedback] = useState(false)

  const handleChoice = (choice: string) => {
    setSelectedChoice(choice)
    setShowFeedback(true)
    onChoice(choice)
  }

  const isCorrect = selectedChoice === "verify"

  return (
    <div className="flex flex-col gap-3 w-full">
      {/* Scam Message */}
      <div className="flex justify-start">
        <div className="max-w-xs bg-gray-200 dark:bg-slate-700 text-gray-900 dark:text-white rounded-lg px-4 py-2 rounded-bl-none">
          <p className="text-sm break-words font-semibold">Mom/Dad</p>
          <p className="text-xs text-gray-600 dark:text-gray-400 mt-1">Unknown Number • 3:45 PM</p>
        </div>
      </div>

      {/* Main Phishing Message */}
      <div className="flex justify-start">
        <div className="max-w-xs bg-gray-200 dark:bg-slate-700 text-gray-900 dark:text-white rounded-lg px-4 py-2 rounded-bl-none">
          <p className="text-sm break-words">
            My phone fell in water and I've lost all my contacts. This is my new number. Can you save it?
          </p>
        </div>
      </div>

      {/* Second Message */}
      <div className="flex justify-start">
        <div className="max-w-xs bg-gray-200 dark:bg-slate-700 text-gray-900 dark:text-white rounded-lg px-4 py-2 rounded-bl-none">
          <p className="text-sm break-words">
            Also, I need to pay an urgent bill but I can't access my bank account. Can you send me money? I'll pay you
            back tonight.
          </p>
        </div>
      </div>

      {/* Interactive Choice Section */}
      <div className="mt-4 pt-4 border-t border-gray-300 dark:border-slate-600">
        <p className="text-xs font-semibold text-gray-700 dark:text-gray-300 mb-3">What would you do?</p>

        <div className="flex flex-col gap-2">
          {/* Stop Choice */}
          <button
            onClick={() => handleChoice("stop")}
            className={`w-full px-3 py-2 rounded-lg text-sm font-medium transition-all ${
              selectedChoice === "stop"
                ? "bg-red-500 text-white ring-2 ring-red-600"
                : "bg-red-100 dark:bg-red-900 text-red-700 dark:text-red-300 hover:bg-red-200 dark:hover:bg-red-800"
            }`}
          >
            <div className="flex items-center gap-2 justify-center">
              <XCircle size={16} />
              STOP - Don't transfer money
            </div>
          </button>

          {/* Verify Choice - CORRECT */}
          <button
            onClick={() => handleChoice("verify")}
            className={`w-full px-3 py-2 rounded-lg text-sm font-medium transition-all ${
              selectedChoice === "verify"
                ? "bg-green-500 text-white ring-2 ring-green-600"
                : "bg-green-100 dark:bg-green-900 text-green-700 dark:text-green-300 hover:bg-green-200 dark:hover:bg-green-800"
            }`}
          >
            <div className="flex items-center gap-2 justify-center">
              <Phone size={16} />
              VERIFY - Call their real number
            </div>
          </button>

          {/* Report Choice */}
          <button
            onClick={() => handleChoice("report")}
            className={`w-full px-3 py-2 rounded-lg text-sm font-medium transition-all ${
              selectedChoice === "report"
                ? "bg-blue-500 text-white ring-2 ring-blue-600"
                : "bg-blue-100 dark:bg-blue-900 text-blue-700 dark:text-blue-300 hover:bg-blue-200 dark:hover:bg-blue-800"
            }`}
          >
            <div className="flex items-center gap-2 justify-center">
              <Shield size={16} />
              REPORT - Block and report
            </div>
          </button>
        </div>
      </div>

      {/* Feedback Section */}
      {showFeedback && (
        <div className="mt-4 p-3 rounded-lg border-l-4 animate-in fade-in slide-in-from-top-2 duration-300">
          {isCorrect ? (
            <div className="border-l-4 border-green-500 bg-green-50 dark:bg-green-900/20 p-3 rounded">
              <div className="flex items-start gap-2">
                <CheckCircle size={18} className="text-green-600 dark:text-green-400 flex-shrink-0 mt-0.5" />
                <div>
                  <p className="font-semibold text-green-800 dark:text-green-300 text-sm">Excellent Choice!</p>
                  <p className="text-xs text-green-700 dark:text-green-400 mt-1">
                    Always verify by calling the person on their original known number. A 30-second call would confirm
                    this is a scam.
                  </p>
                </div>
              </div>
            </div>
          ) : (
            <div className="border-l-4 border-red-500 bg-red-50 dark:bg-red-900/20 p-3 rounded">
              <div className="flex items-start gap-2">
                <AlertTriangle size={18} className="text-red-600 dark:text-red-400 flex-shrink-0 mt-0.5" />
                <div>
                  <p className="font-semibold text-red-800 dark:text-red-300 text-sm">Watch Out!</p>
                  <p className="text-xs text-red-700 dark:text-red-400 mt-1">
                    While that helps, the golden rule is VERIFY. Call your child on their original number immediately -
                    a 30-second call will confirm it's a scam.
                  </p>
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      {/* Red Flags Highlight */}
      <div className="mt-4 p-3 bg-amber-50 dark:bg-amber-900/20 border border-amber-200 dark:border-amber-800 rounded-lg">
        <p className="text-xs font-semibold text-amber-800 dark:text-amber-300 mb-2">Red Flags:</p>
        <ul className="text-xs text-amber-700 dark:text-amber-400 space-y-1">
          <li>• Claim from "Mom/Dad" but unknown number</li>
          <li>• Emergency situation creating urgency</li>
          <li>• Request for money with guarantee to repay</li>
          <li>• Phone "fell in water" excuse</li>
        </ul>
      </div>
    </div>
  )
}
