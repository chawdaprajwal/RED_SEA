"use client"

import { useState } from "react"
import { ChatMessage } from "./chat-message"
import { FeedbackPanel } from "./feedback-panel"
import { ScenarioChoice } from "./scenario-choice"
import { Button } from "@/components/ui/button"
import { SecurityCoach } from "./security-coach"
import { RedFlagHighlighter } from "./red-flag-highlighter"

interface Scenario {
  id: string
  title: string
  contact: string
  initialMessage: string
  redFlags: Array<{
    type: "urgent" | "unfamiliar" | "link" | "request"
    text: string
  }>
  choices: Array<{
    id: string
    text: string
    isCorrect: boolean
    feedback: {
      explanation: string
      consequence: string
      tip: string
    }
  }>
}

const scenarios: Scenario[] = [
  {
    id: "scenario-1",
    title: "Emergency Money Transfer",
    contact: "Mom",
    initialMessage:
      "Mom/Dad, my phone fell in water and I've lost all my contacts. This is my new number. Also, I need to pay an urgent bill but I can't access my bank account. Can you send me the money? I'll pay you back tonight.",
    redFlags: [
      {
        type: "unfamiliar",
        text: "New phone number from an unfamiliar contact - real family members use known numbers",
      },
      {
        type: "urgent",
        text: "Multiple urgent requests combined - 'phone fell in water' AND 'urgent bill' creates panic",
      },
      {
        type: "request",
        text: "Direct money request - legitimate emergencies are usually discussed before asking",
      },
    ],
    choices: [
      {
        id: "choice-1-a",
        text: "Send Money Now",
        isCorrect: false,
        feedback: {
          explanation: "SCAM! Money lost - you've transferred funds to a scammer.",
          consequence: "Your hard-earned money is gone and irretrievable.",
          tip: "Always verify through the original contact method before sending money in emergencies.",
        },
      },
      {
        id: "choice-1-b",
        text: "Call Original Number",
        isCorrect: true,
        feedback: {
          explanation: "Smart decision! You've verified your child is safe.",
          consequence: "Scam prevented - you caught the social engineering attack.",
          tip: "The golden rule: Always verify urgent requests by calling or messaging through known contact details.",
        },
      },
      {
        id: "choice-1-c",
        text: "Ask Security Question",
        isCorrect: true,
        feedback: {
          explanation: "Excellent thinking! Security questions help confirm identity.",
          consequence: "Family security stops scams - a scammer won't know personal family details.",
          tip: "Establish family security questions beforehand for emergency situations.",
        },
      },
    ],
  },
  {
    id: "scenario-2",
    title: "WhatsApp Web Verification",
    contact: "John (Friend)",
    initialMessage:
      "Hey! Can you help me? I'm trying to login to WhatsApp Web but the verification code came to your phone. Can you forward it to me?",
    redFlags: [
      {
        type: "unfamiliar",
        text: "Unusual request - WhatsApp never asks friends for verification codes",
      },
      {
        type: "urgent",
        text: "Requests immediate help without explanation - creates pressure",
      },
      {
        type: "request",
        text: "Asking for sensitive security code - never share codes with anyone",
      },
    ],
    choices: [
      {
        id: "choice-2-a",
        text: "Forward the Code",
        isCorrect: false,
        feedback: {
          explanation: "Account Hacked! The scammer now has access to your WhatsApp.",
          consequence: "Your account is compromised and can be used to scam your contacts.",
          tip: "Never share verification codes with anyone, even friends claiming to need them.",
        },
      },
      {
        id: "choice-2-b",
        text: "Call to Verify",
        isCorrect: true,
        feedback: {
          explanation: "Correct! Calling confirms it's a scam.",
          consequence: "Your account and your friend's contacts remain safe.",
          tip: "WhatsApp support never asks for verification codes. If in doubt, always call the person directly.",
        },
      },
      {
        id: "choice-2-c",
        text: "Report & Block",
        isCorrect: true,
        feedback: {
          explanation: "Perfect! You've taken immediate protective action.",
          consequence: "The scammer is blocked and reported, protecting you and others.",
          tip: "Report suspicious requests immediately and block contacts attempting account takeovers.",
        },
      },
    ],
  },
  {
    id: "scenario-3",
    title: "Gift Card Offer",
    contact: "Unknown",
    initialMessage: "CONGRATULATIONS! You won a $500 Amazon gift card! Click to claim: bit.ly/amzn-claim-500",
    redFlags: [
      {
        type: "urgent",
        text: "Celebratory language creates excitement - bypasses logical thinking",
      },
      {
        type: "link",
        text: "Shortened URL (bit.ly) hides the real destination - standard phishing technique",
      },
      {
        type: "request",
        text: "Random offer from unknown contact - legitimate companies contact verified winners",
      },
    ],
    choices: [
      {
        id: "choice-3-a",
        text: "Click Link",
        isCorrect: false,
        feedback: {
          explanation: "Phishing page detected! Your password has been stolen.",
          consequence: "Scammers have access to your Amazon account and payment methods.",
          tip: "Legitimate offers never come via random WhatsApp messages. Always access services through official apps or websites.",
        },
      },
      {
        id: "choice-3-b",
        text: "Hover to See Real URL",
        isCorrect: true,
        feedback: {
          explanation: "Smart! You've identified the malicious URL.",
          consequence: "The fake URL reveals the scam before any damage.",
          tip: "Hover over links to see real URLs. Shortened URLs like 'bit.ly' often hide malicious destinations.",
        },
      },
      {
        id: "choice-3-c",
        text: "Delete & Report",
        isCorrect: true,
        feedback: {
          explanation: "Correct! You've taken defensive action.",
          consequence: "The phishing attempt is reported and removed from circulation.",
          tip: "Delete suspicious messages immediately and report them to help protect others.",
        },
      },
    ],
  },
]

interface ChatState {
  messages: Array<{
    role: "user" | "contact"
    content: string
    timestamp: string
  }>
  selectedChoice?: string
  showFeedback: boolean
  score: number
  completedScenarios: string[]
  showCoach: boolean
}

interface WhatsAppChatProps {
  onUpdateScore?: (score: number) => void
}

export function WhatsAppChat({ onUpdateScore }: WhatsAppChatProps) {
  const [currentScenarioIndex, setCurrentScenarioIndex] = useState(0)
  const [chatState, setChatState] = useState<ChatState>({
    messages: [],
    showFeedback: false,
    score: 0,
    completedScenarios: [],
    showCoach: false,
  })

  const currentScenario = scenarios[currentScenarioIndex]
  const isScenarioComplete = chatState.completedScenarios.includes(currentScenario.id)

  const handleChoose = (choiceId: string) => {
    const choice = currentScenario.choices.find((c) => c.id === choiceId)
    if (!choice) return

    setChatState((prev) => ({
      ...prev,
      messages: [
        ...prev.messages,
        {
          role: "contact",
          content: currentScenario.initialMessage,
          timestamp: "Initial Message",
        },
        {
          role: "user",
          content: choice.text,
          timestamp: new Date().toLocaleTimeString(),
        },
      ],
      selectedChoice: choiceId,
      showFeedback: true,
      showCoach: false,
      score: prev.score + (choice.isCorrect ? 10 : 0),
      completedScenarios: !prev.completedScenarios.includes(currentScenario.id)
        ? [...prev.completedScenarios, currentScenario.id]
        : prev.completedScenarios,
    }))

    if (onUpdateScore && choice.isCorrect) {
      onUpdateScore(chatState.score + 10)
    }
  }

  const handleNextScenario = () => {
    if (currentScenarioIndex < scenarios.length - 1) {
      setCurrentScenarioIndex(currentScenarioIndex + 1)
      setChatState({
        messages: [],
        showFeedback: false,
        score: chatState.score,
        completedScenarios: chatState.completedScenarios,
        showCoach: false,
      })
    }
  }

  const selectedChoice = currentScenario.choices.find((c) => c.id === chatState.selectedChoice)

  return (
    <div className="flex flex-col h-full bg-white">
      <div className="bg-gradient-to-r from-green-500 to-green-600 text-white p-4">
        <h2 className="font-bold text-lg">{currentScenario.contact}</h2>
        <p className="text-sm text-green-100">{currentScenario.title}</p>
      </div>

      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {chatState.messages.length === 0 && (
          <>
            <ChatMessage role="contact" content={currentScenario.initialMessage} timestamp="Today 14:32" />
            {chatState.showCoach && (
              <SecurityCoach
                scenarioId={currentScenario.id}
                onClose={() => setChatState((prev) => ({ ...prev, showCoach: false }))}
              />
            )}
            {!chatState.showCoach && (
              <div className="space-y-3">
                {currentScenario.redFlags.map((flag, idx) => (
                  <RedFlagHighlighter key={idx} text={flag.text} flagType={flag.type} />
                ))}
              </div>
            )}
          </>
        )}
        {chatState.messages.map((msg, idx) => (
          <ChatMessage
            key={idx}
            role={msg.role}
            content={msg.content}
            timestamp={msg.timestamp}
            isCorrect={msg.role === "user" && selectedChoice ? selectedChoice.isCorrect : undefined}
            showFeedback={msg.role === "user" && chatState.showFeedback}
          />
        ))}
      </div>

      {chatState.showFeedback && selectedChoice && (
        <div className="border-t p-4 bg-gray-50">
          <FeedbackPanel
            title={selectedChoice.isCorrect ? "Correct!" : "Incorrect"}
            explanation={selectedChoice.feedback.explanation}
            isCorrect={selectedChoice.isCorrect}
            tip={selectedChoice.feedback.tip}
          />
          {currentScenarioIndex < scenarios.length - 1 ? (
            <Button onClick={handleNextScenario} className="w-full bg-green-500 hover:bg-green-600">
              Next Scenario ({currentScenarioIndex + 1}/{scenarios.length})
            </Button>
          ) : (
            <Button onClick={() => setCurrentScenarioIndex(0)} className="w-full bg-blue-500 hover:bg-blue-600">
              Restart Training
            </Button>
          )}
        </div>
      )}

      {chatState.messages.length === 0 && !chatState.showCoach && (
        <div className="border-t p-4 bg-gray-50 space-y-3">
          <div className="flex gap-2">
            <Button
              onClick={() => setChatState((prev) => ({ ...prev, showCoach: true }))}
              variant="outline"
              className="flex-1"
            >
              Get Hint
            </Button>
          </div>
          <div>
            <p className="text-sm text-gray-600 mb-3 font-semibold">Choose your action:</p>
            <ScenarioChoice
              choices={currentScenario.choices}
              onChoose={handleChoose}
              disabled={chatState.showFeedback}
            />
          </div>
        </div>
      )}
    </div>
  )
}
