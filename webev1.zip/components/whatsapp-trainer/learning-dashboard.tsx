"use client"
import { Card } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { CheckCircle2, AlertCircle, Award } from "lucide-react"

interface DashboardProps {
  score: number
  completedScenarios: number
  totalScenarios: number
}

export function LearningDashboard({ score, completedScenarios, totalScenarios }: DashboardProps) {
  const percentage = (completedScenarios / totalScenarios) * 100
  const badges = []

  if (completedScenarios >= 1) badges.push("Verification Expert")
  if (completedScenarios >= 2) badges.push("Link Detective")
  if (completedScenarios >= 3) badges.push("Emergency Responder")

  return (
    <div className="space-y-4">
      <Card className="p-4 bg-gradient-to-r from-blue-50 to-indigo-50">
        <div className="flex items-center justify-between mb-4">
          <h3 className="font-bold text-lg">Phishing Detection Score</h3>
          <span className="text-3xl font-bold text-blue-600">{Math.round((score / 30) * 100)}%</span>
        </div>
        <div className="w-full bg-gray-200 rounded-full h-2">
          <div
            className="bg-blue-600 h-2 rounded-full transition-all duration-300"
            style={{ width: `${(score / 30) * 100}%` }}
          />
        </div>
      </Card>

      <Card className="p-4">
        <h3 className="font-bold mb-3 flex items-center gap-2">
          <CheckCircle2 className="w-5 h-5 text-green-600" />
          Progress
        </h3>
        <p className="text-sm text-gray-600">
          {completedScenarios} of {totalScenarios} scenarios completed
        </p>
        <div className="mt-2 space-y-2">
          {Array.from({ length: totalScenarios }).map((_, i) => (
            <div key={i} className={`h-2 rounded-full ${i < completedScenarios ? "bg-green-500" : "bg-gray-200"}`} />
          ))}
        </div>
      </Card>

      {badges.length > 0 && (
        <Card className="p-4 bg-gradient-to-r from-amber-50 to-orange-50">
          <h3 className="font-bold mb-3 flex items-center gap-2">
            <Award className="w-5 h-5 text-amber-600" />
            Badges Earned
          </h3>
          <div className="flex flex-wrap gap-2">
            {badges.map((badge) => (
              <Badge key={badge} className="bg-amber-500 text-white">
                {badge}
              </Badge>
            ))}
          </div>
        </Card>
      )}

      <Card className="p-4 bg-blue-50 border-blue-200">
        <h3 className="font-bold mb-2 flex items-center gap-2">
          <AlertCircle className="w-5 h-5 text-blue-600" />
          Security Tips
        </h3>
        <ul className="text-sm space-y-2 text-blue-900">
          <li>• Always verify urgent requests through original contact numbers</li>
          <li>• Never share verification codes with anyone</li>
          <li>• Check URLs by hovering before clicking links</li>
          <li>• Report suspicious messages immediately</li>
        </ul>
      </Card>
    </div>
  )
}
