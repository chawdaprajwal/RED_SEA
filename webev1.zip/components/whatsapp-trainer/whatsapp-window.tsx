"use client"

import { useState } from "react"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { WhatsAppChat } from "./whatsapp-chat"
import { LearningDashboard } from "./learning-dashboard"

export function WhatsAppWindow() {
  const [score, setScore] = useState(0)
  const [completedScenarios, setCompletedScenarios] = useState(0)

  const handleScoreUpdate = (newScore: number) => {
    setScore(newScore)
  }

  const handleScenarioComplete = () => {
    setCompletedScenarios((prev) => Math.min(prev + 1, 3))
  }

  return (
    <div className="w-full h-full flex flex-col bg-white rounded-lg overflow-hidden">
      <Tabs defaultValue="chat" className="flex flex-col h-full w-full">
        <TabsList className="grid w-full grid-cols-2 rounded-none bg-gray-100">
          <TabsTrigger value="chat" className="rounded-none">
            Chat
          </TabsTrigger>
          <TabsTrigger value="dashboard" className="rounded-none">
            Dashboard
          </TabsTrigger>
        </TabsList>

        <TabsContent value="chat" className="flex-1 overflow-hidden m-0">
          <WhatsAppChat onUpdateScore={handleScoreUpdate} />
        </TabsContent>

        <TabsContent value="dashboard" className="flex-1 overflow-y-auto p-4 m-0">
          <LearningDashboard score={score} completedScenarios={completedScenarios} totalScenarios={3} />
        </TabsContent>
      </Tabs>
    </div>
  )
}
