"use client"

import { useState } from "react"
import { AlertTriangle, CheckCircle, XCircle, Zap, Shield } from "lucide-react"

interface PhishingScenarioGiftcardProps {
  onChoice: (choice: string) => void
}

export function PhishingScenarioGiftcard({ onChoice }: PhishingScenarioGiftcardProps) {
  const [selectedChoice, setSelectedChoice] = useState<string | null>(null)
  const [showFeedback, setShowFeedback] = useState(false)
  const [showMaliciousUrl, setShowMaliciousUrl] = useState(false)

  const handleChoice = (choice: string) => {
    setSelectedChoice(choice)
    setShowFeedback(true)
    if (choice === "link") {
      setShowMaliciousUrl(true)
    }
    onChoice(choice)
  }

  const isCorrect = selectedChoice === "delete"

  return (
    <div className="flex flex-col gap-3 w-full">
      {/* Main Message */}
      <div className="flex justify-start">
        <div className="max-w-xs bg-gray-200 dark:bg-slate-700 text-gray-900 dark:text-white rounded-lg px-4 py-2 rounded-bl-none">
          <p className="text-sm break-words">
            🎉 CONGRATULATIONS! You won a $500 Amazon gift card! Click to claim:{" "}
            <span className="text-blue-600 dark:text-blue-400 underline cursor-pointer">amaz0n-rewards.click</span>
          </p>
        </div>
      </div>

      {/* Interactive Choice Section */}
      <div className="mt-4 pt-4 border-t border-gray-300 dark:border-slate-600">
        <p className="text-xs font-semibold text-gray-700 dark:text-gray-300 mb-3">What would you do?</p>

        <div className="flex flex-col gap-2">
          {/* Click Link - WRONG */}
          <button
            onClick={() => handleChoice("link")}
            className={`w-full px-3 py-2 rounded-lg text-sm font-medium transition-all ${
              selectedChoice === "link"
                ? "bg-red-500 text-white ring-2 ring-red-600"
                : "bg-red-100 dark:bg-red-900 text-red-700 dark:text-red-300 hover:bg-red-200 dark:hover:bg-red-800"
            }`}
          >
            <div className="flex items-center gap-2 justify-center">
              <XCircle size={16} />
              Click the link
            </div>
          </button>

          {/* Delete & Report - CORRECT */}
          <button
            onClick={() => handleChoice("delete")}
            className={`w-full px-3 py-2 rounded-lg text-sm font-medium transition-all ${
              selectedChoice === "delete"
                ? "bg-green-500 text-white ring-2 ring-green-600"
                : "bg-green-100 dark:bg-green-900 text-green-700 dark:text-green-300 hover:bg-green-200 dark:hover:bg-green-800"
            }`}
          >
            <div className="flex items-center gap-2 justify-center">
              <Shield size={16} />
              Delete and report
            </div>
          </button>

          {/* Check URL - GOOD */}
          <button
            onClick={() => handleChoice("check")}
            className={`w-full px-3 py-2 rounded-lg text-sm font-medium transition-all ${
              selectedChoice === "check"
                ? "bg-blue-500 text-white ring-2 ring-blue-600"
                : "bg-blue-100 dark:bg-blue-900 text-blue-700 dark:text-blue-300 hover:bg-blue-200 dark:hover:bg-blue-800"
            }`}
          >
            <div className="flex items-center gap-2 justify-center">
              <Zap size={16} />
              Hover to check the real URL
            </div>
          </button>
        </div>
      </div>

      {/* Malicious URL Revealed */}
      {showMaliciousUrl && (
        <div className="mt-4 p-3 bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-lg animate-in fade-in">
          <p className="text-xs font-semibold text-red-800 dark:text-red-300 mb-2">⚠️ Real URL Behind the Link:</p>
          <p className="text-xs bg-red-100 dark:bg-red-900/50 p-2 rounded font-mono text-red-700 dark:text-red-400 break-all">
            http://malicious-phishing-site.ru/amaz0n-rewards-steal-data
          </p>
        </div>
      )}

      {/* Feedback Section */}
      {showFeedback && (
        <div className="mt-4 p-3 rounded-lg border-l-4 animate-in fade-in slide-in-from-top-2 duration-300">
          {isCorrect ? (
            <div className="border-l-4 border-green-500 bg-green-50 dark:bg-green-900/20 p-3 rounded">
              <div className="flex items-start gap-2">
                <CheckCircle size={18} className="text-green-600 dark:text-green-400 flex-shrink-0 mt-0.5" />
                <div>
                  <p className="font-semibold text-green-800 dark:text-green-300 text-sm">Excellent Security Sense!</p>
                  <p className="text-xs text-green-700 dark:text-green-400 mt-1">
                    Legitimate companies never send gift card offers via random WhatsApp messages. Always delete
                    suspicious links and report them to help protect others.
                  </p>
                </div>
              </div>
            </div>
          ) : selectedChoice === "check" ? (
            <div className="border-l-4 border-blue-500 bg-blue-50 dark:bg-blue-900/20 p-3 rounded">
              <div className="flex items-start gap-2">
                <CheckCircle size={18} className="text-blue-600 dark:text-blue-400 flex-shrink-0 mt-0.5" />
                <div>
                  <p className="font-semibold text-blue-800 dark:text-blue-300 text-sm">Great Observation!</p>
                  <p className="text-xs text-blue-700 dark:text-blue-400 mt-1">
                    Checking URLs by hovering (not clicking!) reveals malicious domains. Notice how the real URL is
                    completely different from what's displayed.
                  </p>
                </div>
              </div>
            </div>
          ) : (
            <div className="border-l-4 border-red-500 bg-red-50 dark:bg-red-900/20 p-3 rounded">
              <div className="flex items-start gap-2">
                <AlertTriangle size={18} className="text-red-600 dark:text-red-400 flex-shrink-0 mt-0.5" />
                <div>
                  <p className="font-semibold text-red-800 dark:text-red-300 text-sm">Phishing Site Opened!</p>
                  <p className="text-xs text-red-700 dark:text-red-400 mt-1">
                    The fake Amazon page stole your credentials. The real URL behind the link was completely different.
                    Always verify offers through official company websites directly.
                  </p>
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      {/* Red Flags */}
      <div className="mt-4 p-3 bg-amber-50 dark:bg-amber-900/20 border border-amber-200 dark:border-amber-800 rounded-lg">
        <p className="text-xs font-semibold text-amber-800 dark:text-amber-300 mb-2">Red Flags:</p>
        <ul className="text-xs text-amber-700 dark:text-amber-400 space-y-1">
          <li>• Unsolicited gift card or prize offer</li>
          <li>• Shortened or disguised URL link</li>
          <li>• Link sent via WhatsApp, not official app</li>
          <li>• Claiming you won something you didn't enter</li>
          <li>• Suspicious domain name (amaz0n ≠ amazon)</li>
        </ul>
      </div>
    </div>
  )
}
