"use client"

import { useState } from "react"
import { AlertTriangle, CheckCircle, XCircle, Phone, HelpCircle } from "lucide-react"

interface PhishingScenarioEmergencyProps {
  onChoice: (choice: string) => void
}

export function PhishingScenarioEmergency({ onChoice }: PhishingScenarioEmergencyProps) {
  const [selectedChoice, setSelectedChoice] = useState<string | null>(null)
  const [showFeedback, setShowFeedback] = useState(false)

  const handleChoice = (choice: string) => {
    setSelectedChoice(choice)
    setShowFeedback(true)
    onChoice(choice)
  }

  const isCorrect = selectedChoice === "call"

  return (
    <div className="flex flex-col gap-3 w-full">
      {/* Main Message 1 */}
      <div className="flex justify-start">
        <div className="max-w-xs bg-gray-200 dark:bg-slate-700 text-gray-900 dark:text-white rounded-lg px-4 py-2 rounded-bl-none">
          <p className="text-sm break-words font-semibold">Mom!</p>
        </div>
      </div>

      {/* Main Message 2 */}
      <div className="flex justify-start">
        <div className="max-w-xs bg-gray-200 dark:bg-slate-700 text-gray-900 dark:text-white rounded-lg px-4 py-2 rounded-bl-none">
          <p className="text-sm break-words">
            I broke my phone and this is my new number. I need money for hospital bills urgently!
          </p>
        </div>
      </div>

      {/* Interactive Choice Section */}
      <div className="mt-4 pt-4 border-t border-gray-300 dark:border-slate-600">
        <p className="text-xs font-semibold text-gray-700 dark:text-gray-300 mb-3">What would you do?</p>

        <div className="flex flex-col gap-2">
          {/* Send Money Now - WRONG */}
          <button
            onClick={() => handleChoice("send")}
            className={`w-full px-3 py-2 rounded-lg text-sm font-medium transition-all ${
              selectedChoice === "send"
                ? "bg-red-500 text-white ring-2 ring-red-600"
                : "bg-red-100 dark:bg-red-900 text-red-700 dark:text-red-300 hover:bg-red-200 dark:hover:bg-red-800"
            }`}
          >
            <div className="flex items-center gap-2 justify-center">
              <XCircle size={16} />
              Send money immediately
            </div>
          </button>

          {/* Call Original Number - CORRECT */}
          <button
            onClick={() => handleChoice("call")}
            className={`w-full px-3 py-2 rounded-lg text-sm font-medium transition-all ${
              selectedChoice === "call"
                ? "bg-green-500 text-white ring-2 ring-green-600"
                : "bg-green-100 dark:bg-green-900 text-green-700 dark:text-green-300 hover:bg-green-200 dark:hover:bg-green-800"
            }`}
          >
            <div className="flex items-center gap-2 justify-center">
              <Phone size={16} />
              Call their original number
            </div>
          </button>

          {/* Ask Security Question */}
          <button
            onClick={() => handleChoice("question")}
            className={`w-full px-3 py-2 rounded-lg text-sm font-medium transition-all ${
              selectedChoice === "question"
                ? "bg-blue-500 text-white ring-2 ring-blue-600"
                : "bg-blue-100 dark:bg-blue-900 text-blue-700 dark:text-blue-300 hover:bg-blue-200 dark:hover:bg-blue-800"
            }`}
          >
            <div className="flex items-center gap-2 justify-center">
              <HelpCircle size={16} />
              Ask a personal security question
            </div>
          </button>
        </div>
      </div>

      {/* Feedback Section */}
      {showFeedback && (
        <div className="mt-4 p-3 rounded-lg border-l-4 animate-in fade-in slide-in-from-top-2 duration-300">
          {isCorrect ? (
            <div className="border-l-4 border-green-500 bg-green-50 dark:bg-green-900/20 p-3 rounded">
              <div className="flex items-start gap-2">
                <CheckCircle size={18} className="text-green-600 dark:text-green-400 flex-shrink-0 mt-0.5" />
                <div>
                  <p className="font-semibold text-green-800 dark:text-green-300 text-sm">Perfect Response!</p>
                  <p className="text-xs text-green-700 dark:text-green-400 mt-1">
                    A quick phone call on their original number would confirm this is genuine or a scam. Emergency
                    situations are common social engineering tactics.
                  </p>
                </div>
              </div>
            </div>
          ) : selectedChoice === "question" ? (
            <div className="border-l-4 border-blue-500 bg-blue-50 dark:bg-blue-900/20 p-3 rounded">
              <div className="flex items-start gap-2">
                <CheckCircle size={18} className="text-blue-600 dark:text-blue-400 flex-shrink-0 mt-0.5" />
                <div>
                  <p className="font-semibold text-blue-800 dark:text-blue-300 text-sm">Good Thinking!</p>
                  <p className="text-xs text-blue-700 dark:text-blue-400 mt-1">
                    Security questions help verify identity. However, calling their original number is the fastest
                    verification method and most reliable.
                  </p>
                </div>
              </div>
            </div>
          ) : (
            <div className="border-l-4 border-red-500 bg-red-50 dark:bg-red-900/20 p-3 rounded">
              <div className="flex items-start gap-2">
                <AlertTriangle size={18} className="text-red-600 dark:text-red-400 flex-shrink-0 mt-0.5" />
                <div>
                  <p className="font-semibold text-red-800 dark:text-red-300 text-sm">Money Lost!</p>
                  <p className="text-xs text-red-700 dark:text-red-400 mt-1">
                    Emergency requests coupled with a new number are classic social engineering attacks. Always verify
                    through original contact first - it only takes 30 seconds.
                  </p>
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      {/* Red Flags */}
      <div className="mt-4 p-3 bg-amber-50 dark:bg-amber-900/20 border border-amber-200 dark:border-amber-800 rounded-lg">
        <p className="text-xs font-semibold text-amber-800 dark:text-amber-300 mb-2">Red Flags:</p>
        <ul className="text-xs text-amber-700 dark:text-amber-400 space-y-1">
          <li>• Emergency + new number = classic scam combo</li>
          <li>• Urgency to prevent you from thinking</li>
          <li>• Requesting money before full verification</li>
          <li>• Promise of repayment (rarely happens)</li>
        </ul>
      </div>
    </div>
  )
}
