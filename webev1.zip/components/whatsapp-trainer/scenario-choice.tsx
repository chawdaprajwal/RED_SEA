"use client"

import { Button } from "@/components/ui/button"

interface Choice {
  id: string
  text: string
  isCorrect: boolean
}

interface ScenarioChoiceProps {
  choices: Choice[]
  onChoose: (choiceId: string) => void
  disabled?: boolean
}

export function ScenarioChoice({ choices, onChoose, disabled }: ScenarioChoiceProps) {
  return (
    <div className="space-y-3">
      {choices.map((choice) => (
        <Button
          key={choice.id}
          onClick={() => onChoose(choice.id)}
          disabled={disabled}
          variant="outline"
          className="w-full justify-start text-left h-auto py-3 px-4 whitespace-normal hover:bg-green-50"
        >
          {choice.text}
        </Button>
      ))}
    </div>
  )
}
