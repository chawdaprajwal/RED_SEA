"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Lightbulb, X } from "lucide-react"

interface CoachHint {
  level: 1 | 2 | 3
  text: string
}

interface SecurityCoachProps {
  scenarioId: string
  hints: CoachHint[]
  onClose?: () => void
}

const scenarioHints: Record<string, CoachHint[]> = {
  "scenario-1": [
    {
      level: 1,
      text: "Red Flag Alert: The message claims urgency but comes from an unfamiliar number. Real family members usually use established contact methods.",
    },
    {
      level: 2,
      text: "Verification Tip: Scammers rely on panic. A quick 30-second call to your child's original number will confirm if this is legitimate.",
    },
    {
      level: 3,
      text: "Pattern Recognition: This combines two social engineering tactics - a new number (to avoid you recognizing it's fake) AND urgency (to bypass your judgment).",
    },
  ],
  "scenario-2": [
    {
      level: 1,
      text: "Red Flag Alert: WhatsApp will NEVER ask you to forward verification codes to anyone, not even friends. This is the #1 account takeover method.",
    },
    {
      level: 2,
      text: "Verification Tip: If your friend needs help accessing WhatsApp, they should contact WhatsApp support directly, not ask you for verification codes.",
    },
    {
      level: 3,
      text: "Pattern Recognition: The attacker is using social engineering by posing as your friend. Always verify through a different communication channel first.",
    },
  ],
  "scenario-3": [
    {
      level: 1,
      text: "Red Flag Alert: You never entered any contest. Legitimate companies don't announce winners via random messages with shortened links.",
    },
    {
      level: 2,
      text: "Link Detective Tip: Shortened URLs (bit.ly, tinyurl, etc.) hide the real destination. Always check the actual URL before clicking.",
    },
    {
      level: 3,
      text: "Pattern Recognition: Prize scams use excitement to override caution. Real companies contact winners through official channels with verifiable information.",
    },
  ],
}

export function SecurityCoach({ scenarioId, onClose }: SecurityCoachProps & { onClose?: () => void }) {
  const [revealedHint, setRevealedHint] = useState<1 | 2 | 3 | null>(null)
  const hints = scenarioHints[scenarioId] || []

  return (
    <Card className="p-4 bg-gradient-to-br from-amber-50 to-yellow-50 border-2 border-amber-300">
      <div className="flex items-center justify-between mb-3">
        <h3 className="font-bold text-lg flex items-center gap-2 text-amber-900">
          <Lightbulb className="w-5 h-5 text-amber-600" />
          Security Coach
        </h3>
        {onClose && (
          <button onClick={onClose} className="text-gray-500 hover:text-gray-700">
            <X className="w-4 h-4" />
          </button>
        )}
      </div>

      <p className="text-sm text-amber-800 mb-3">Need help? Get progressive hints to spot the red flags:</p>

      <div className="space-y-2">
        {hints.map((hint) => (
          <Button
            key={hint.level}
            onClick={() => setRevealedHint(revealedHint === hint.level ? null : hint.level)}
            variant="outline"
            className="w-full justify-start text-left h-auto py-2 px-3 whitespace-normal hover:bg-amber-100 border-amber-300"
          >
            <span className="text-amber-600 font-bold mr-2">Hint {hint.level}:</span>
            {revealedHint === hint.level ? (
              <span className="text-sm text-amber-900">{hint.text}</span>
            ) : (
              <span className="text-sm text-gray-600">Reveal hint...</span>
            )}
          </Button>
        ))}
      </div>

      <div className="mt-3 p-2 bg-blue-50 rounded border border-blue-200">
        <p className="text-xs text-blue-800">
          <strong>Pro Tip:</strong> Use hints strategically! Getting hints doesn't count against your score.
        </p>
      </div>
    </Card>
  )
}
