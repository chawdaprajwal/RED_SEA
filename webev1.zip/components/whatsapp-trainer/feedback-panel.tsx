interface FeedbackPanelProps {
  title: string
  explanation: string
  isCorrect: boolean
  tip: string
}

export function FeedbackPanel({ title, explanation, isCorrect, tip }: FeedbackPanelProps) {
  return (
    <div
      className={`rounded-lg p-4 mb-4 border-l-4 ${
        isCorrect ? "bg-green-50 border-green-500 text-green-900" : "bg-red-50 border-red-500 text-red-900"
      }`}
    >
      <h4 className="font-bold mb-2">{title}</h4>
      <p className="text-sm mb-3">{explanation}</p>
      <div className="bg-blue-50 text-blue-900 rounded p-2">
        <p className="text-xs font-semibold">Security Tip:</p>
        <p className="text-xs">{tip}</p>
      </div>
    </div>
  )
}
