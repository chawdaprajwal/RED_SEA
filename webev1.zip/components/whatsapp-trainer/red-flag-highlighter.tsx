import { AlertTriangle } from "lucide-react"

interface RedFlagProps {
  text: string
  flagType: "urgent" | "unfamiliar" | "link" | "request"
}

export function RedFlagHighlighter({ text, flagType }: RedFlagProps) {
  const colors: Record<string, string> = {
    urgent: "bg-red-100 border-red-300 text-red-900",
    unfamiliar: "bg-yellow-100 border-yellow-300 text-yellow-900",
    link: "bg-orange-100 border-orange-300 text-orange-900",
    request: "bg-pink-100 border-pink-300 text-pink-900",
  }

  const labels: Record<string, string> = {
    urgent: "URGENCY RED FLAG",
    unfamiliar: "UNFAMILIAR SOURCE",
    link: "SUSPICIOUS LINK",
    request: "UNUSUAL REQUEST",
  }

  return (
    <div className={`p-3 rounded border-l-4 ${colors[flagType]}`}>
      <div className="flex items-center gap-2 mb-1">
        <AlertTriangle className="w-4 h-4" />
        <span className="font-bold text-xs">{labels[flagType]}</span>
      </div>
      <p className="text-sm">{text}</p>
    </div>
  )
}
