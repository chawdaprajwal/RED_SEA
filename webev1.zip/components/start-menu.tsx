"use client"

import { useState } from "react"
import { Search, Moon, RotateCcw, Power, X } from "lucide-react"
import WhatsAppLogo from "./app-logos/whatsapp-logo"
import TelegramLogo from "./app-logos/telegram-logo"
import LinkedInLogo from "./app-logos/linkedin-logo"

interface StartMenuProps {
  isOpen: boolean
  onClose: () => void
  onLaunchApp: (type: string, title: string) => void
  openApps: Array<{ id: string; type: string; title: string; minimized: boolean }>
  onShutdown?: () => void
  onToggleMinimize?: (id: string) => void
}

const appLaunchers = [
  { type: "file-explorer", title: "File Explorer", icon: "📁" },
  { type: "email", title: "Email", icon: "✉️" },
  { type: "chat", title: "Messages", icon: "💬" },
  { type: "admin", title: "Admin Dashboard", icon: "⚙️" },
  { type: "chrome", title: "Chrome", icon: "🌐" },
  { type: "whatsapp", title: "WhatsApp", icon: <WhatsAppLogo />, isComponent: true },
  { type: "facebook", title: "Facebook", icon: "📘" },
  { type: "linkedin", title: "LinkedIn", icon: <LinkedInLogo />, isComponent: true },
  { type: "telegram", title: "Telegram", icon: <TelegramLogo />, isComponent: true },
  { type: "twitter", title: "Twitter", icon: "𝕏" },
  { type: "recycle-bin", title: "Recycle Bin", icon: "🗑️" },
  { type: "this-pc", title: "This PC", icon: "💻" },
  { type: "messages", title: "Messages", icon: "💬" },
]

const recommendedApps = appLaunchers.slice(0, 4)

export default function StartMenu({
  isOpen,
  onClose,
  onLaunchApp,
  openApps,
  onShutdown,
  onToggleMinimize,
}: StartMenuProps) {
  const [searchQuery, setSearchQuery] = useState("")
  const [showPowerOptions, setShowPowerOptions] = useState(false)

  if (!isOpen) return null

  const filteredApps = appLaunchers.filter(
    (app) =>
      app.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      app.type.toLowerCase().includes(searchQuery.toLowerCase()),
  )

  const handleLaunchApp = (type: string, title: string) => {
    const exists = openApps.find((app) => app.type === type)
    if (exists && exists.minimized && onToggleMinimize) {
      onToggleMinimize(exists.id)
    } else if (!exists) {
      onLaunchApp(type, title)
    }
    onClose()
    setSearchQuery("")
  }

  const handleShutdown = () => {
    if (window.confirm("Are you sure you want to shut down?")) {
      if (onShutdown) {
        onShutdown()
      }
      onClose()
    }
  }

  const handleRestart = () => {
    if (window.confirm("Are you sure you want to restart?")) {
      if (onShutdown) {
        onShutdown()
      }
      setTimeout(() => {
        window.location.reload()
      }, 500)
      onClose()
    }
  }

  const handleSleep = () => {
    openApps.forEach((app) => {
      if (!app.minimized && onToggleMinimize) {
        onToggleMinimize(app.id)
      }
    })
    onClose()
    alert("System entering sleep mode. Click any key to wake up.")
  }

  return (
    <>
      {/* Backdrop */}
      <div className="fixed inset-0 z-40 backdrop-blur-sm" onClick={onClose} />

      {/* Start Menu */}
      <div className="fixed bottom-14 left-0 z-50 m-0 sm:m-2 bg-white dark:bg-slate-900 border border-gray-200 dark:border-slate-700 rounded-2xl shadow-2xl w-full sm:w-96 max-h-[90vh] overflow-hidden flex flex-col">
        {/* Header with Close Button */}
        <div className="flex items-center justify-between p-3 sm:p-4 border-b border-gray-200 dark:border-slate-700">
          <h2 className="text-lg sm:text-xl font-bold text-gray-900 dark:text-white">Start</h2>
          <button
            onClick={onClose}
            className="p-1.5 hover:bg-gray-100 dark:hover:bg-slate-800 rounded-lg transition-colors"
            title="Close Start Menu"
          >
            <X size={18} />
          </button>
        </div>

        {/* Search Bar */}
        <div className="p-2 sm:p-3 border-b border-gray-200 dark:border-slate-700">
          <div className="relative">
            <Search size={16} className="absolute left-3 top-3 text-gray-400" />
            <input
              type="text"
              placeholder="Type here to search"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              autoFocus
              className="w-full pl-10 pr-3 py-2.5 border border-gray-300 dark:border-slate-600 rounded-lg bg-gray-50 dark:bg-slate-800 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 dark:text-white"
            />
          </div>
        </div>

        {/* Content - Scrollable */}
        <div className="flex-1 overflow-y-auto scroll-smooth">
          {searchQuery === "" ? (
            <>
              {/* Recommended Section */}
              <div className="p-3 sm:p-4">
                <h3 className="text-xs font-semibold text-gray-500 dark:text-gray-400 mb-2.5 px-1">RECOMMENDED</h3>
                <div className="grid grid-cols-2 gap-2">
                  {recommendedApps.map((app) => (
                    <button
                      key={app.type}
                      onClick={() => handleLaunchApp(app.type, app.title)}
                      className="flex items-center gap-3 p-2.5 rounded-lg hover:bg-gray-100 dark:hover:bg-slate-800 transition-colors active:scale-95"
                    >
                      <div className="text-2xl flex-shrink-0">
                        {typeof app.icon === "string" ? app.icon : <div className="w-8 h-8">{app.icon}</div>}
                      </div>
                      <div className="text-left flex-1 min-w-0">
                        <p className="text-xs sm:text-sm font-medium text-gray-900 dark:text-white truncate">
                          {app.title}
                        </p>
                      </div>
                    </button>
                  ))}
                </div>
              </div>

              <hr className="border-gray-200 dark:border-slate-700" />

              {/* All Apps Section */}
              <div className="p-3 sm:p-4">
                <h3 className="text-xs font-semibold text-gray-500 dark:text-gray-400 mb-2.5 px-1">ALL APPS</h3>
                <div className="space-y-1">
                  {appLaunchers.map((app) => (
                    <button
                      key={app.type}
                      onClick={() => handleLaunchApp(app.type, app.title)}
                      className="w-full text-left px-2.5 py-2 rounded-lg hover:bg-gray-100 dark:hover:bg-slate-800 flex items-center gap-3 transition-colors active:scale-95"
                    >
                      <span className="text-lg flex-shrink-0">
                        {typeof app.icon === "string" ? app.icon : <div className="w-6 h-6">{app.icon}</div>}
                      </span>
                      <span className="text-sm font-medium text-gray-900 dark:text-white">{app.title}</span>
                    </button>
                  ))}
                </div>
              </div>
            </>
          ) : (
            // Search Results
            <div className="p-3 sm:p-4">
              {filteredApps.length > 0 ? (
                <div className="space-y-1">
                  {filteredApps.map((app) => (
                    <button
                      key={app.type}
                      onClick={() => handleLaunchApp(app.type, app.title)}
                      className="w-full text-left px-2.5 py-2 rounded-lg hover:bg-gray-100 dark:hover:bg-slate-800 flex items-center gap-3 transition-colors active:scale-95"
                    >
                      <span className="text-lg flex-shrink-0">
                        {typeof app.icon === "string" ? app.icon : <div className="w-6 h-6">{app.icon}</div>}
                      </span>
                      <span className="text-sm font-medium text-gray-900 dark:text-white">{app.title}</span>
                    </button>
                  ))}
                </div>
              ) : (
                <p className="text-sm text-gray-500 dark:text-gray-400 text-center py-4">No apps found</p>
              )}
            </div>
          )}
        </div>

        {/* Power Options */}
        <div className="border-t border-gray-200 dark:border-slate-700 p-2 sm:p-3">
          <div className="relative">
            <button
              onClick={() => setShowPowerOptions(!showPowerOptions)}
              className="w-full flex items-center justify-center gap-2 px-3 py-2.5 rounded-lg hover:bg-gray-100 dark:hover:bg-slate-800 text-gray-700 dark:text-gray-200 transition-colors font-medium text-sm"
            >
              <Power size={16} />
              Power
            </button>

            {showPowerOptions && (
              <div className="absolute bottom-full left-0 right-0 mb-2 bg-white dark:bg-slate-800 border border-gray-200 dark:border-slate-700 rounded-lg shadow-lg overflow-hidden">
                <button
                  onClick={handleSleep}
                  className="w-full text-left px-3 py-2.5 hover:bg-yellow-100 dark:hover:bg-yellow-900/30 text-yellow-700 dark:text-yellow-400 flex items-center gap-2 transition-colors text-sm font-medium"
                >
                  <Moon size={14} />
                  Sleep
                </button>
                <button
                  onClick={handleRestart}
                  className="w-full text-left px-3 py-2.5 hover:bg-blue-100 dark:hover:bg-blue-900/30 text-blue-700 dark:text-blue-400 flex items-center gap-2 transition-colors text-sm font-medium border-t border-gray-200 dark:border-slate-700"
                >
                  <RotateCcw size={14} />
                  Restart
                </button>
                <button
                  onClick={handleShutdown}
                  className="w-full text-left px-3 py-2.5 hover:bg-red-100 dark:hover:bg-red-900/30 text-red-700 dark:text-red-400 flex items-center gap-2 transition-colors text-sm font-medium border-t border-gray-200 dark:border-slate-700"
                >
                  <Power size={14} />
                  Shut Down
                </button>
              </div>
            )}
          </div>
        </div>
      </div>
    </>
  )
}
