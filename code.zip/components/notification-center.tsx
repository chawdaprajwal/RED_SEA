"use client"

import { X } from "lucide-react"

interface Notification {
  id: string
  title: string
  message: string
  type: "info" | "success" | "warning" | "error"
}

interface NotificationCenterProps {
  notifications: Notification[]
  onClear: () => void
}

export default function NotificationCenter({ notifications, onClear }: NotificationCenterProps) {
  const getTypeColor = (type: string) => {
    switch (type) {
      case "success":
        return "bg-green-50 dark:bg-green-900/20 border-green-300 dark:border-green-700"
      case "error":
        return "bg-red-50 dark:bg-red-900/20 border-red-300 dark:border-red-700"
      case "warning":
        return "bg-yellow-50 dark:bg-yellow-900/20 border-yellow-300 dark:border-yellow-700"
      default:
        return "bg-blue-50 dark:bg-blue-900/20 border-blue-300 dark:border-blue-700"
    }
  }

  const getTypeIcon = (type: string) => {
    switch (type) {
      case "success":
        return "✓"
      case "error":
        return "✕"
      case "warning":
        return "!"
      default:
        return "ℹ"
    }
  }

  return (
    <div className="absolute bottom-20 right-4 w-80 bg-white dark:bg-slate-800 border border-gray-300 dark:border-slate-700 rounded-lg shadow-xl z-50 max-h-96 overflow-y-auto animate-in slide-in-from-bottom-4 duration-200">
      <div className="p-4 border-b border-gray-300 dark:border-slate-700 flex items-center justify-between">
        <h3 className="font-semibold">Notifications</h3>
        <button
          onClick={onClear}
          className="text-gray-500 hover:text-gray-700 dark:hover:text-gray-300 transition-colors"
        >
          <X size={18} />
        </button>
      </div>
      {notifications.length === 0 ? (
        <div className="p-6 text-center text-gray-500 dark:text-gray-400">No notifications</div>
      ) : (
        <div className="p-2 space-y-2">
          {notifications.map((notif) => (
            <div
              key={notif.id}
              className={`p-3 rounded-lg border ${getTypeColor(notif.type)} animate-in slide-in-from-top-2 duration-150`}
            >
              <div className="flex items-start gap-2">
                <span className="text-sm font-bold mt-0.5">{getTypeIcon(notif.type)}</span>
                <div className="flex-1">
                  <p className="font-medium text-sm">{notif.title}</p>
                  <p className="text-xs text-gray-600 dark:text-gray-400 mt-1">{notif.message}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}
