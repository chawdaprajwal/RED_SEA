"use client"

import type React from "react"

import { useRef, useState, useEffect } from "react"
import { X, Minus, Maximize2 } from "lucide-react"

interface WindowProps {
  id: string
  title: string
  children: React.ReactNode
  minimized: boolean
  zIndex: number
  onClose: () => void
  onMinimize: () => void
  onFocus: () => void
}

export default function Window({ id, title, children, minimized, zIndex, onClose, onMinimize, onFocus }: WindowProps) {
  const windowRef = useRef<HTMLDivElement>(null)
  const titleBarRef = useRef<HTMLDivElement>(null)
  const [position, setPosition] = useState({ x: Math.random() * 200, y: Math.random() * 100 + 50 })
  const [size, setSize] = useState({ width: 700, height: 450 })
  const [isDragging, setIsDragging] = useState(false)
  const [dragStart, setDragStart] = useState({ x: 0, y: 0 })
  const [isResizing, setIsResizing] = useState(false)
  const [resizeStart, setResizeStart] = useState({ x: 0, y: 0, width: 0, height: 0 })
  const [isMaximized, setIsMaximized] = useState(false)
  const positionRef = useRef(position)
  const sizeRef = useRef(size)

  useEffect(() => {
    positionRef.current = position
  }, [position])

  useEffect(() => {
    sizeRef.current = size
  }, [size])

  useEffect(() => {
    const handleWindowResize = () => {
      if (isMaximized) {
        setSize({ width: window.innerWidth - 40, height: window.innerHeight - 100 })
      }
    }
    window.addEventListener("resize", handleWindowResize)
    return () => window.removeEventListener("resize", handleWindowResize)
  }, [isMaximized])

  const handleMouseDown = (e: React.MouseEvent) => {
    if (!titleBarRef.current?.contains(e.target as Node)) return
    onFocus()
    setIsDragging(true)
    setDragStart({ x: e.clientX - positionRef.current.x, y: e.clientY - positionRef.current.y })
  }

  const handleMouseMove = (e: React.MouseEvent) => {
    if (isDragging) {
      setPosition({
        x: e.clientX - dragStart.x,
        y: e.clientY - dragStart.y,
      })
    }

    if (isResizing) {
      const deltaX = e.clientX - resizeStart.x
      const deltaY = e.clientY - resizeStart.y
      setSize({
        width: Math.max(400, resizeStart.width + deltaX),
        height: Math.max(250, resizeStart.height + deltaY),
      })
    }
  }

  const handleResizeStart = (e: React.MouseEvent) => {
    onFocus()
    e.preventDefault()
    setIsResizing(true)
    setResizeStart({ x: e.clientX, y: e.clientY, width: sizeRef.current.width, height: sizeRef.current.height })
  }

  const toggleMaximize = () => {
    if (isMaximized) {
      setIsMaximized(false)
      setPosition({ x: 50, y: 50 })
      setSize({ width: 700, height: 450 })
    } else {
      setIsMaximized(true)
      setPosition({ x: 20, y: 50 })
      setSize({ width: window.innerWidth - 40, height: window.innerHeight - 100 })
    }
  }

  return (
    <>
      {!minimized && (
        <div
          ref={windowRef}
          style={{
            left: `${position.x}px`,
            top: `${position.y}px`,
            width: `${size.width}px`,
            height: `${size.height}px`,
            zIndex,
            willChange: isDragging || isResizing ? "transform" : "auto",
          }}
          onMouseDown={() => onFocus()}
          onMouseMove={handleMouseMove}
          onMouseUp={() => {
            setIsDragging(false)
            setIsResizing(false)
          }}
          onMouseLeave={() => {
            setIsDragging(false)
            setIsResizing(false)
          }}
          className="absolute bg-white dark:bg-slate-800 border border-gray-300 dark:border-slate-600 rounded-xl shadow-2xl flex flex-col animate-in zoom-in-95 duration-300 backdrop-blur-sm hover:shadow-3xl transition-shadow"
        >
          <div
            ref={titleBarRef}
            onMouseDown={handleMouseDown}
            className="flex items-center justify-between h-11 px-4 bg-gradient-to-r from-blue-600 to-blue-700 dark:from-slate-700 dark:to-slate-800 rounded-t-xl cursor-move select-none border-b border-blue-800 dark:border-slate-600 hover:from-blue-700 hover:to-blue-800 transition-all shadow-md active:shadow-lg"
          >
            <span className="text-white font-semibold text-sm truncate">{title}</span>
            <div className="flex gap-1">
              <button
                onClick={toggleMaximize}
                className="p-1.5 hover:bg-white/20 rounded transition-colors active:scale-90 duration-100"
                title="Maximize"
              >
                <Maximize2 size={16} className="text-white" />
              </button>
              <button
                onClick={onMinimize}
                className="p-1.5 hover:bg-white/20 rounded transition-colors active:scale-90 duration-100"
                title="Minimize"
              >
                <Minus size={16} className="text-white" />
              </button>
              <button
                onClick={onClose}
                className="p-1.5 hover:bg-red-500 rounded transition-colors active:scale-90 duration-100"
                title="Close"
              >
                <X size={16} className="text-white" />
              </button>
            </div>
          </div>

          {/* Content - with optimized scrolling */}
          <div className="flex-1 overflow-auto scroll-smooth">{children}</div>

          {/* Resize Handle */}
          {!isMaximized && (
            <div
              onMouseDown={handleResizeStart}
              className="absolute bottom-0 right-0 w-6 h-6 bg-gradient-to-tl from-blue-600 to-transparent dark:from-slate-700 cursor-se-resize rounded-bl-lg opacity-70 hover:opacity-100 transition-opacity active:opacity-100"
            />
          )}
        </div>
      )}
    </>
  )
}
