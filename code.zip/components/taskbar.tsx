"use client"

import { useState, useEffect } from "react"
import { Bell, LogOut, Volume2, Power, RotateCcw, Moon, Search, X, Wifi, WifiOff } from "lucide-react"

interface TaskbarProps {
  openApps: Array<{ id: string; type: string; title: string; minimized: boolean }>
  onOpenApp: (type: string, title: string) => void
  onToggleMinimize: (id: string) => void
  notificationCount: number
  onToggleNotifications: () => void
  onShutdown?: () => void
}

const appLaunchers = [
  { type: "file-explorer", title: "File Explorer", icon: "📁" },
  { type: "email", title: "Email", icon: "✉️" },
  { type: "chat", title: "Messages", icon: "💬" },
  { type: "admin", title: "Admin Dashboard", icon: "⚙️" },
  { type: "chrome", title: "Chrome", icon: "🌐" },
  { type: "whatsapp", title: "WhatsApp", icon: "💬" },
  { type: "facebook", title: "Facebook", icon: "📘" },
  { type: "linkedin", title: "LinkedIn", icon: "💼" },
  { type: "telegram", title: "Telegram", icon: "✈️" },
  { type: "twitter", title: "Twitter", icon: "𝕏" },
  { type: "recycle-bin", title: "Recycle Bin", icon: "🗑️" },
  { type: "this-pc", title: "This PC", icon: "💻" },
  { type: "messages", title: "Messages", icon: "💬" },
]

const pinnedApps = [
  { type: "chrome", title: "Chrome", icon: "🌐" },
  { type: "whatsapp", title: "WhatsApp", icon: "💬" },
  { type: "linkedin", title: "LinkedIn", icon: "💼" },
]

export default function Taskbar({
  openApps,
  onOpenApp,
  onToggleMinimize,
  notificationCount,
  onToggleNotifications,
  onShutdown,
}: TaskbarProps) {
  const [showStartMenu, setShowStartMenu] = useState(false)
  const [time, setTime] = useState<string>("")
  const [searchQuery, setSearchQuery] = useState("")
  const [searchOpen, setSearchOpen] = useState(false)
  const [wifiConnected, setWifiConnected] = useState(true)
  const [volume, setVolume] = useState(70)
  const [showVolumeControl, setShowVolumeControl] = useState(false)
  const [showWifiMenu, setShowWifiMenu] = useState(false)

  useEffect(() => {
    const updateTime = () => {
      const now = new Date()
      setTime(now.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }))
    }
    updateTime()
    const interval = setInterval(updateTime, 1000)
    return () => clearInterval(interval)
  }, [])

  const handleLaunchApp = (type: string, title: string) => {
    const exists = openApps.find((app) => app.type === type)
    if (exists && exists.minimized) {
      onToggleMinimize(exists.id)
    } else if (!exists) {
      onOpenApp(type, title)
    }
    setShowStartMenu(false)
    setSearchQuery("")
  }

  const filteredApps = appLaunchers.filter(
    (app) =>
      app.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      app.type.toLowerCase().includes(searchQuery.toLowerCase()),
  )

  const handleShutdown = () => {
    if (window.confirm("Are you sure you want to shut down?")) {
      if (onShutdown) {
        onShutdown()
      }
      setShowStartMenu(false)
    }
  }

  const handleRestart = () => {
    if (window.confirm("Are you sure you want to restart?")) {
      if (onShutdown) {
        onShutdown()
      }
      setTimeout(() => {
        window.location.reload()
      }, 500)
      setShowStartMenu(false)
    }
  }

  const handleSleep = () => {
    openApps.forEach((app) => {
      if (!app.minimized) {
        onToggleMinimize(app.id)
      }
    })
    setShowStartMenu(false)
    alert("System entering sleep mode. Click any key to wake up.")
  }

  return (
    <>
      <div className="h-14 sm:h-16 bg-gray-100 dark:bg-slate-900 border-t border-gray-300 dark:border-slate-700 flex items-center justify-between px-2 sm:px-4 gap-2 sm:gap-3 shadow-lg flex-wrap sm:flex-nowrap">
        {/* Start Button */}
        <div className="relative flex-shrink-0">
          <button
            onClick={() => setShowStartMenu(!showStartMenu)}
            className="p-2 rounded-lg bg-gradient-to-br from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800 text-white flex items-center gap-2 font-semibold transition-all active:scale-95"
            title="Start Menu"
          >
            <svg className="w-4 h-4 sm:w-5 sm:h-5" fill="currentColor" viewBox="0 0 24 24">
              <rect x="3" y="3" width="8" height="8" />
              <rect x="13" y="3" width="8" height="8" />
              <rect x="3" y="13" width="8" height="8" />
              <rect x="13" y="13" width="8" height="8" />
            </svg>
            <span className="hidden md:inline text-sm sm:text-base">Start</span>
          </button>

          {/* Start Menu */}
          {showStartMenu && (
            <div className="absolute bottom-14 sm:bottom-20 left-0 bg-white dark:bg-slate-800 border border-gray-300 dark:border-slate-700 rounded-lg shadow-xl w-60 sm:w-72 z-50 max-h-[60vh] sm:max-h-[70vh] overflow-hidden flex flex-col">
              {/* Search Bar in Start Menu */}
              <div className="p-2 sm:p-3 border-b border-gray-200 dark:border-slate-700">
                <div className="relative">
                  <Search size={14} className="absolute left-2 top-2.5 text-gray-400" />
                  <input
                    type="text"
                    placeholder="Search apps..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="w-full pl-7 pr-2 py-1.5 sm:py-2 border border-gray-300 dark:border-slate-600 rounded bg-white dark:bg-slate-700 text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
              </div>

              {/* Apps List */}
              <div className="overflow-y-auto scroll-smooth flex-1 p-2">
                <h3 className="px-2 sm:px-3 py-1.5 sm:py-2 text-xs font-semibold text-gray-500 dark:text-gray-400">
                  APPLICATIONS
                </h3>
                {filteredApps.length > 0 ? (
                  filteredApps.map((app) => (
                    <button
                      key={app.type}
                      onClick={() => handleLaunchApp(app.type, app.title)}
                      className="w-full text-left px-2 sm:px-3 py-1.5 sm:py-2 rounded hover:bg-blue-100 dark:hover:bg-slate-700 flex items-center gap-2 transition-colors active:bg-blue-200 dark:active:bg-slate-600"
                    >
                      <span className="text-base sm:text-lg">{app.icon}</span>
                      <span className="text-xs sm:text-sm font-medium truncate">{app.title}</span>
                    </button>
                  ))
                ) : (
                  <p className="px-2 sm:px-3 py-2 text-xs sm:text-sm text-gray-500 dark:text-gray-400">No apps found</p>
                )}
              </div>

              {/* System Controls */}
              <div className="border-t border-gray-200 dark:border-slate-700 p-1.5 sm:p-2 flex gap-1 sm:gap-2">
                <button
                  onClick={handleSleep}
                  className="flex-1 flex items-center justify-center gap-1 px-1.5 sm:px-2 py-1.5 sm:py-2 rounded hover:bg-yellow-100 dark:hover:bg-yellow-900/30 text-yellow-700 dark:text-yellow-400 transition-colors text-xs sm:text-sm font-medium active:scale-95"
                  title="Sleep - Minimizes all windows"
                >
                  <Moon size={14} className="sm:w-4 sm:h-4" />
                  <span className="hidden sm:inline">Sleep</span>
                </button>
                <button
                  onClick={handleRestart}
                  className="flex-1 flex items-center justify-center gap-1 px-1.5 sm:px-2 py-1.5 sm:py-2 rounded hover:bg-blue-100 dark:hover:bg-blue-900/30 text-blue-700 dark:text-blue-400 transition-colors text-xs sm:text-sm font-medium active:scale-95"
                  title="Restart - Restarts the system"
                >
                  <RotateCcw size={14} className="sm:w-4 sm:h-4" />
                  <span className="hidden sm:inline">Restart</span>
                </button>
                <button
                  onClick={handleShutdown}
                  className="flex-1 flex items-center justify-center gap-1 px-1.5 sm:px-2 py-1.5 sm:py-2 rounded hover:bg-red-100 dark:hover:bg-red-900/30 text-red-700 dark:text-red-400 transition-colors text-xs sm:text-sm font-medium active:scale-95"
                  title="Shutdown - Powers off the system"
                >
                  <Power size={14} className="sm:w-4 sm:h-4" />
                  <span className="hidden sm:inline">Shut Down</span>
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Search Bar - Responsive */}
        <div className="hidden lg:flex flex-shrink-0">
          {searchOpen ? (
            <div className="relative flex items-center gap-1">
              <Search size={14} className="absolute left-2 text-gray-400" />
              <input
                type="text"
                placeholder="Search..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-7 pr-2 py-1 border border-gray-300 dark:border-slate-600 rounded bg-white dark:bg-slate-700 text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 w-32 sm:w-40"
                autoFocus
              />
              <button
                onClick={() => {
                  setSearchOpen(false)
                  setSearchQuery("")
                }}
                className="p-1 hover:bg-gray-200 dark:hover:bg-slate-700 rounded transition-colors"
                title="Close search"
              >
                <X size={14} />
              </button>
            </div>
          ) : (
            <button
              onClick={() => setSearchOpen(true)}
              className="p-2 hover:bg-gray-200 dark:hover:bg-slate-800 rounded-lg transition-colors"
              title="Open search"
            >
              <Search size={16} />
            </button>
          )}
        </div>

        {/* Pinned Apps - Responsive */}
        <div className="flex gap-1 flex-shrink-0 hidden sm:flex">
          {pinnedApps.map((app) => (
            <button
              key={app.type}
              onClick={() => handleLaunchApp(app.type, app.title)}
              className="p-1.5 sm:p-2 hover:bg-gray-200 dark:hover:bg-slate-700 rounded-lg transition-colors text-base sm:text-lg active:scale-95"
              title={app.title}
            >
              {app.icon}
            </button>
          ))}
        </div>

        {/* Open Apps Buttons - Responsive */}
        <div className="flex gap-1 sm:gap-2 flex-1 overflow-x-auto max-w-xs sm:max-w-xl">
          {openApps
            .filter((app) => !app.minimized)
            .map((app) => (
              <button
                key={app.id}
                onClick={() => onToggleMinimize(app.id)}
                className="px-2 sm:px-3 py-1 sm:py-2 bg-white dark:bg-slate-700 border border-gray-300 dark:border-slate-600 rounded-lg text-xs sm:text-sm font-medium hover:bg-gray-50 dark:hover:bg-slate-600 transition-colors whitespace-nowrap active:scale-95"
              >
                {app.title}
              </button>
            ))}
        </div>

        {/* System Tray - Responsive */}
        <div className="flex items-center gap-1 sm:gap-3 ml-auto flex-shrink-0">
          {time && (
            <div className="px-2 sm:px-3 py-1 sm:py-2 text-xs sm:text-sm font-medium text-gray-700 dark:text-gray-200 bg-white dark:bg-slate-800 rounded-lg border border-gray-300 dark:border-slate-600 hidden sm:block">
              {time}
            </div>
          )}

          <button
            onClick={onToggleNotifications}
            className="relative p-1.5 sm:p-2 hover:bg-gray-200 dark:hover:bg-slate-800 rounded-lg transition-colors active:scale-95"
            title="Notifications"
          >
            <Bell size={16} className="sm:w-5 sm:h-5" />
            {notificationCount > 0 && (
              <span className="absolute top-0 right-0 w-4 h-4 bg-red-500 text-white text-xs rounded-full flex items-center justify-center font-bold">
                {notificationCount}
              </span>
            )}
          </button>

          <div className="relative group">
            <button
              onClick={() => setShowWifiMenu(!showWifiMenu)}
              className="p-1.5 sm:p-2 hover:bg-gray-200 dark:hover:bg-slate-800 rounded-lg transition-colors active:scale-95"
              title={wifiConnected ? "WiFi Connected" : "WiFi Disconnected"}
            >
              {wifiConnected ? (
                <Wifi size={16} className="sm:w-5 sm:h-5 text-blue-600" />
              ) : (
                <WifiOff size={16} className="sm:w-5 sm:h-5 text-gray-500" />
              )}
            </button>

            {/* WiFi Menu */}
            {showWifiMenu && (
              <div className="absolute bottom-14 right-0 bg-white dark:bg-slate-800 border border-gray-300 dark:border-slate-700 rounded-lg shadow-xl w-48 sm:w-56 p-2 sm:p-3 z-50">
                <h3 className="text-xs sm:text-sm font-semibold text-gray-700 dark:text-gray-200 mb-2 px-1">
                  WiFi Networks
                </h3>
                <div className="space-y-1 sm:space-y-2">
                  <button
                    onClick={() => {
                      setWifiConnected(true)
                      setShowWifiMenu(false)
                    }}
                    className={`w-full text-left px-2 sm:px-3 py-1.5 sm:py-2 rounded text-xs sm:text-sm transition-colors ${
                      wifiConnected
                        ? "bg-blue-100 dark:bg-blue-900/30 text-blue-700 dark:text-blue-400 font-medium"
                        : "hover:bg-gray-100 dark:hover:bg-slate-700 text-gray-700 dark:text-gray-300"
                    }`}
                  >
                    {wifiConnected && "✓ "} Home WiFi
                  </button>
                  <button
                    onClick={() => {
                      setWifiConnected(false)
                      setShowWifiMenu(false)
                    }}
                    className={`w-full text-left px-2 sm:px-3 py-1.5 sm:py-2 rounded text-xs sm:text-sm transition-colors ${
                      !wifiConnected
                        ? "bg-blue-100 dark:bg-blue-900/30 text-blue-700 dark:text-blue-400 font-medium"
                        : "hover:bg-gray-100 dark:hover:bg-slate-700 text-gray-700 dark:text-gray-300"
                    }`}
                  >
                    {!wifiConnected && "✓ "} Disconnect
                  </button>
                </div>
              </div>
            )}
          </div>

          <div className="relative group">
            <button
              onClick={() => setShowVolumeControl(!showVolumeControl)}
              className="p-1.5 sm:p-2 hover:bg-gray-200 dark:hover:bg-slate-800 rounded-lg transition-colors active:scale-95"
              title={`Volume: ${volume}%`}
            >
              <Volume2 size={16} className="sm:w-5 sm:h-5" />
            </button>

            {/* Volume Control Slider */}
            {showVolumeControl && (
              <div className="absolute bottom-14 right-0 bg-white dark:bg-slate-800 border border-gray-300 dark:border-slate-700 rounded-lg shadow-xl w-40 sm:w-48 p-3 sm:p-4 z-50">
                <div className="flex items-center gap-2">
                  <span className="text-xs sm:text-sm font-medium text-gray-700 dark:text-gray-200">Volume</span>
                  <span className="text-xs sm:text-sm font-semibold text-blue-600 dark:text-blue-400 ml-auto">
                    {volume}%
                  </span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="100"
                  value={volume}
                  onChange={(e) => setVolume(Number(e.target.value))}
                  className="w-full mt-2 sm:mt-3 cursor-pointer accent-blue-600"
                />
              </div>
            )}
          </div>

          <button
            className="p-1.5 sm:p-2 hover:bg-gray-200 dark:hover:bg-slate-800 rounded-lg transition-colors active:scale-95"
            title="Logout"
          >
            <LogOut size={16} className="sm:w-5 sm:h-5" />
          </button>
        </div>
      </div>
    </>
  )
}
