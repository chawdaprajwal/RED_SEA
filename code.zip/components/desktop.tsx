"use client"

import type React from "react"

import { useState } from "react"
import Window from "./window"
import FileExplorer from "./apps/file-explorer"
import EmailClient from "./apps/email-client"
import ChatApp from "./apps/chat-app"
import AdminDashboard from "./apps/admin-dashboard"
import ChromeBrowser from "./apps/chrome-browser"
import SocialMedia from "./apps/social-media"
import SystemApp from "./apps/system-apps"
import WhatsApp from "./apps/whatsapp"
import MessagesApp from "./apps/messages"

const desktopIcons = [
  { id: "file", icon: "📁", label: "Files", type: "file-explorer" },
  { id: "email", icon: "✉️", label: "Email", type: "email" },
  { id: "messages", icon: "💬", label: "Messages", type: "messages" },
  { id: "admin", icon: "⚙️", label: "Admin", type: "admin" },
  { id: "chrome", icon: "🌐", label: "Chrome", type: "chrome" },
  { id: "whatsapp", icon: "💬", label: "WhatsApp", type: "whatsapp" },
  { id: "recycle", icon: "🗑️", label: "Recycle Bin", type: "recycle-bin" },
  { id: "pc", icon: "💻", label: "This PC", type: "this-pc" },
  { id: "linkedin", icon: "💼", label: "LinkedIn", type: "linkedin" },
  { id: "facebook", icon: "📘", label: "Facebook", type: "facebook" },
  { id: "telegram", icon: "✈️", label: "Telegram", type: "telegram" },
  { id: "twitter", icon: "𝕏", label: "Twitter", type: "twitter" },
]

interface DesktopProps {
  openApps: Array<{ id: string; type: string; title: string; minimized: boolean }>
  onCloseApp: (id: string) => void
  onToggleMinimize: (id: string) => void
  onOpenApp?: (type: string, title: string) => void
}

export default function Desktop({ openApps, onCloseApp, onToggleMinimize, onOpenApp }: DesktopProps) {
  const [zIndex, setZIndex] = useState<Record<string, number>>({})
  const [contextMenu, setContextMenu] = useState<{ x: number; y: number } | null>(null)

  const handleWindowFocus = (appId: string) => {
    setZIndex((prev) => ({ ...prev, [appId]: Math.max(...Object.values(prev), 100) + 1 }))
  }

  const handleDesktopIconClick = (type: string, label: string) => {
    if (onOpenApp) {
      onOpenApp(type, label)
    }
  }

  const handleContextMenu = (e: React.MouseEvent) => {
    e.preventDefault()
    setContextMenu({ x: e.clientX, y: e.clientY })
  }

  const renderAppContent = (type: string) => {
    switch (type) {
      case "file-explorer":
        return <FileExplorer />
      case "email":
        return <EmailClient />
      case "chat":
        return <ChatApp />
      case "admin":
        return <AdminDashboard />
      case "chrome":
        return <ChromeBrowser />
      case "whatsapp":
        return <WhatsApp />
      case "messages":
        return <MessagesApp />
      case "facebook":
      case "linkedin":
      case "telegram":
      case "twitter":
        return <SocialMedia platform={type} />
      case "recycle-bin":
        return <SystemApp type="recycle-bin" />
      case "this-pc":
        return <SystemApp type="this-pc" />
      default:
        return null
    }
  }

  return (
    <div
      className="flex-1 relative overflow-hidden desktop-wallpaper dark:desktop-wallpaper"
      onContextMenu={handleContextMenu}
      onClick={() => setContextMenu(null)}
    >
      <div className="absolute top-6 left-6 z-10 max-h-[calc(100%-3rem)] overflow-y-auto">
        <div className="grid grid-cols-2 gap-3 w-max">
          {desktopIcons.map((icon) => (
            <button
              key={icon.id}
              onClick={() => handleDesktopIconClick(icon.type, icon.label)}
              className="flex flex-col items-center gap-1 p-1 rounded-lg hover:bg-white/30 dark:hover:bg-black/30 transition-all group active:scale-95 duration-150 backdrop-blur-sm hover:backdrop-blur-md w-16"
              title={icon.label}
            >
              <div className="text-3xl group-hover:scale-110 transition-transform duration-200 drop-shadow-lg">
                {icon.icon}
              </div>
              <span className="text-[9px] text-white dark:text-gray-100 text-center max-w-14 font-medium drop-shadow-md line-clamp-2">
                {icon.label}
              </span>
            </button>
          ))}
        </div>
      </div>

      {/* Open Windows */}
      <div className="relative w-full h-full">
        {openApps.map((app, index) => (
          <Window
            key={app.id}
            id={app.id}
            title={app.title}
            minimized={app.minimized}
            zIndex={zIndex[app.id] || 10 + index}
            onClose={() => onCloseApp(app.id)}
            onMinimize={() => onToggleMinimize(app.id)}
            onFocus={() => handleWindowFocus(app.id)}
          >
            {renderAppContent(app.type)}
          </Window>
        ))}
      </div>

      {/* Context Menu */}
      {contextMenu && (
        <div
          style={{ position: "fixed", left: `${contextMenu.x}px`, top: `${contextMenu.y}px` }}
          className="bg-white dark:bg-slate-800 border border-gray-300 dark:border-slate-700 rounded-lg shadow-2xl z-50 min-w-48 animate-in zoom-in-95 duration-150 backdrop-blur-sm"
        >
          <button className="w-full text-left px-4 py-2 hover:bg-gray-100 dark:hover:bg-slate-700 transition-colors text-sm font-medium">
            Refresh Desktop
          </button>
          <button className="w-full text-left px-4 py-2 hover:bg-gray-100 dark:hover:bg-slate-700 transition-colors text-sm font-medium">
            New Folder
          </button>
          <hr className="border-gray-200 dark:border-slate-700 my-1" />
          <button className="w-full text-left px-4 py-2 hover:bg-gray-100 dark:hover:bg-slate-700 transition-colors text-sm font-medium">
            Properties
          </button>
        </div>
      )}
    </div>
  )
}
