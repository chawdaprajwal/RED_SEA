"use client"

import type React from "react"

import { useState } from "react"
import { Mail, Trash2, Archive, Star, Send, X } from "lucide-react"

interface EmailMessage {
  id: string
  from: string
  subject: string
  preview: string
  timestamp: string
  read: boolean
  starred?: boolean
}

const mockEmails: EmailMessage[] = [
  {
    id: "1",
    from: "team@company.com",
    subject: "Q4 Planning Meeting - Tomorrow at 2PM",
    preview:
      "Hi, Just sending a reminder about tomorrow's Q4 planning meeting. Please come prepared with your quarterly goals and metrics.",
    timestamp: "2:30 PM",
    read: false,
    starred: false,
  },
  {
    id: "2",
    from: "hr@company.com",
    subject: "Updated Benefits Information",
    preview:
      "Please review the attached updated benefits information for 2024. Changes include expanded health coverage...",
    timestamp: "1:15 PM",
    read: true,
    starred: true,
  },
  {
    id: "3",
    from: "project-manager@company.com",
    subject: "Project Alpha - Status Update",
    preview: "Great progress this week! We're on track to complete Phase 2 by the end of this month...",
    timestamp: "Nov 6",
    read: true,
    starred: false,
  },
]

export default function EmailClient() {
  const [selectedEmail, setSelectedEmail] = useState<string | null>(mockEmails[0].id)
  const [emails, setEmails] = useState<EmailMessage[]>(mockEmails)
  const [filter, setFilter] = useState<"all" | "unread" | "starred">("all")
  const [showCompose, setShowCompose] = useState(false)
  const [composeData, setComposeData] = useState({ to: "", subject: "", body: "" })

  const toggleStarred = (id: string, e: React.MouseEvent) => {
    e.stopPropagation()
    setEmails(emails.map((e) => (e.id === id ? { ...e, starred: !e.starred } : e)))
  }

  const deleteEmail = (id: string) => {
    setEmails(emails.filter((e) => e.id !== id))
    if (selectedEmail === id) setSelectedEmail(null)
  }

  const handleSendEmail = (e: React.FormEvent) => {
    e.preventDefault()
    if (composeData.to && composeData.subject) {
      const newEmail: EmailMessage = {
        id: Date.now().toString(),
        from: "you@company.com",
        subject: `Re: ${composeData.subject}`,
        preview: composeData.body.substring(0, 100),
        timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
        read: true,
        starred: false,
      }
      setEmails([newEmail, ...emails])
      setShowCompose(false)
      setComposeData({ to: "", subject: "", body: "" })
    }
  }

  const filteredEmails = emails.filter((e) => {
    if (filter === "unread") return !e.read
    if (filter === "starred") return e.starred
    return true
  })

  const currentEmail = emails.find((e) => e.id === selectedEmail)

  return (
    <div className="flex h-full bg-white dark:bg-slate-800">
      <div className="w-full sm:w-96 border-r border-gray-300 dark:border-slate-600 flex flex-col">
        <div className="h-14 bg-gradient-to-r from-blue-600 to-blue-700 text-white flex items-center justify-between px-4 font-semibold border-b border-blue-800 dark:border-slate-600">
          <div className="flex items-center">
            <Mail size={18} className="mr-2" />
            Inbox
          </div>
          <button
            onClick={() => setShowCompose(true)}
            className="px-3 py-1 bg-white text-blue-600 rounded text-xs font-bold hover:bg-blue-50 transition-colors active:scale-95"
          >
            Compose
          </button>
        </div>

        <div className="flex border-b border-gray-300 dark:border-slate-600">
          {["all", "unread", "starred"].map((f) => (
            <button
              key={f}
              onClick={() => setFilter(f as typeof filter)}
              className={`flex-1 px-3 py-2 text-xs font-medium transition-colors ${
                filter === f
                  ? "bg-blue-100 dark:bg-slate-700 text-blue-600 dark:text-blue-400 border-b-2 border-blue-600"
                  : "hover:bg-gray-100 dark:hover:bg-slate-700"
              }`}
            >
              {f.charAt(0).toUpperCase() + f.slice(1)}
            </button>
          ))}
        </div>

        <div className="flex-1 overflow-y-auto scroll-smooth">
          {filteredEmails.length > 0 ? (
            filteredEmails.map((email) => (
              <button
                key={email.id}
                onClick={() => setSelectedEmail(email.id)}
                className={`w-full text-left px-4 py-3 border-b border-gray-200 dark:border-slate-700 hover:bg-gray-50 dark:hover:bg-slate-700 transition-colors group ${
                  selectedEmail === email.id ? "bg-blue-50 dark:bg-slate-700" : ""
                } ${!email.read ? "bg-blue-50 dark:bg-slate-700" : ""}`}
              >
                <div className="flex items-start gap-2">
                  <button
                    onClick={(e) => toggleStarred(email.id, e)}
                    className={`flex-shrink-0 mt-1 transition-colors ${email.starred ? "text-yellow-500" : "text-gray-400"}`}
                  >
                    <Star size={14} fill={email.starred ? "currentColor" : "none"} />
                  </button>
                  <div className="flex-1 min-w-0">
                    <p className={`text-sm ${!email.read ? "font-bold" : "font-medium"} truncate`}>{email.from}</p>
                    <p className="text-xs text-gray-600 dark:text-gray-400 truncate">{email.subject}</p>
                  </div>
                </div>
              </button>
            ))
          ) : (
            <div className="p-4 text-center text-sm text-gray-500">No emails found</div>
          )}
        </div>
      </div>

      {/* Email View */}
      <div className="hidden sm:flex flex-1 flex-col">
        {currentEmail ? (
          <>
            <div className="h-16 border-b border-gray-300 dark:border-slate-600 px-6 flex items-center justify-between bg-gray-50 dark:bg-slate-700">
              <h3 className="font-semibold truncate flex-1">{currentEmail.subject}</h3>
              <div className="flex gap-2">
                <button className="p-2 hover:bg-gray-200 dark:hover:bg-slate-600 rounded transition-colors">
                  <Archive size={18} />
                </button>
                <button
                  onClick={() => deleteEmail(currentEmail.id)}
                  className="p-2 hover:bg-red-200 dark:hover:bg-red-900 rounded transition-colors text-red-600 dark:text-red-400"
                >
                  <Trash2 size={18} />
                </button>
              </div>
            </div>
            <div className="flex-1 overflow-y-auto scroll-smooth p-6">
              <p className="text-sm text-gray-600 dark:text-gray-400 mb-4">From: {currentEmail.from}</p>
              <p className="text-sm leading-relaxed">{currentEmail.preview}</p>
              <div className="mt-6 p-4 bg-gray-100 dark:bg-slate-800 rounded text-sm text-gray-600 dark:text-gray-400">
                Full email functionality would include file attachments and rich formatting.
              </div>
            </div>
          </>
        ) : (
          <div className="flex-1 flex items-center justify-center text-gray-500">Select an email to view</div>
        )}
      </div>

      {/* Compose Modal */}
      {showCompose && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white dark:bg-slate-800 rounded-lg shadow-2xl w-full max-w-md max-h-[90vh] flex flex-col animate-in zoom-in-95 duration-200">
            <div className="flex items-center justify-between h-12 px-4 bg-gradient-to-r from-blue-600 to-blue-700 text-white rounded-t-lg font-semibold">
              <span>New Email</span>
              <button onClick={() => setShowCompose(false)} className="p-1 hover:bg-white/20 rounded transition-colors">
                <X size={18} />
              </button>
            </div>
            <form onSubmit={handleSendEmail} className="flex-1 overflow-y-auto flex flex-col">
              <div className="flex-1 p-4 space-y-4">
                <div>
                  <label className="text-xs font-semibold text-gray-600 dark:text-gray-400">To:</label>
                  <input
                    type="email"
                    placeholder="recipient@example.com"
                    value={composeData.to}
                    onChange={(e) => setComposeData({ ...composeData, to: e.target.value })}
                    className="w-full mt-1 px-3 py-2 border border-gray-300 dark:border-slate-600 rounded-lg bg-white dark:bg-slate-700 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
                <div>
                  <label className="text-xs font-semibold text-gray-600 dark:text-gray-400">Subject:</label>
                  <input
                    type="text"
                    placeholder="Email subject"
                    value={composeData.subject}
                    onChange={(e) => setComposeData({ ...composeData, subject: e.target.value })}
                    className="w-full mt-1 px-3 py-2 border border-gray-300 dark:border-slate-600 rounded-lg bg-white dark:bg-slate-700 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
                <div>
                  <label className="text-xs font-semibold text-gray-600 dark:text-gray-400">Message:</label>
                  <textarea
                    placeholder="Type your message..."
                    value={composeData.body}
                    onChange={(e) => setComposeData({ ...composeData, body: e.target.value })}
                    className="w-full mt-1 px-3 py-2 border border-gray-300 dark:border-slate-600 rounded-lg bg-white dark:bg-slate-700 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 resize-none h-32"
                  />
                </div>
              </div>
              <div className="flex gap-2 p-4 border-t border-gray-300 dark:border-slate-600">
                <button
                  type="button"
                  onClick={() => setShowCompose(false)}
                  className="flex-1 px-3 py-2 border border-gray-300 dark:border-slate-600 rounded-lg text-sm font-medium hover:bg-gray-100 dark:hover:bg-slate-700 transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 px-3 py-2 bg-blue-600 text-white rounded-lg text-sm font-medium hover:bg-blue-700 transition-colors flex items-center justify-center gap-2 active:scale-95"
                >
                  <Send size={16} />
                  Send
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  )
}
