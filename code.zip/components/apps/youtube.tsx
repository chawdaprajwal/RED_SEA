"use client"

import { useState } from "react"
import { Search, Bell, User, Menu, Home, Compass, Play, Clock } from "lucide-react"

interface Video {
  id: string
  title: string
  channel: string
  views: string
  time: string
  thumbnail: string
}

const mockVideos: Video[] = [
  {
    id: "1",
    title: "Amazing Web Development Tutorial",
    channel: "Code Masters",
    views: "125K",
    time: "12:34",
    thumbnail: "🎥",
  },
  { id: "2", title: "React Hooks Explained", channel: "Dev Academy", views: "89K", time: "18:45", thumbnail: "⚛️" },
  {
    id: "3",
    title: "Next.js 15 Features Walkthrough",
    channel: "Tech Today",
    views: "234K",
    time: "25:10",
    thumbnail: "▶️",
  },
  {
    id: "4",
    title: "Building Full Stack Apps",
    channel: "Code Masters",
    views: "156K",
    time: "31:22",
    thumbnail: "🚀",
  },
  {
    id: "5",
    title: "TypeScript Advanced Patterns",
    channel: "Dev Academy",
    views: "67K",
    time: "22:15",
    thumbnail: "📘",
  },
  {
    id: "6",
    title: "Web Performance Optimization",
    channel: "Tech Today",
    views: "198K",
    time: "28:40",
    thumbnail: "⚡",
  },
]

export default function YouTube() {
  const [selectedVideo, setSelectedVideo] = useState<Video | null>(null)
  const [sidebarOpen, setSidebarOpen] = useState(true)
  const [searchQuery, setSearchQuery] = useState("")

  const filteredVideos = mockVideos.filter(
    (video) =>
      video.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      video.channel.toLowerCase().includes(searchQuery.toLowerCase()),
  )

  return (
    <div className="flex h-full bg-white dark:bg-slate-900">
      {/* Sidebar */}
      {sidebarOpen && (
        <div className="w-64 bg-white dark:bg-slate-800 border-r border-gray-200 dark:border-slate-700 p-4 overflow-y-auto scroll-smooth">
          <div className="flex items-center gap-2 mb-6">
            <span className="text-2xl font-bold text-red-600">▶</span>
            <span className="font-bold text-lg">YouTube</span>
          </div>
          <nav className="space-y-3">
            <button className="w-full flex items-center gap-3 px-3 py-2 rounded-lg hover:bg-gray-100 dark:hover:bg-slate-700 transition-colors">
              <Home size={20} />
              <span className="text-sm font-medium">Home</span>
            </button>
            <button className="w-full flex items-center gap-3 px-3 py-2 rounded-lg hover:bg-gray-100 dark:hover:bg-slate-700 transition-colors">
              <Compass size={20} />
              <span className="text-sm font-medium">Explore</span>
            </button>
            <button className="w-full flex items-center gap-3 px-3 py-2 rounded-lg hover:bg-gray-100 dark:hover:bg-slate-700 transition-colors">
              <Play size={20} />
              <span className="text-sm font-medium">Subscriptions</span>
            </button>
            <button className="w-full flex items-center gap-3 px-3 py-2 rounded-lg hover:bg-gray-100 dark:hover:bg-slate-700 transition-colors">
              <Clock size={20} />
              <span className="text-sm font-medium">Watch Later</span>
            </button>
          </nav>
          <hr className="my-4 border-gray-200 dark:border-slate-700" />
          <div className="text-xs font-semibold text-gray-500 mb-3">SUBSCRIPTIONS</div>
          <div className="space-y-2">
            {["Code Masters", "Dev Academy", "Tech Today"].map((channel) => (
              <button
                key={channel}
                className="w-full text-left px-3 py-2 text-sm hover:bg-gray-100 dark:hover:bg-slate-700 rounded transition-colors"
              >
                {channel}
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Main Content */}
      <div className="flex-1 flex flex-col">
        {/* Header */}
        <div className="bg-white dark:bg-slate-800 border-b border-gray-200 dark:border-slate-700 p-4 flex items-center gap-4">
          <button
            onClick={() => setSidebarOpen(!sidebarOpen)}
            className="p-2 hover:bg-gray-100 dark:hover:bg-slate-700 rounded transition-colors"
          >
            <Menu size={20} />
          </button>
          <div className="flex-1 flex items-center gap-2 bg-gray-100 dark:bg-slate-700 rounded-full px-4 py-2">
            <Search size={18} className="text-gray-500" />
            <input
              type="text"
              placeholder="Search"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="flex-1 bg-transparent outline-none text-sm"
            />
          </div>
          <button className="p-2 hover:bg-gray-100 dark:hover:bg-slate-700 rounded transition-colors">
            <Bell size={20} />
          </button>
          <button className="p-2 hover:bg-gray-100 dark:hover:bg-slate-700 rounded transition-colors">
            <User size={20} />
          </button>
        </div>

        {/* Video Grid */}
        {selectedVideo ? (
          <div className="flex-1 overflow-y-auto scroll-smooth p-6">
            <button
              onClick={() => setSelectedVideo(null)}
              className="mb-4 px-4 py-2 bg-gray-200 dark:bg-slate-700 rounded text-sm font-medium hover:bg-gray-300 dark:hover:bg-slate-600 transition-colors"
            >
              ← Back to Videos
            </button>
            <div className="bg-black rounded-lg aspect-video mb-6 flex items-center justify-center text-6xl">
              {selectedVideo.thumbnail}
            </div>
            <h1 className="text-2xl font-bold mb-2">{selectedVideo.title}</h1>
            <div className="flex items-center justify-between mb-6">
              <div>
                <p className="font-semibold">{selectedVideo.channel}</p>
                <p className="text-sm text-gray-500">{selectedVideo.views} views</p>
              </div>
              <button className="px-6 py-2 bg-red-600 text-white rounded-full font-medium hover:bg-red-700 transition-colors active:scale-95">
                Subscribe
              </button>
            </div>
          </div>
        ) : (
          <div className="flex-1 overflow-y-auto scroll-smooth p-6">
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
              {filteredVideos.map((video) => (
                <button
                  key={video.id}
                  onClick={() => setSelectedVideo(video)}
                  className="group cursor-pointer hover:scale-105 transition-transform duration-200"
                >
                  <div className="bg-gray-300 dark:bg-slate-700 rounded-lg aspect-video mb-2 flex items-center justify-center text-4xl group-hover:bg-gray-400 dark:group-hover:bg-slate-600 transition-colors">
                    {video.thumbnail}
                  </div>
                  <h3 className="text-sm font-medium line-clamp-2 text-left">{video.title}</h3>
                  <p className="text-xs text-gray-500 text-left">{video.channel}</p>
                  <p className="text-xs text-gray-500 text-left">
                    {video.views} views • {video.time}
                  </p>
                </button>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  )
}
