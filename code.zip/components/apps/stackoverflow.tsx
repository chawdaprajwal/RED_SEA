"use client"

import { useState } from "react"
import { Search, ThumbsUp, MessageSquare, Eye } from "lucide-react"

interface Question {
  id: string
  title: string
  description: string
  votes: number
  answers: number
  views: number
  tags: string[]
  author: string
}

const mockQuestions: Question[] = [
  {
    id: "1",
    title: "How to fetch data in Next.js App Router?",
    description:
      "I'm trying to fetch data from an API in my Next.js 13+ app router. What's the best way to handle this?",
    votes: 234,
    answers: 5,
    views: 1200,
    tags: ["next.js", "react", "javascript"],
    author: "John Dev",
  },
  {
    id: "2",
    title: "React Hooks vs Class Components",
    description:
      "What are the main differences between using React Hooks and Class Components? When should I use each?",
    votes: 567,
    answers: 8,
    views: 5600,
    tags: ["react", "hooks", "components"],
    author: "Jane Coder",
  },
  {
    id: "3",
    title: "Best practices for TypeScript in React",
    description: "What are the best practices for using TypeScript with React for large-scale applications?",
    votes: 123,
    answers: 3,
    views: 890,
    tags: ["typescript", "react", "best-practices"],
    author: "Mike Dev",
  },
  {
    id: "4",
    title: "How to optimize CSS in Tailwind?",
    description: "How can I ensure my Tailwind CSS is optimized for production builds?",
    votes: 89,
    answers: 2,
    views: 450,
    tags: ["tailwind", "css", "optimization"],
    author: "Sarah Code",
  },
]

export default function StackOverflow() {
  const [searchQuery, setSearchQuery] = useState("")
  const [selectedQuestion, setSelectedQuestion] = useState<Question | null>(null)

  const filteredQuestions = mockQuestions.filter(
    (q) =>
      q.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      q.description.toLowerCase().includes(searchQuery.toLowerCase()),
  )

  return (
    <div className="flex flex-col h-full bg-white dark:bg-slate-900">
      <div className="bg-white dark:bg-slate-800 border-b border-gray-200 dark:border-slate-700 p-4">
        <div className="flex items-center gap-4 mb-4">
          <span className="text-2xl font-bold text-orange-600">Stack Overflow</span>
        </div>

        <div className="flex items-center gap-2 bg-gray-100 dark:bg-slate-700 rounded px-4 py-2 border border-gray-300 dark:border-slate-600">
          <Search size={18} className="text-gray-400" />
          <input
            type="text"
            placeholder="Search questions..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="flex-1 bg-transparent outline-none text-sm"
          />
        </div>
      </div>

      <div className="flex-1 overflow-y-auto scroll-smooth">
        {selectedQuestion ? (
          <div className="p-6 max-w-4xl">
            <button
              onClick={() => setSelectedQuestion(null)}
              className="mb-4 px-4 py-2 bg-gray-200 dark:bg-slate-700 rounded text-sm font-medium hover:bg-gray-300 dark:hover:bg-slate-600 transition-colors"
            >
              ← Back to Questions
            </button>

            <div className="mb-6">
              <h1 className="text-3xl font-bold mb-4">{selectedQuestion.title}</h1>
              <div className="flex items-center gap-6 text-sm text-gray-600 dark:text-gray-400 mb-4">
                <div className="flex items-center gap-2">
                  <ThumbsUp size={16} />
                  {selectedQuestion.votes} votes
                </div>
                <div className="flex items-center gap-2">
                  <MessageSquare size={16} />
                  {selectedQuestion.answers} answers
                </div>
                <div className="flex items-center gap-2">
                  <Eye size={16} />
                  {selectedQuestion.views} views
                </div>
              </div>
            </div>

            <div className="bg-gray-50 dark:bg-slate-800 p-6 rounded-lg mb-6">
              <p className="text-gray-700 dark:text-gray-300 mb-4">{selectedQuestion.description}</p>
              <div className="flex flex-wrap gap-2">
                {selectedQuestion.tags.map((tag) => (
                  <span
                    key={tag}
                    className="px-3 py-1 bg-blue-100 dark:bg-blue-900 text-blue-700 dark:text-blue-300 text-xs rounded"
                  >
                    {tag}
                  </span>
                ))}
              </div>
            </div>

            <div className="bg-gray-50 dark:bg-slate-800 p-4 rounded-lg">
              <p className="text-sm">
                <span className="font-semibold">Asked by:</span> {selectedQuestion.author}
              </p>
            </div>
          </div>
        ) : (
          <div className="p-6">
            {filteredQuestions.length === 0 ? (
              <div className="text-center py-12">
                <p className="text-gray-500 dark:text-gray-400">No questions found</p>
              </div>
            ) : (
              <div className="space-y-4">
                {filteredQuestions.map((question) => (
                  <button
                    key={question.id}
                    onClick={() => setSelectedQuestion(question)}
                    className="w-full text-left p-4 border border-gray-200 dark:border-slate-700 rounded-lg hover:bg-gray-50 dark:hover:bg-slate-800 transition-colors"
                  >
                    <h3 className="text-lg font-semibold text-blue-600 dark:text-blue-400 hover:underline mb-2">
                      {question.title}
                    </h3>
                    <p className="text-gray-600 dark:text-gray-400 text-sm mb-3">{question.description}</p>
                    <div className="flex items-center justify-between">
                      <div className="flex flex-wrap gap-2">
                        {question.tags.map((tag) => (
                          <span
                            key={tag}
                            className="px-2 py-1 bg-blue-100 dark:bg-blue-900 text-blue-700 dark:text-blue-300 text-xs rounded"
                          >
                            {tag}
                          </span>
                        ))}
                      </div>
                      <div className="flex items-center gap-4 text-xs text-gray-500 dark:text-gray-400">
                        <div className="flex items-center gap-1">
                          <ThumbsUp size={14} />
                          {question.votes}
                        </div>
                        <div className="flex items-center gap-1">
                          <MessageSquare size={14} />
                          {question.answers}
                        </div>
                        <div className="flex items-center gap-1">
                          <Eye size={14} />
                          {question.views}
                        </div>
                      </div>
                    </div>
                  </button>
                ))}
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  )
}
