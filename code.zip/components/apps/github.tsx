"use client"

import { useState } from "react"
import { Search, Star, GitFork, Eye, Code } from "lucide-react"

interface Repository {
  id: string
  name: string
  description: string
  language: string
  stars: number
  forks: number
  watchers: number
}

const mockRepositories: Repository[] = [
  {
    id: "1",
    name: "next.js",
    description: "The React Framework for Production",
    language: "TypeScript",
    stars: 125000,
    forks: 26000,
    watchers: 5000,
  },
  {
    id: "2",
    name: "react",
    description: "A JavaScript library for building user interfaces",
    language: "JavaScript",
    stars: 220000,
    forks: 45000,
    watchers: 8000,
  },
  {
    id: "3",
    name: "tailwindcss",
    description: "A utility-first CSS framework",
    language: "TypeScript",
    stars: 85000,
    forks: 4300,
    watchers: 3000,
  },
  {
    id: "4",
    name: "vercel",
    description: "Vercel platform for deploying web apps",
    language: "TypeScript",
    stars: 12000,
    forks: 1500,
    watchers: 800,
  },
]

export default function GitHub() {
  const [searchQuery, setSearchQuery] = useState("")
  const [selectedRepo, setSelectedRepo] = useState<Repository | null>(null)

  const filteredRepos = mockRepositories.filter(
    (repo) =>
      repo.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      repo.description.toLowerCase().includes(searchQuery.toLowerCase()),
  )

  return (
    <div className="flex flex-col h-full bg-white dark:bg-slate-900">
      <div className="bg-white dark:bg-slate-800 border-b border-gray-200 dark:border-slate-700 p-4">
        <div className="flex items-center gap-4 mb-4">
          <span className="text-2xl font-bold">⚙️ GitHub</span>
        </div>

        <div className="flex items-center gap-2 bg-gray-100 dark:bg-slate-700 rounded px-4 py-2 border border-gray-300 dark:border-slate-600">
          <Search size={18} className="text-gray-400" />
          <input
            type="text"
            placeholder="Search repositories..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="flex-1 bg-transparent outline-none text-sm"
          />
        </div>
      </div>

      <div className="flex-1 overflow-y-auto scroll-smooth">
        {selectedRepo ? (
          <div className="p-6">
            <button
              onClick={() => setSelectedRepo(null)}
              className="mb-4 px-4 py-2 bg-gray-200 dark:bg-slate-700 rounded text-sm font-medium hover:bg-gray-300 dark:hover:bg-slate-600 transition-colors"
            >
              ← Back to Repositories
            </button>

            <div className="bg-gray-50 dark:bg-slate-800 rounded-lg p-6">
              <h1 className="text-3xl font-bold mb-2">{selectedRepo.name}</h1>
              <p className="text-gray-600 dark:text-gray-400 mb-4">{selectedRepo.description}</p>

              <div className="grid grid-cols-3 gap-4 mb-6">
                <div className="bg-white dark:bg-slate-700 p-4 rounded">
                  <div className="flex items-center gap-2 text-yellow-500 mb-2">
                    <Star size={18} />
                    <span className="font-semibold">{selectedRepo.stars.toLocaleString()}</span>
                  </div>
                  <p className="text-xs text-gray-600 dark:text-gray-400">Stars</p>
                </div>

                <div className="bg-white dark:bg-slate-700 p-4 rounded">
                  <div className="flex items-center gap-2 text-blue-500 mb-2">
                    <GitFork size={18} />
                    <span className="font-semibold">{selectedRepo.forks.toLocaleString()}</span>
                  </div>
                  <p className="text-xs text-gray-600 dark:text-gray-400">Forks</p>
                </div>

                <div className="bg-white dark:bg-slate-700 p-4 rounded">
                  <div className="flex items-center gap-2 text-green-500 mb-2">
                    <Eye size={18} />
                    <span className="font-semibold">{selectedRepo.watchers.toLocaleString()}</span>
                  </div>
                  <p className="text-xs text-gray-600 dark:text-gray-400">Watchers</p>
                </div>
              </div>

              <div className="bg-white dark:bg-slate-700 p-4 rounded mb-4">
                <p className="text-sm">
                  <span className="font-semibold">Language:</span> {selectedRepo.language}
                </p>
              </div>

              <button className="w-full px-6 py-3 bg-blue-600 text-white rounded font-medium hover:bg-blue-700 transition-colors active:scale-95">
                View on GitHub
              </button>
            </div>
          </div>
        ) : (
          <div className="p-6">
            {filteredRepos.length === 0 ? (
              <div className="text-center py-12">
                <p className="text-gray-500 dark:text-gray-400">No repositories found</p>
              </div>
            ) : (
              <div className="space-y-4">
                {filteredRepos.map((repo) => (
                  <button
                    key={repo.id}
                    onClick={() => setSelectedRepo(repo)}
                    className="w-full text-left p-4 border border-gray-200 dark:border-slate-700 rounded-lg hover:bg-gray-50 dark:hover:bg-slate-800 transition-colors"
                  >
                    <h3 className="text-lg font-semibold text-blue-600 dark:text-blue-400 hover:underline">
                      {repo.name}
                    </h3>
                    <p className="text-gray-600 dark:text-gray-400 text-sm mb-3">{repo.description}</p>
                    <div className="flex gap-6 text-xs text-gray-500 dark:text-gray-400">
                      <div className="flex items-center gap-1">
                        <Code size={14} />
                        {repo.language}
                      </div>
                      <div className="flex items-center gap-1">
                        <Star size={14} />
                        {repo.stars.toLocaleString()}
                      </div>
                      <div className="flex items-center gap-1">
                        <GitFork size={14} />
                        {repo.forks.toLocaleString()}
                      </div>
                    </div>
                  </button>
                ))}
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  )
}
