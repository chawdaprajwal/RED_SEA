"use client"

import { useState } from "react"
import { Search } from "lucide-react"

export default function Google() {
  const [searchQuery, setSearchQuery] = useState("")
  const [searchResults, setSearchResults] = useState<any[]>([])
  const [hasSearched, setHasSearched] = useState(false)

  const mockSearchResults = [
    {
      id: "1",
      title: "Web Development - MDN Web Docs",
      url: "developer.mozilla.org",
      snippet: "Learn web development with MDN Web Docs. Whether you are a beginner or an experienced developer...",
    },
    {
      id: "2",
      title: "React Official Website",
      url: "react.dev",
      snippet: "React is a JavaScript library for building user interfaces with reusable components...",
    },
    {
      id: "3",
      title: "Next.js by Vercel",
      url: "nextjs.org",
      snippet: "The React Framework for Production. Next.js gives you the best developer experience with all...",
    },
    {
      id: "4",
      title: "TypeScript Documentation",
      url: "typescriptlang.org",
      snippet:
        "TypeScript is JavaScript for application-scale development. TypeScript adds optional types to JavaScript...",
    },
    {
      id: "5",
      title: "Node.js Official",
      url: "nodejs.org",
      snippet: "Node.js is a JavaScript runtime built on Chrome's V8 JavaScript engine...",
    },
  ]

  const handleSearch = () => {
    if (searchQuery.trim()) {
      setSearchResults(mockSearchResults)
      setHasSearched(true)
    }
  }

  return (
    <div className="flex flex-col h-full bg-white dark:bg-slate-900">
      {!hasSearched ? (
        <div className="flex-1 flex flex-col items-center justify-center p-8">
          <div className="text-6xl font-bold mb-8">
            <span className="text-blue-500">G</span>
            <span className="text-red-500">o</span>
            <span className="text-yellow-500">o</span>
            <span className="text-blue-500">g</span>
            <span className="text-green-500">l</span>
            <span className="text-red-500">e</span>
          </div>

          <div className="w-full max-w-2xl mb-8">
            <div className="flex items-center gap-2 bg-white dark:bg-slate-800 rounded-full px-6 py-3 border border-gray-300 dark:border-slate-700 shadow-md hover:shadow-lg transition-shadow">
              <Search size={20} className="text-gray-400" />
              <input
                type="text"
                placeholder="Search Google"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                onKeyPress={(e) => {
                  if (e.key === "Enter") handleSearch()
                }}
                className="flex-1 bg-transparent outline-none text-lg"
                autoFocus
              />
            </div>
          </div>

          <div className="flex gap-4">
            <button
              onClick={handleSearch}
              className="px-6 py-2 bg-gray-200 dark:bg-slate-700 rounded hover:shadow-md transition-all active:scale-95"
            >
              Google Search
            </button>
            <button className="px-6 py-2 bg-gray-200 dark:bg-slate-700 rounded hover:shadow-md transition-all active:scale-95">
              I'm Feeling Lucky
            </button>
          </div>
        </div>
      ) : (
        <div className="flex flex-col h-full">
          <div className="bg-white dark:bg-slate-800 border-b border-gray-200 dark:border-slate-700 p-4">
            <div className="flex items-center gap-4 mb-4">
              <div className="text-3xl font-bold">
                <span className="text-blue-500">G</span>
                <span className="text-red-500">o</span>
                <span className="text-yellow-500">o</span>
                <span className="text-blue-500">g</span>
                <span className="text-green-500">l</span>
                <span className="text-red-500">e</span>
              </div>
            </div>

            <div className="flex items-center gap-2 bg-gray-100 dark:bg-slate-700 rounded-full px-4 py-2 border border-gray-300 dark:border-slate-600">
              <Search size={18} className="text-gray-400" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                onKeyPress={(e) => {
                  if (e.key === "Enter") handleSearch()
                }}
                className="flex-1 bg-transparent outline-none text-sm"
              />
            </div>
          </div>

          <div className="flex-1 overflow-y-auto scroll-smooth p-8">
            <div className="max-w-3xl">
              <p className="text-gray-600 dark:text-gray-400 mb-6">About {mockSearchResults.length} results</p>
              {searchResults.map((result) => (
                <div
                  key={result.id}
                  className="mb-6 hover:bg-gray-50 dark:hover:bg-slate-800 p-2 rounded transition-colors cursor-pointer"
                >
                  <div className="text-sm text-green-700 dark:text-green-400 mb-1">{result.url}</div>
                  <h3 className="text-lg font-semibold text-blue-700 dark:text-blue-400 hover:underline cursor-pointer mb-1">
                    {result.title}
                  </h3>
                  <p className="text-gray-700 dark:text-gray-300 text-sm">{result.snippet}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
