"use client"

import { useState, useRef, useEffect } from "react"
import { Send, Paperclip, Smile, Search } from "lucide-react"

interface Message {
  id: string
  sender: string
  text: string
  timestamp: string
  isOwn: boolean
}

interface Conversation {
  id: string
  name: string
  avatar: string
  lastMessage: string
  timestamp: string
  unread: number
  messages: Message[]
}

const mockConversations: Conversation[] = [
  {
    id: "1",
    name: "John Doe",
    avatar: "👨",
    lastMessage: "See you later!",
    timestamp: "2:30 PM",
    unread: 2,
    messages: [
      { id: "1", sender: "John", text: "Hi there!", timestamp: "2:15 PM", isOwn: false },
      { id: "2", sender: "You", text: "Hey! How are you?", timestamp: "2:20 PM", isOwn: true },
      { id: "3", sender: "John", text: "Great! What about you?", timestamp: "2:22 PM", isOwn: false },
      { id: "4", sender: "You", text: "All good here!", timestamp: "2:25 PM", isOwn: true },
      { id: "5", sender: "John", text: "See you later!", timestamp: "2:30 PM", isOwn: false },
    ],
  },
  {
    id: "2",
    name: "Sarah Smith",
    avatar: "👩",
    lastMessage: "That sounds perfect!",
    timestamp: "1:45 PM",
    unread: 0,
    messages: [
      { id: "1", sender: "Sarah", text: "Did you finish the project?", timestamp: "1:20 PM", isOwn: false },
      { id: "2", sender: "You", text: "Yes, just completed it!", timestamp: "1:30 PM", isOwn: true },
      { id: "3", sender: "Sarah", text: "That sounds perfect!", timestamp: "1:45 PM", isOwn: false },
    ],
  },
  {
    id: "3",
    name: "Mike Johnson",
    avatar: "👱",
    lastMessage: "Let me know soon!",
    timestamp: "12:00 PM",
    unread: 1,
    messages: [
      { id: "1", sender: "Mike", text: "Are you coming to the meeting?", timestamp: "11:45 AM", isOwn: false },
      { id: "2", sender: "You", text: "Yes, I will be there", timestamp: "11:50 AM", isOwn: true },
      { id: "3", sender: "Mike", text: "Let me know soon!", timestamp: "12:00 PM", isOwn: false },
    ],
  },
  {
    id: "4",
    name: "Emma Wilson",
    avatar: "👩‍🦰",
    lastMessage: "Talk later!",
    timestamp: "10:30 AM",
    unread: 0,
    messages: [
      { id: "1", sender: "Emma", text: "How was your day?", timestamp: "10:00 AM", isOwn: false },
      { id: "2", sender: "You", text: "Pretty good, thanks for asking!", timestamp: "10:15 AM", isOwn: true },
      { id: "3", sender: "Emma", text: "Talk later!", timestamp: "10:30 AM", isOwn: false },
    ],
  },
]

export default function MessagesApp() {
  const [conversations, setConversations] = useState<Conversation[]>(mockConversations)
  const [selectedConversation, setSelectedConversation] = useState<Conversation | null>(mockConversations[0])
  const [messageInput, setMessageInput] = useState("")
  const [searchInput, setSearchInput] = useState("")
  const messagesEndRef = useRef<HTMLDivElement>(null)

  const filteredConversations = conversations.filter((conv) =>
    conv.name.toLowerCase().includes(searchInput.toLowerCase()),
  )

  const handleSendMessage = () => {
    if (!messageInput.trim() || !selectedConversation) return

    const newMessage: Message = {
      id: Date.now().toString(),
      sender: "You",
      text: messageInput,
      timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
      isOwn: true,
    }

    const updatedConversations = conversations.map((conv) => {
      if (conv.id === selectedConversation.id) {
        return {
          ...conv,
          messages: [...conv.messages, newMessage],
          lastMessage: messageInput,
          timestamp: newMessage.timestamp,
        }
      }
      return conv
    })

    setConversations(updatedConversations)
    setSelectedConversation(updatedConversations.find((c) => c.id === selectedConversation.id) || null)
    setMessageInput("")

    // Simulate reply
    setTimeout(() => {
      const reply: Message = {
        id: (Date.now() + 1).toString(),
        sender: selectedConversation.name,
        text: "Thanks for the message!",
        timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
        isOwn: false,
      }

      const replyConversations = updatedConversations.map((conv) => {
        if (conv.id === selectedConversation.id) {
          return {
            ...conv,
            messages: [...conv.messages, reply],
            lastMessage: reply.text,
            timestamp: reply.timestamp,
          }
        }
        return conv
      })

      setConversations(replyConversations)
      setSelectedConversation(replyConversations.find((c) => c.id === selectedConversation.id) || null)
    }, 1500)
  }

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }, [selectedConversation?.messages])

  return (
    <div className="flex h-full bg-white dark:bg-slate-800">
      {/* Conversations List */}
      <div className="w-80 border-r border-gray-300 dark:border-slate-700 flex flex-col">
        {/* Search */}
        <div className="p-4 border-b border-gray-300 dark:border-slate-700">
          <div className="relative">
            <Search size={18} className="absolute left-3 top-3 text-gray-400" />
            <input
              type="text"
              value={searchInput}
              onChange={(e) => setSearchInput(e.target.value)}
              placeholder="Search conversations..."
              className="w-full pl-10 pr-4 py-2 bg-gray-100 dark:bg-slate-700 border border-gray-300 dark:border-slate-600 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-600"
            />
          </div>
        </div>

        {/* Conversations */}
        <div className="flex-1 overflow-y-auto scroll-smooth">
          {filteredConversations.map((conv) => (
            <button
              key={conv.id}
              onClick={() => setSelectedConversation(conv)}
              className={`w-full px-4 py-3 flex items-center gap-3 hover:bg-gray-100 dark:hover:bg-slate-700 transition-colors border-b border-gray-200 dark:border-slate-700 ${
                selectedConversation?.id === conv.id ? "bg-blue-50 dark:bg-slate-700" : ""
              }`}
            >
              <div className="relative">
                <div className="text-3xl">{conv.avatar}</div>
                {conv.unread > 0 && (
                  <div className="absolute -top-1 -right-1 bg-red-500 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center font-bold">
                    {conv.unread}
                  </div>
                )}
              </div>
              <div className="flex-1 min-w-0 text-left">
                <p className="font-semibold text-gray-900 dark:text-white">{conv.name}</p>
                <p className="text-xs text-gray-600 dark:text-gray-400 truncate">{conv.lastMessage}</p>
                <p className="text-xs text-gray-500 dark:text-gray-500">{conv.timestamp}</p>
              </div>
            </button>
          ))}
        </div>
      </div>

      {/* Chat Area */}
      <div className="flex-1 flex flex-col">
        {selectedConversation ? (
          <>
            {/* Chat Header */}
            <div className="flex-shrink-0 h-16 bg-gradient-to-r from-blue-600 to-blue-700 text-white flex items-center px-6 font-semibold border-b border-blue-800 dark:border-slate-600 shadow-md">
              <div className="text-2xl mr-3">{selectedConversation.avatar}</div>
              <div className="flex-1">
                <div>{selectedConversation.name}</div>
                <div className="text-xs font-normal text-blue-100">Active now</div>
              </div>
            </div>

            {/* Messages */}
            <div className="flex-1 overflow-y-auto scroll-smooth p-4 space-y-4">
              {selectedConversation.messages.map((msg) => (
                <div key={msg.id} className={`flex ${msg.isOwn ? "justify-end" : "justify-start"} gap-2`}>
                  {!msg.isOwn && <div className="text-2xl flex-shrink-0">{selectedConversation.avatar}</div>}
                  <div className={`flex flex-col ${msg.isOwn ? "items-end" : "items-start"}`}>
                    <div
                      className={`max-w-xs lg:max-w-md px-4 py-3 rounded-2xl transition-all hover:shadow-lg ${
                        msg.isOwn
                          ? "bg-blue-600 text-white rounded-br-none"
                          : "bg-gray-200 dark:bg-slate-700 text-gray-900 dark:text-white rounded-bl-none"
                      }`}
                    >
                      <p className="text-sm break-words">{msg.text}</p>
                    </div>
                    <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">{msg.timestamp}</p>
                  </div>
                  {msg.isOwn && <div className="text-2xl flex-shrink-0">👤</div>}
                </div>
              ))}
              <div ref={messagesEndRef} />
            </div>

            {/* Input Area */}
            <div className="flex-shrink-0 border-t border-gray-300 dark:border-slate-600 p-4 bg-gray-50 dark:bg-slate-700 space-y-2">
              <div className="flex items-center gap-2">
                <button
                  className="p-2 hover:bg-gray-200 dark:hover:bg-slate-600 rounded-lg transition-colors text-gray-600 dark:text-gray-400"
                  title="Attach file"
                >
                  <Paperclip size={18} />
                </button>
                <input
                  type="text"
                  value={messageInput}
                  onChange={(e) => setMessageInput(e.target.value)}
                  onKeyPress={(e) => e.key === "Enter" && handleSendMessage()}
                  placeholder="Type a message..."
                  className="flex-1 px-4 py-2 bg-white dark:bg-slate-800 border border-gray-300 dark:border-slate-600 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-600 transition-ring"
                />
                <button
                  className="p-2 hover:bg-gray-200 dark:hover:bg-slate-600 rounded-lg transition-colors text-gray-600 dark:text-gray-400"
                  title="Emoji"
                >
                  <Smile size={18} />
                </button>
                <button
                  onClick={handleSendMessage}
                  className="p-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition-colors active:scale-95"
                  title="Send message"
                >
                  <Send size={18} />
                </button>
              </div>
            </div>
          </>
        ) : (
          <div className="flex-1 flex items-center justify-center text-gray-500 dark:text-gray-400">
            Select a conversation to start messaging
          </div>
        )}
      </div>
    </div>
  )
}
