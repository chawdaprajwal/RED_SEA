"use client"

import { useState } from "react"
import { Users, Lock, Shield, Settings } from "lucide-react"

interface User {
  id: string
  name: string
  email: string
  role: string
  status: "active" | "inactive"
  lastLogin: string
}

const mockUsers: User[] = [
  { id: "1", name: "John Doe", email: "john@company.com", role: "Admin", status: "active", lastLogin: "2 min ago" },
  { id: "2", name: "Jane Smith", email: "jane@company.com", role: "User", status: "active", lastLogin: "1 hour ago" },
  { id: "3", name: "Bob Johnson", email: "bob@company.com", role: "User", status: "inactive", lastLogin: "3 days ago" },
  {
    id: "4",
    name: "Alice Brown",
    email: "alice@company.com",
    role: "Manager",
    status: "active",
    lastLogin: "30 min ago",
  },
]

export default function AdminDashboard() {
  const [users, setUsers] = useState<User[]>(mockUsers)
  const [activeTab, setActiveTab] = useState<"users" | "security" | "logs" | "settings">("users")
  const [selectedUser, setSelectedUser] = useState<string | null>(null)

  const toggleUserStatus = (id: string) => {
    setUsers(users.map((u) => (u.id === id ? { ...u, status: u.status === "active" ? "inactive" : "active" } : u)))
  }

  const deleteUser = (id: string) => {
    setUsers(users.filter((u) => u.id !== id))
    setSelectedUser(null)
  }

  return (
    <div className="flex h-full bg-white dark:bg-slate-800">
      <div className="w-full sm:w-64 bg-gray-50 dark:bg-slate-800 border-r border-gray-300 dark:border-slate-700 p-4 flex flex-col">
        <h2 className="font-bold text-lg mb-6 hidden sm:block">Admin Panel</h2>
        <nav className="space-y-2 flex sm:flex-col gap-2 sm:gap-0 overflow-x-auto sm:overflow-x-visible pb-2 sm:pb-0">
          {[
            { id: "users", icon: Users, label: "Users" },
            { id: "security", icon: Shield, label: "Security" },
            { id: "logs", icon: Lock, label: "Audit Logs" },
            { id: "settings", icon: Settings, label: "Settings" },
          ].map(({ id, icon: Icon, label }) => (
            <button
              key={id}
              onClick={() => setActiveTab(id as typeof activeTab)}
              className={`flex items-center gap-2 px-4 py-2 rounded-lg transition-colors whitespace-nowrap flex-shrink-0 sm:flex-shrink ${
                activeTab === id ? "bg-blue-600 text-white" : "hover:bg-gray-200 dark:hover:bg-slate-700"
              }`}
              title={label}
            >
              <Icon size={18} />
              <span className="hidden sm:inline">{label}</span>
            </button>
          ))}
        </nav>
      </div>

      {/* Content */}
      <div className="flex-1 overflow-y-auto scroll-smooth">
        {activeTab === "users" && (
          <div className="flex flex-col h-full">
            <div className="h-16 bg-gray-50 dark:bg-slate-800 border-b border-gray-300 dark:border-slate-700 flex items-center px-6 font-semibold flex-shrink-0">
              User Management
            </div>
            <div className="flex-1 overflow-x-auto p-4 sm:p-6">
              <div className="inline-block min-w-full">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b border-gray-300 dark:border-slate-700">
                      <th className="text-left py-3 px-2 sm:px-4 font-semibold">Name</th>
                      <th className="text-left py-3 px-2 sm:px-4 font-semibold hidden sm:table-cell">Email</th>
                      <th className="text-left py-3 px-2 sm:px-4 font-semibold">Role</th>
                      <th className="text-left py-3 px-2 sm:px-4 font-semibold">Status</th>
                      <th className="text-left py-3 px-2 sm:px-4 font-semibold">Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {users.map((user) => (
                      <tr
                        key={user.id}
                        onClick={() => setSelectedUser(user.id)}
                        className={`border-b border-gray-200 dark:border-slate-700 hover:bg-gray-50 dark:hover:bg-slate-700 cursor-pointer transition-colors ${
                          selectedUser === user.id ? "bg-blue-50 dark:bg-slate-700" : ""
                        }`}
                      >
                        <td className="py-3 px-2 sm:px-4 font-medium">{user.name}</td>
                        <td className="py-3 px-2 sm:px-4 text-gray-600 dark:text-gray-400 hidden sm:table-cell text-xs sm:text-sm">
                          {user.email}
                        </td>
                        <td className="py-3 px-2 sm:px-4">
                          <span className="px-2 py-1 rounded text-xs font-semibold bg-blue-100 dark:bg-blue-900 text-blue-800 dark:text-blue-200">
                            {user.role}
                          </span>
                        </td>
                        <td className="py-3 px-2 sm:px-4">
                          <button
                            onClick={(e) => {
                              e.stopPropagation()
                              toggleUserStatus(user.id)
                            }}
                            className={`px-2 py-1 rounded text-xs font-semibold transition-colors ${
                              user.status === "active"
                                ? "bg-green-100 dark:bg-green-900 text-green-800 dark:text-green-200 hover:bg-green-200"
                                : "bg-gray-100 dark:bg-gray-700 text-gray-800 dark:text-gray-200 hover:bg-gray-200"
                            }`}
                          >
                            {user.status}
                          </button>
                        </td>
                        <td className="py-3 px-2 sm:px-4">
                          <button
                            onClick={(e) => {
                              e.stopPropagation()
                              deleteUser(user.id)
                            }}
                            className="text-red-600 dark:text-red-400 hover:text-red-700 dark:hover:text-red-300 font-semibold text-xs"
                          >
                            Remove
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {activeTab === "security" && (
          <div className="p-6">
            <h3 className="text-lg font-semibold mb-4">Security Settings</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="p-4 bg-gray-50 dark:bg-slate-800 rounded-lg border border-gray-300 dark:border-slate-700 hover:border-blue-400 transition-colors cursor-pointer">
                <label className="flex items-center gap-3">
                  <input type="checkbox" defaultChecked className="w-4 h-4 cursor-pointer" />
                  <span className="font-medium">Two-Factor Authentication</span>
                </label>
              </div>
              <div className="p-4 bg-gray-50 dark:bg-slate-800 rounded-lg border border-gray-300 dark:border-slate-700 hover:border-blue-400 transition-colors cursor-pointer">
                <label className="flex items-center gap-3">
                  <input type="checkbox" defaultChecked className="w-4 h-4 cursor-pointer" />
                  <span className="font-medium">Session Timeout (30 min)</span>
                </label>
              </div>
              <div className="p-4 bg-gray-50 dark:bg-slate-800 rounded-lg border border-gray-300 dark:border-slate-700 hover:border-blue-400 transition-colors cursor-pointer">
                <label className="flex items-center gap-3">
                  <input type="checkbox" defaultChecked className="w-4 h-4 cursor-pointer" />
                  <span className="font-medium">Audit Logging Enabled</span>
                </label>
              </div>
              <div className="p-4 bg-gray-50 dark:bg-slate-800 rounded-lg border border-gray-300 dark:border-slate-700 hover:border-blue-400 transition-colors cursor-pointer">
                <label className="flex items-center gap-3">
                  <input type="checkbox" className="w-4 h-4 cursor-pointer" />
                  <span className="font-medium">IP Whitelist</span>
                </label>
              </div>
            </div>
          </div>
        )}

        {activeTab === "logs" && (
          <div className="p-6">
            <h3 className="text-lg font-semibold mb-4">Audit Logs</h3>
            <div className="space-y-2 text-sm">
              {[
                { action: "User login: john@company.com", time: "2 minutes ago" },
                { action: "Settings modified by Admin", time: "15 minutes ago" },
                { action: "User jane@company.com logged out", time: "1 hour ago" },
                { action: "New user invited: alice@company.com", time: "3 hours ago" },
              ].map((log, i) => (
                <div
                  key={i}
                  className="p-3 bg-gray-50 dark:bg-slate-800 rounded border border-gray-300 dark:border-slate-700 hover:border-blue-400 transition-colors"
                >
                  <p className="font-medium">{log.action}</p>
                  <p className="text-gray-600 dark:text-gray-400 text-xs">{log.time}</p>
                </div>
              ))}
            </div>
          </div>
        )}

        {activeTab === "settings" && (
          <div className="p-6">
            <h3 className="text-lg font-semibold mb-4">System Settings</h3>
            <div className="space-y-4 max-w-2xl">
              <div className="p-4 bg-gray-50 dark:bg-slate-800 rounded-lg border border-gray-300 dark:border-slate-700">
                <label className="block text-sm font-medium mb-2">Organization Name</label>
                <input
                  type="text"
                  defaultValue="Tech Corp"
                  className="w-full px-3 py-2 border border-gray-300 dark:border-slate-600 rounded bg-white dark:bg-slate-700"
                />
              </div>
              <div className="p-4 bg-gray-50 dark:bg-slate-800 rounded-lg border border-gray-300 dark:border-slate-700">
                <label className="block text-sm font-medium mb-2">Primary Email</label>
                <input
                  type="email"
                  defaultValue="admin@techcorp.com"
                  className="w-full px-3 py-2 border border-gray-300 dark:border-slate-600 rounded bg-white dark:bg-slate-700"
                />
              </div>
              <button className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded font-medium transition-colors">
                Save Changes
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  )
}
