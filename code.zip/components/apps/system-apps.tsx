"use client"

import { useState } from "react"

interface SystemFile {
  id: string
  name: string
  size: string
  type: string
}

const diskInfo: SystemFile[] = [
  { id: "1", name: "Windows (C:)", size: "256 GB", type: "drive" },
  { id: "2", name: "Data (D:)", size: "500 GB", type: "drive" },
  { id: "3", name: "Backup (E:)", size: "1 TB", type: "drive" },
]

const recycleBinItems: SystemFile[] = [
  { id: "1", name: "old_project.zip", size: "45 MB", type: "file" },
  { id: "2", name: "backup_folder", size: "234 MB", type: "folder" },
  { id: "3", name: "temp_cache", size: "123 MB", type: "folder" },
]

export default function SystemApp({ type }: { type: "this-pc" | "recycle-bin" }) {
  const [items, setItems] = useState(type === "recycle-bin" ? recycleBinItems : diskInfo)
  const [selectedItems, setSelectedItems] = useState<string[]>([])

  const toggleSelect = (id: string) => {
    setSelectedItems((prev) => (prev.includes(id) ? prev.filter((i) => i !== id) : [...prev, id]))
  }

  const restoreItems = () => {
    setItems(items.filter((i) => !selectedItems.includes(i.id)))
    setSelectedItems([])
  }

  return (
    <div className="flex flex-col h-full bg-white dark:bg-slate-800">
      {/* Header */}
      <div className="h-14 bg-gradient-to-r from-amber-600 to-amber-700 text-white flex items-center px-4 font-semibold border-b border-gray-300 dark:border-slate-600">
        <span className="text-xl mr-2">{type === "recycle-bin" ? "🗑️" : "💻"}</span>
        {type === "recycle-bin" ? "Recycle Bin" : "This PC"}
      </div>

      {/* Toolbar */}
      {type === "recycle-bin" && selectedItems.length > 0 && (
        <div className="h-10 bg-gray-100 dark:bg-slate-700 border-b border-gray-300 dark:border-slate-600 flex items-center px-4 gap-2">
          <button
            onClick={restoreItems}
            className="px-4 py-1 bg-blue-600 text-white rounded text-sm font-medium hover:bg-blue-700 transition-colors active:scale-95"
          >
            Restore Selected
          </button>
          <span className="text-sm text-gray-600 dark:text-gray-400">{selectedItems.length} selected</span>
        </div>
      )}

      {/* File List */}
      <div className="flex-1 overflow-y-auto scroll-smooth">
        {items.length > 0 ? (
          <div className="divide-y divide-gray-200 dark:divide-slate-700">
            {items.map((item) => (
              <div
                key={item.id}
                onClick={() => (type === "recycle-bin" ? toggleSelect(item.id) : null)}
                className={`flex flex-col sm:flex-row items-start sm:items-center gap-4 px-4 py-3 hover:bg-gray-50 dark:hover:bg-slate-700 transition-colors ${
                  type === "recycle-bin" ? "cursor-pointer" : ""
                } ${selectedItems.includes(item.id) ? "bg-blue-100 dark:bg-slate-700" : ""}`}
              >
                {type === "recycle-bin" && (
                  <input
                    type="checkbox"
                    checked={selectedItems.includes(item.id)}
                    onChange={() => toggleSelect(item.id)}
                    className="w-4 h-4 cursor-pointer"
                  />
                )}
                <span className="text-2xl flex-shrink-0">
                  {item.type === "drive" ? "💾" : item.type === "folder" ? "📁" : "📄"}
                </span>
                <div className="flex-1 min-w-0">
                  <p className="font-medium text-sm truncate">{item.name}</p>
                  <p className="text-xs text-gray-500">{item.size}</p>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="flex items-center justify-center h-full text-gray-500">
            <div className="text-center">
              <div className="text-6xl mb-2">{type === "recycle-bin" ? "🗑️" : "💻"}</div>
              <p>{type === "recycle-bin" ? "Recycle Bin is empty" : "Loading drives..."}</p>
            </div>
          </div>
        )}
      </div>
    </div>
  )
}
