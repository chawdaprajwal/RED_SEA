"use client"

import { useState } from "react"
import { ChevronRight, ChevronDown, File, Folder, Upload, Download, Trash2, Search } from "lucide-react"

interface FileItem {
  id: string
  name: string
  type: "file" | "folder"
  size?: string
  modified?: string
  children?: FileItem[]
}

const initialFiles: FileItem[] = [
  {
    id: "1",
    name: "Documents",
    type: "folder",
    children: [
      { id: "1-1", name: "Resume.pdf", type: "file", size: "245 KB", modified: "Nov 5" },
      { id: "1-2", name: "CoverLetter.docx", type: "file", size: "125 KB", modified: "Nov 3" },
      { id: "1-3", name: "Portfolio", type: "folder", children: [] },
    ],
  },
  {
    id: "2",
    name: "Downloads",
    type: "folder",
    children: [{ id: "2-1", name: "Project.zip", type: "file", size: "2.5 MB", modified: "Nov 4" }],
  },
  {
    id: "3",
    name: "Pictures",
    type: "folder",
    children: [],
  },
  {
    id: "4",
    name: "Videos",
    type: "folder",
    children: [],
  },
]

export default function FileExplorer() {
  const [expandedFolders, setExpandedFolders] = useState<Set<string>>(new Set(["1", "2"]))
  const [files] = useState<FileItem[]>(initialFiles)
  const [selectedFile, setSelectedFile] = useState<string | null>(null)
  const [searchQuery, setSearchQuery] = useState("")

  const toggleFolder = (id: string) => {
    const newExpanded = new Set(expandedFolders)
    if (newExpanded.has(id)) {
      newExpanded.delete(id)
    } else {
      newExpanded.add(id)
    }
    setExpandedFolders(newExpanded)
  }

  const renderFileItem = (item: FileItem, level = 0) => (
    <div key={item.id}>
      <div
        onClick={() => setSelectedFile(item.id)}
        className={`flex items-center gap-1 px-3 py-2 hover:bg-blue-100 dark:hover:bg-slate-700 rounded cursor-pointer group transition-colors ${
          selectedFile === item.id ? "bg-blue-200 dark:bg-slate-600" : ""
        }`}
      >
        {item.type === "folder" ? (
          <>
            <button
              onClick={(e) => {
                e.stopPropagation()
                toggleFolder(item.id)
              }}
              className="p-0.5 hover:bg-gray-300 dark:hover:bg-slate-600 rounded transition-colors"
            >
              {expandedFolders.has(item.id) ? <ChevronDown size={16} /> : <ChevronRight size={16} />}
            </button>
            <Folder size={16} className="text-blue-600 dark:text-blue-400" />
            <span className="flex-1 text-sm font-medium">{item.name}</span>
          </>
        ) : (
          <>
            <div className="w-4" />
            <File size={16} className="text-gray-600 dark:text-gray-400" />
            <span className="flex-1 text-sm">{item.name}</span>
            <span className="text-xs text-gray-500 dark:text-gray-400 group-hover:hidden">{item.size}</span>
          </>
        )}
      </div>
      {item.type === "folder" && expandedFolders.has(item.id) && item.children && (
        <div style={{ paddingLeft: `${(level + 1) * 12}px` }}>
          {item.children.map((child) => renderFileItem(child, level + 1))}
        </div>
      )}
    </div>
  )

  return (
    <div className="flex flex-col h-full bg-white dark:bg-slate-800">
      <div className="flex-shrink-0 bg-gray-50 dark:bg-slate-700 border-b border-gray-300 dark:border-slate-600 p-3 space-y-2">
        <div className="relative">
          <Search size={16} className="absolute left-3 top-2.5 text-gray-500" />
          <input
            type="text"
            placeholder="Search files..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-8 pr-3 py-1.5 text-sm bg-white dark:bg-slate-800 border border-gray-300 dark:border-slate-600 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
        </div>
        <div className="flex gap-2 flex-wrap">
          <button className="flex items-center gap-1 px-3 py-1.5 hover:bg-gray-200 dark:hover:bg-slate-600 rounded transition-colors text-sm">
            <Upload size={14} />
            <span className="hidden sm:inline">Upload</span>
          </button>
          <button className="flex items-center gap-1 px-3 py-1.5 hover:bg-gray-200 dark:hover:bg-slate-600 rounded transition-colors text-sm">
            <Download size={14} />
            <span className="hidden sm:inline">Download</span>
          </button>
          <button className="flex items-center gap-1 px-3 py-1.5 hover:bg-red-200 dark:hover:bg-red-900 rounded transition-colors text-sm text-red-600 dark:text-red-400">
            <Trash2 size={14} />
            <span className="hidden sm:inline">Delete</span>
          </button>
        </div>
      </div>

      {/* File List */}
      <div className="flex-1 overflow-y-auto scroll-smooth">{files.map((item) => renderFileItem(item))}</div>
    </div>
  )
}
