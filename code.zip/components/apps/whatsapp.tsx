"use client"

import { useState, useRef, useEffect } from "react"
import { Send, Search, MoreVertical, Plus } from "lucide-react"

interface Chat {
  id: string
  name: string
  avatar: string
  lastMessage: string
  timestamp: string
  unread: number
}

interface Message {
  id: string
  chatId: string
  sender: "user" | "other"
  text: string
  timestamp: string
}

export default function WhatsApp() {
  const [chats, setChats] = useState<Chat[]>([
    {
      id: "1",
      name: "Sarah Johnson",
      avatar: "👩‍💼",
      lastMessage: "That sounds great! See you tomorrow",
      timestamp: "2:30 PM",
      unread: 2,
    },
    {
      id: "2",
      name: "Alex Chen",
      avatar: "👨‍💻",
      lastMessage: "Let's catch up soon",
      timestamp: "1:15 PM",
      unread: 0,
    },
    {
      id: "3",
      name: "Emma Wilson",
      avatar: "👩‍🎨",
      lastMessage: "The project looks amazing!",
      timestamp: "11:45 AM",
      unread: 1,
    },
    {
      id: "4",
      name: "Mike Davis",
      avatar: "👨‍🔧",
      lastMessage: "Thanks for the help!",
      timestamp: "10:20 AM",
      unread: 0,
    },
  ])

  const [messages, setMessages] = useState<Message[]>([
    { id: "1", chatId: "1", sender: "other", text: "Hey! How are you?", timestamp: "2:15 PM" },
    { id: "2", chatId: "1", sender: "user", text: "I'm doing great! How about you?", timestamp: "2:18 PM" },
    { id: "3", chatId: "1", sender: "other", text: "Really good! Want to grab coffee?", timestamp: "2:25 PM" },
    { id: "4", chatId: "1", sender: "user", text: "When?", timestamp: "2:28 PM" },
    { id: "5", chatId: "1", sender: "other", text: "That sounds great! See you tomorrow", timestamp: "2:30 PM" },

    { id: "6", chatId: "2", sender: "other", text: "Did you see the new design?", timestamp: "1:10 PM" },
    { id: "7", chatId: "2", sender: "user", text: "Not yet, I'll check it out", timestamp: "1:12 PM" },
    { id: "8", chatId: "2", sender: "other", text: "Let's catch up soon", timestamp: "1:15 PM" },

    { id: "9", chatId: "3", sender: "user", text: "I finished the artwork!", timestamp: "11:40 AM" },
    { id: "10", chatId: "3", sender: "other", text: "The project looks amazing!", timestamp: "11:45 AM" },
  ])

  const [selectedChatId, setSelectedChatId] = useState<string>("1")
  const [messageInput, setMessageInput] = useState("")
  const [searchQuery, setSearchQuery] = useState("")
  const messagesEndRef = useRef<HTMLDivElement>(null)

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }

  useEffect(() => {
    scrollToBottom()
  }, [messages, selectedChatId])

  const handleSendMessage = () => {
    if (messageInput.trim()) {
      const newMessage: Message = {
        id: Date.now().toString(),
        chatId: selectedChatId,
        sender: "user",
        text: messageInput,
        timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
      }
      setMessages([...messages, newMessage])
      setMessageInput("")

      // Simulate reply
      setTimeout(() => {
        const replyMessage: Message = {
          id: (Date.now() + 1).toString(),
          chatId: selectedChatId,
          sender: "other",
          text: "Thanks for the message! 😊",
          timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
        }
        setMessages((prev) => [...prev, replyMessage])
      }, 1500)
    }
  }

  const selectedChat = chats.find((c) => c.id === selectedChatId)
  const chatMessages = messages.filter((m) => m.chatId === selectedChatId)
  const filteredChats = chats.filter((c) => c.name.toLowerCase().includes(searchQuery.toLowerCase()))

  return (
    <div className="flex h-full bg-white dark:bg-slate-900">
      {/* Sidebar - Chats List */}
      <div className="w-80 border-r border-gray-300 dark:border-slate-700 flex flex-col bg-white dark:bg-slate-900">
        {/* Header */}
        <div className="p-4 border-b border-gray-200 dark:border-slate-700">
          <div className="flex items-center justify-between mb-4">
            <h1 className="text-2xl font-bold text-gray-900 dark:text-white">WhatsApp</h1>
            <div className="flex gap-2">
              <button className="p-2 hover:bg-gray-100 dark:hover:bg-slate-800 rounded-full transition-colors">
                <Plus size={20} className="text-gray-600 dark:text-gray-300" />
              </button>
              <button className="p-2 hover:bg-gray-100 dark:hover:bg-slate-800 rounded-full transition-colors">
                <MoreVertical size={20} className="text-gray-600 dark:text-gray-300" />
              </button>
            </div>
          </div>

          {/* Search */}
          <div className="relative">
            <Search size={16} className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
            <input
              type="text"
              placeholder="Search or start new chat"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-9 pr-4 py-2 bg-gray-100 dark:bg-slate-800 border border-gray-300 dark:border-slate-700 rounded-full text-sm focus:outline-none focus:ring-2 focus:ring-green-500"
            />
          </div>
        </div>

        {/* Chats List */}
        <div className="flex-1 overflow-y-auto scroll-smooth">
          {filteredChats.map((chat) => (
            <button
              key={chat.id}
              onClick={() => setSelectedChatId(chat.id)}
              className={`w-full p-3 border-b border-gray-100 dark:border-slate-800 hover:bg-gray-50 dark:hover:bg-slate-800 transition-colors flex items-center gap-3 ${
                selectedChatId === chat.id ? "bg-gray-100 dark:bg-slate-800" : ""
              }`}
            >
              <div className="text-3xl">{chat.avatar}</div>
              <div className="flex-1 min-w-0 text-left">
                <div className="flex justify-between items-start">
                  <p className="font-semibold text-sm text-gray-900 dark:text-white">{chat.name}</p>
                  <span className="text-xs text-gray-500 dark:text-gray-400">{chat.timestamp}</span>
                </div>
                <p className="text-xs text-gray-600 dark:text-gray-400 truncate">{chat.lastMessage}</p>
              </div>
              {chat.unread > 0 && (
                <div className="bg-green-500 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center font-semibold">
                  {chat.unread}
                </div>
              )}
            </button>
          ))}
        </div>
      </div>

      {/* Chat Area */}
      <div className="flex-1 flex flex-col bg-gradient-to-b from-gray-50 to-white dark:from-slate-800 dark:to-slate-900">
        {selectedChat ? (
          <>
            {/* Chat Header */}
            <div className="h-16 border-b border-gray-300 dark:border-slate-700 px-6 flex items-center justify-between bg-white dark:bg-slate-800">
              <div className="flex items-center gap-3">
                <div className="text-3xl">{selectedChat.avatar}</div>
                <div>
                  <p className="font-semibold text-gray-900 dark:text-white">{selectedChat.name}</p>
                  <p className="text-xs text-gray-500 dark:text-gray-400">Active now</p>
                </div>
              </div>
              <button className="p-2 hover:bg-gray-100 dark:hover:bg-slate-700 rounded-full transition-colors">
                <MoreVertical size={20} className="text-gray-600 dark:text-gray-300" />
              </button>
            </div>

            {/* Messages */}
            <div className="flex-1 overflow-y-auto scroll-smooth p-4 space-y-4">
              {chatMessages.map((msg) => (
                <div key={msg.id} className={`flex ${msg.sender === "user" ? "justify-end" : "justify-start"}`}>
                  <div
                    className={`max-w-xs px-4 py-2 rounded-lg ${
                      msg.sender === "user"
                        ? "bg-green-500 text-white rounded-br-none"
                        : "bg-gray-200 dark:bg-slate-700 text-gray-900 dark:text-white rounded-bl-none"
                    }`}
                  >
                    <p className="text-sm break-words">{msg.text}</p>
                    <p
                      className={`text-xs mt-1 ${msg.sender === "user" ? "text-green-100" : "text-gray-600 dark:text-gray-400"}`}
                    >
                      {msg.timestamp}
                    </p>
                  </div>
                </div>
              ))}
              <div ref={messagesEndRef} />
            </div>

            {/* Input Area */}
            <div className="h-20 border-t border-gray-300 dark:border-slate-700 px-4 py-3 bg-white dark:bg-slate-800 flex items-center gap-3">
              <button className="p-2 hover:bg-gray-100 dark:hover:bg-slate-700 rounded-full transition-colors">
                <Plus size={20} className="text-green-500" />
              </button>
              <input
                type="text"
                placeholder="Type a message..."
                value={messageInput}
                onChange={(e) => setMessageInput(e.target.value)}
                onKeyPress={(e) => e.key === "Enter" && handleSendMessage()}
                className="flex-1 px-4 py-2 border border-gray-300 dark:border-slate-600 rounded-full bg-white dark:bg-slate-700 text-sm focus:outline-none focus:ring-2 focus:ring-green-500 text-gray-900 dark:text-white"
              />
              <button
                onClick={handleSendMessage}
                disabled={!messageInput.trim()}
                className="p-2 hover:bg-gray-100 dark:hover:bg-slate-700 rounded-full transition-colors disabled:opacity-50"
              >
                <Send size={20} className="text-green-500" />
              </button>
            </div>
          </>
        ) : (
          <div className="flex items-center justify-center h-full text-gray-500">
            <p>Select a chat to start messaging</p>
          </div>
        )}
      </div>
    </div>
  )
}
