"use client"

import { useState } from "react"
import { Heart, MessageCircle, Share2 } from "lucide-react"

interface Post {
  id: string
  author: string
  avatar: string
  content: string
  likes: number
  comments: number
  timestamp: string
  liked: boolean
}

const mockPosts: Post[] = [
  {
    id: "1",
    author: "Sarah Johnson",
    avatar: "👩‍💼",
    content: "Just launched our new product! Excited to share it with everyone.",
    likes: 342,
    comments: 45,
    timestamp: "2 hours ago",
    liked: false,
  },
  {
    id: "2",
    author: "Alex Chen",
    avatar: "👨‍💻",
    content: "Working on an amazing project. Can't wait to show you all what we've built!",
    likes: 512,
    comments: 78,
    timestamp: "4 hours ago",
    liked: false,
  },
]

export default function SocialMedia({
  platform,
}: { platform: "whatsapp" | "facebook" | "linkedin" | "telegram" | "twitter" }) {
  const [posts, setPosts] = useState<Post[]>(mockPosts)
  const [newPost, setNewPost] = useState("")

  const toggleLike = (id: string) => {
    setPosts(
      posts.map((p) => (p.id === id ? { ...p, liked: !p.liked, likes: p.liked ? p.likes - 1 : p.likes + 1 } : p)),
    )
  }

  const handlePost = () => {
    if (newPost.trim()) {
      const post: Post = {
        id: Date.now().toString(),
        author: "You",
        avatar: "👤",
        content: newPost,
        likes: 0,
        comments: 0,
        timestamp: "now",
        liked: false,
      }
      setPosts([post, ...posts])
      setNewPost("")
    }
  }

  const platformConfig = {
    whatsapp: { color: "from-green-500 to-green-600", name: "WhatsApp" },
    facebook: { color: "from-blue-600 to-blue-700", name: "Facebook" },
    linkedin: { color: "from-blue-700 to-blue-800", name: "LinkedIn" },
    telegram: { color: "from-blue-400 to-blue-500", name: "Telegram" },
    twitter: { color: "from-sky-400 to-sky-500", name: "Twitter" },
  }

  const config = platformConfig[platform]

  return (
    <div className="flex flex-col h-full bg-white dark:bg-slate-900">
      {/* Header */}
      <div
        className={`h-14 bg-gradient-to-r ${config.color} text-white flex items-center px-4 font-semibold border-b border-gray-300 dark:border-slate-700`}
      >
        <span className="text-xl mr-2">
          {platform === "whatsapp"
            ? "💬"
            : platform === "facebook"
              ? "📘"
              : platform === "linkedin"
                ? "💼"
                : platform === "telegram"
                  ? "✈️"
                  : "𝕏"}
        </span>
        {config.name}
      </div>

      {/* Feed */}
      <div className="flex-1 overflow-y-auto scroll-smooth">
        {/* Compose */}
        <div className="p-4 border-b border-gray-200 dark:border-slate-700 bg-gray-50 dark:bg-slate-800">
          <div className="flex gap-3">
            <div className="text-2xl">👤</div>
            <div className="flex-1">
              <textarea
                placeholder={`What's on your mind?`}
                value={newPost}
                onChange={(e) => setNewPost(e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 dark:border-slate-600 rounded-lg bg-white dark:bg-slate-700 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 resize-none h-20"
              />
              <button
                onClick={handlePost}
                disabled={!newPost.trim()}
                className="mt-2 px-4 py-1 bg-blue-600 text-white rounded-lg text-sm font-medium hover:bg-blue-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed active:scale-95"
              >
                Post
              </button>
            </div>
          </div>
        </div>

        {/* Posts */}
        <div className="space-y-4 p-4">
          {posts.map((post) => (
            <div
              key={post.id}
              className="border border-gray-200 dark:border-slate-700 rounded-lg p-4 hover:shadow-md dark:hover:shadow-slate-900 transition-shadow"
            >
              <div className="flex items-center gap-3 mb-3">
                <span className="text-2xl">{post.avatar}</span>
                <div className="flex-1">
                  <p className="font-semibold text-sm">{post.author}</p>
                  <p className="text-xs text-gray-500">{post.timestamp}</p>
                </div>
              </div>
              <p className="text-sm text-gray-800 dark:text-gray-200 mb-3">{post.content}</p>
              <div className="flex items-center justify-between text-xs text-gray-500 pt-3 border-t border-gray-200 dark:border-slate-700">
                <button
                  onClick={() => toggleLike(post.id)}
                  className={`flex items-center gap-1 px-3 py-1 rounded hover:bg-gray-100 dark:hover:bg-slate-800 transition-colors ${
                    post.liked ? "text-red-500" : ""
                  }`}
                >
                  <Heart size={16} fill={post.liked ? "currentColor" : "none"} />
                  {post.likes}
                </button>
                <button className="flex items-center gap-1 px-3 py-1 rounded hover:bg-gray-100 dark:hover:bg-slate-800 transition-colors">
                  <MessageCircle size={16} />
                  {post.comments}
                </button>
                <button className="flex items-center gap-1 px-3 py-1 rounded hover:bg-gray-100 dark:hover:bg-slate-800 transition-colors">
                  <Share2 size={16} />
                  Share
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}
