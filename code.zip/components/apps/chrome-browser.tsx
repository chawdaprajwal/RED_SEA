"use client"

import { useState } from "react"
import { ArrowLeft, ArrowRight, RotateCw, Settings, Globe } from "lucide-react"
import YouTube from "./youtube"
import Google from "./google"
import GitHub from "./github"
import StackOverflow from "./stackoverflow"

interface BrowserTab {
  id: string
  url: string
  title: string
  favicon: string
}

const mockPages: Record<
  string,
  {
    title: string
    content?: string
    favicon: string
    isYoutube?: boolean
    isGoogle?: boolean
    isGithub?: boolean
    isStackOverflow?: boolean
  }
> = {
  "https://google.com": { title: "Google", favicon: "🔵", isGoogle: true },
  "https://youtube.com": { title: "YouTube", favicon: "🔴", isYoutube: true },
  "https://github.com": { title: "GitHub", favicon: "⚫", isGithub: true },
  "https://stackoverflow.com": { title: "Stack Overflow", favicon: "🟠", isStackOverflow: true },
  "https://": { title: "Home", content: "Welcome to Chrome", favicon: "🌐" },
}

export default function ChromeBrowser() {
  const [tabs, setTabs] = useState<BrowserTab[]>([{ id: "1", url: "https://", title: "Home", favicon: "🌐" }])
  const [activeTabId, setActiveTabId] = useState("1")
  const [urlInput, setUrlInput] = useState("")

  const activeTab = tabs.find((t) => t.id === activeTabId)

  const navigateTo = (url: string) => {
    const page = mockPages[url] || mockPages["https://"]
    const newTab = { id: Date.now().toString(), url, title: page.title, favicon: page.favicon }
    setTabs([...tabs, newTab])
    setActiveTabId(newTab.id)
    setUrlInput("")
  }

  const closeTab = (id: string) => {
    const newTabs = tabs.filter((t) => t.id !== id)
    if (newTabs.length === 0) {
      setTabs([{ id: "1", url: "https://", title: "Home", favicon: "🌐" }])
      setActiveTabId("1")
    } else {
      setTabs(newTabs)
      setActiveTabId(newTabs[0].id)
    }
  }

  const pageInfo = activeTab ? mockPages[activeTab.url] : mockPages["https://"]
  const isYoutubePage = pageInfo?.isYoutube
  const isGooglePage = pageInfo?.isGoogle
  const isGithubPage = pageInfo?.isGithub
  const isStackOverflowPage = pageInfo?.isStackOverflow

  return (
    <div className="flex flex-col h-full bg-white dark:bg-slate-900">
      {/* Address Bar */}
      <div className="bg-gray-100 dark:bg-slate-800 border-b border-gray-300 dark:border-slate-700 p-3 space-y-3">
        <div className="flex items-center gap-2">
          <button className="p-2 hover:bg-gray-200 dark:hover:bg-slate-700 rounded transition-colors active:scale-90 duration-100">
            <ArrowLeft size={18} />
          </button>
          <button className="p-2 hover:bg-gray-200 dark:hover:bg-slate-700 rounded transition-colors active:scale-90 duration-100">
            <ArrowRight size={18} />
          </button>
          <button className="p-2 hover:bg-gray-200 dark:hover:bg-slate-700 rounded transition-colors active:scale-90 duration-100">
            <RotateCw size={18} />
          </button>
          <div className="flex-1 flex items-center gap-2 bg-white dark:bg-slate-700 rounded-full px-4 py-2 border border-gray-300 dark:border-slate-600 hover:border-blue-500 transition-colors">
            <Globe size={16} className="text-gray-500" />
            <input
              type="text"
              placeholder="Search or enter URL"
              value={urlInput}
              onChange={(e) => setUrlInput(e.target.value)}
              onKeyPress={(e) => {
                if (e.key === "Enter" && urlInput) {
                  navigateTo(urlInput.startsWith("https://") ? urlInput : `https://${urlInput}`)
                }
              }}
              className="flex-1 bg-transparent outline-none text-sm"
            />
          </div>
          <button className="p-2 hover:bg-gray-200 dark:hover:bg-slate-700 rounded transition-colors active:scale-90 duration-100">
            <Settings size={18} />
          </button>
        </div>

        {/* Tabs */}
        <div className="flex gap-2 overflow-x-auto pb-2 scroll-smooth">
          {tabs.map((tab) => (
            <div
              key={tab.id}
              onClick={() => setActiveTabId(tab.id)}
              className={`flex items-center gap-2 px-3 py-1 rounded-t-lg cursor-pointer whitespace-nowrap transition-all ${
                activeTabId === tab.id
                  ? "bg-white dark:bg-slate-700 border-b-2 border-blue-600 shadow-md"
                  : "bg-gray-200 dark:bg-slate-800 hover:bg-gray-300 dark:hover:bg-slate-700"
              }`}
            >
              <span>{tab.favicon}</span>
              <span className="text-xs font-medium">{tab.title}</span>
              <button
                onClick={(e) => {
                  e.stopPropagation()
                  closeTab(tab.id)
                }}
                className="text-gray-500 hover:text-red-500 transition-colors text-sm"
              >
                ✕
              </button>
            </div>
          ))}
          <button
            onClick={() => navigateTo("https://")}
            className="px-3 py-1 text-gray-600 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-slate-700 rounded transition-colors text-xl leading-none active:scale-95"
          >
            +
          </button>
        </div>
      </div>

      {/* Content */}
      <div className="flex-1 overflow-y-auto scroll-smooth">
        {isGooglePage ? (
          <Google />
        ) : isYoutubePage ? (
          <YouTube />
        ) : isGithubPage ? (
          <GitHub />
        ) : isStackOverflowPage ? (
          <StackOverflow />
        ) : (
          <div className="p-8 text-center animate-fade-in-up">
            <div className="text-6xl mb-4">{pageInfo?.favicon}</div>
            <h2 className="text-2xl font-bold mb-2">{pageInfo?.title}</h2>
            <p className="text-gray-600 dark:text-gray-400 mb-6">{pageInfo?.content}</p>
            <div className="flex flex-wrap gap-2 justify-center">
              {Object.keys(mockPages).map((url) => (
                <button
                  key={url}
                  onClick={() => navigateTo(url)}
                  className="px-4 py-2 bg-blue-600 text-white rounded-lg text-sm font-medium hover:bg-blue-700 transition-colors active:scale-95 duration-100"
                >
                  {mockPages[url].title}
                </button>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  )
}
