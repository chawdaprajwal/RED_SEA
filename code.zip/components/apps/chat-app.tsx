"use client"

import { useState, useRef, useEffect } from "react"
import { Send, Paperclip, Smile } from "lucide-react"

interface ChatMessage {
  id: string
  sender: string
  message: string
  timestamp: string
  isOwn: boolean
  avatar?: string
}

const mockConversation: ChatMessage[] = [
  {
    id: "1",
    sender: "Alex",
    message: "Hey, how's the project going?",
    timestamp: "10:30 AM",
    isOwn: false,
    avatar: "👨",
  },
  {
    id: "2",
    sender: "You",
    message: "Going well! Just finishing up the UI components.",
    timestamp: "10:31 AM",
    isOwn: true,
    avatar: "👤",
  },
  {
    id: "3",
    sender: "Alex",
    message: "Great! Let me know when you need a review.",
    timestamp: "10:35 AM",
    isOwn: false,
    avatar: "👨",
  },
  {
    id: "4",
    sender: "You",
    message: "Will do, should be ready by EOD tomorrow",
    timestamp: "10:36 AM",
    isOwn: true,
    avatar: "👤",
  },
]

export default function ChatApp() {
  const [messages, setMessages] = useState<ChatMessage[]>(mockConversation)
  const [inputValue, setInputValue] = useState("")
  const [isTyping, setIsTyping] = useState(false)
  const messagesEndRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }, [messages])

  const handleSend = () => {
    if (!inputValue.trim()) return

    const newMessage: ChatMessage = {
      id: Date.now().toString(),
      sender: "You",
      message: inputValue,
      timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
      isOwn: true,
      avatar: "👤",
    }

    setMessages([...messages, newMessage])
    setInputValue("")

    setIsTyping(true)
    setTimeout(() => {
      const reply: ChatMessage = {
        id: (Date.now() + 1).toString(),
        sender: "Alex",
        message: "That sounds great! I'll review it then.",
        timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
        isOwn: false,
        avatar: "👨",
      }
      setMessages((prev) => [...prev, reply])
      setIsTyping(false)
    }, 1500)
  }

  return (
    <div className="flex flex-col h-full bg-white dark:bg-slate-800">
      <div className="flex-shrink-0 h-14 bg-gradient-to-r from-blue-600 to-blue-700 text-white flex items-center px-6 font-semibold border-b border-blue-800 dark:border-slate-600 shadow-md">
        <div className="w-10 h-10 rounded-full bg-white/20 flex items-center justify-center text-lg mr-3">👨</div>
        <div className="flex-1">
          <div>💬 Chat with Alex</div>
          <div className="text-xs font-normal text-blue-100">Active now</div>
        </div>
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto scroll-smooth p-4 space-y-4">
        {messages.map((msg) => (
          <div key={msg.id} className={`flex ${msg.isOwn ? "justify-end" : "justify-start"} gap-2`}>
            {!msg.isOwn && <div className="text-2xl flex-shrink-0">{msg.avatar}</div>}
            <div className={`flex flex-col ${msg.isOwn ? "items-end" : "items-start"}`}>
              <div
                className={`max-w-xs lg:max-w-md px-4 py-3 rounded-2xl transition-all hover:shadow-lg ${
                  msg.isOwn
                    ? "bg-blue-600 text-white rounded-br-none"
                    : "bg-gray-200 dark:bg-slate-700 text-gray-900 dark:text-white rounded-bl-none"
                }`}
              >
                {!msg.isOwn && <p className="text-xs font-semibold mb-1">{msg.sender}</p>}
                <p className="text-sm break-words">{msg.message}</p>
              </div>
              <p className="text-xs text-gray-500 mt-1">{msg.timestamp}</p>
            </div>
            {msg.isOwn && <div className="text-2xl flex-shrink-0">{msg.avatar}</div>}
          </div>
        ))}
        {isTyping && (
          <div className="flex gap-2">
            <div className="text-2xl">👨</div>
            <div className="bg-gray-200 dark:bg-slate-700 px-4 py-3 rounded-2xl rounded-bl-none">
              <div className="flex gap-1">
                <div className="w-2 h-2 bg-gray-600 dark:bg-gray-400 rounded-full animate-bounce" />
                <div
                  className="w-2 h-2 bg-gray-600 dark:bg-gray-400 rounded-full animate-bounce"
                  style={{ animationDelay: "0.1s" }}
                />
                <div
                  className="w-2 h-2 bg-gray-600 dark:bg-gray-400 rounded-full animate-bounce"
                  style={{ animationDelay: "0.2s" }}
                />
              </div>
            </div>
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>

      <div className="flex-shrink-0 border-t border-gray-300 dark:border-slate-600 p-4 bg-gray-50 dark:bg-slate-700 space-y-2">
        <div className="flex items-center gap-2">
          <button
            className="p-2 hover:bg-gray-200 dark:hover:bg-slate-600 rounded-lg transition-colors text-gray-600 dark:text-gray-400"
            title="Attach file"
          >
            <Paperclip size={18} />
          </button>
          <input
            type="text"
            value={inputValue}
            onChange={(e) => setInputValue(e.target.value)}
            onKeyPress={(e) => e.key === "Enter" && handleSend()}
            placeholder="Type a message..."
            className="flex-1 px-4 py-2 bg-white dark:bg-slate-800 border border-gray-300 dark:border-slate-600 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-600 transition-ring"
          />
          <button
            className="p-2 hover:bg-gray-200 dark:hover:bg-slate-600 rounded-lg transition-colors text-gray-600 dark:text-gray-400"
            title="Emoji"
          >
            <Smile size={18} />
          </button>
          <button
            onClick={handleSend}
            className="p-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition-colors active:scale-95"
            title="Send message"
          >
            <Send size={18} />
          </button>
        </div>
      </div>
    </div>
  )
}
