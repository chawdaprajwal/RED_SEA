"use client"

import { useState, useRef } from "react"
import Desktop from "@/components/desktop"
import Taskbar from "@/components/taskbar"
import NotificationCenter from "@/components/notification-center"

export default function Home() {
  const [openApps, setOpenApps] = useState<Array<{ id: string; type: string; title: string; minimized: boolean }>>([])
  const [notifications, setNotifications] = useState<
    Array<{ id: string; title: string; message: string; type: "info" | "success" | "warning" | "error" }>
  >([])
  const [showNotifications, setShowNotifications] = useState(false)
  const [systemPowered, setSystemPowered] = useState(true)
  const notificationIdRef = useRef(0)

  const openApp = (type: string, title: string) => {
    const id = `${type}-${Date.now()}`
    setOpenApps([...openApps, { id, type, title, minimized: false }])
    addNotification(`${title} opened`, "success")
  }

  const closeApp = (id: string) => {
    setOpenApps(openApps.filter((app) => app.id !== id))
    addNotification("App closed", "info")
  }

  const toggleMinimize = (id: string) => {
    setOpenApps(openApps.map((app) => (app.id === id ? { ...app, minimized: !app.minimized } : app)))
  }

  const addNotification = (message: string, type: "info" | "success" | "warning" | "error" = "info") => {
    const id = `notif-${notificationIdRef.current++}`
    setNotifications((prev) => [...prev, { id, title: "Virtual Laptop", message, type }])
    setTimeout(() => {
      setNotifications((prev) => prev.filter((n) => n.id !== id))
    }, 4000)
  }

  const handleShutdown = () => {
    setOpenApps([])
    setSystemPowered(false)
    addNotification("System shutting down...", "warning")
  }

  if (!systemPowered) {
    return (
      <div className="h-screen w-screen bg-black flex items-center justify-center">
        <div className="text-center">
          <div className="text-4xl sm:text-6xl mb-4">⏻️</div>
          <h1 className="text-lg sm:text-2xl font-bold text-white mb-4">System Powered Off</h1>
          <button
            onClick={() => {
              setSystemPowered(true)
              addNotification("System powered on", "success")
            }}
            className="px-4 sm:px-6 py-2 sm:py-3 bg-blue-600 hover:bg-blue-700 text-white rounded-lg font-semibold transition-colors active:scale-95 text-sm sm:text-base"
          >
            Power On
          </button>
        </div>
      </div>
    )
  }

  return (
    <div className="h-screen bg-gradient-to-b from-blue-50 to-slate-100 dark:from-slate-900 dark:to-slate-800 flex flex-col overflow-hidden">
      <Desktop openApps={openApps} onCloseApp={closeApp} onToggleMinimize={toggleMinimize} onOpenApp={openApp} />
      <Taskbar
        openApps={openApps}
        onOpenApp={openApp}
        onToggleMinimize={toggleMinimize}
        notificationCount={notifications.length}
        onToggleNotifications={() => setShowNotifications(!showNotifications)}
        onShutdown={handleShutdown}
      />
      {showNotifications && <NotificationCenter notifications={notifications} onClear={() => setNotifications([])} />}
    </div>
  )
}
