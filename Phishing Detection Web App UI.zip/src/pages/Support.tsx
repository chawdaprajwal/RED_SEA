import { useState } from 'react';
import { DashboardLayout } from '../components/DashboardLayout';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../components/ui/card';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { Label } from '../components/ui/label';
import { Textarea } from '../components/ui/textarea';
import { Badge } from '../components/ui/badge';
import { 
  HeadphonesIcon, Send, Phone, Mail, MessageCircle, 
  Clock, CheckCircle, HelpCircle, FileText, Video, Book
} from 'lucide-react';
import { toast } from 'sonner@2.0.3';
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from '../components/ui/accordion';

export default function Support() {
  const [supportForm, setSupportForm] = useState({
    subject: '',
    priority: 'medium',
    message: '',
  });

  const handleSubmitTicket = () => {
    if (!supportForm.subject || !supportForm.message) {
      toast.error('Please fill all required fields');
      return;
    }
    toast.success('Support ticket submitted! Ticket #' + Math.floor(Math.random() * 10000));
    setSupportForm({ subject: '', priority: 'medium', message: '' });
  };

  const contactMethods = [
    {
      icon: Phone,
      title: '24/7 Phone Support',
      value: '+91 1800-123-4567',
      description: 'Available 24/7 for enterprise clients',
      color: 'from-blue-500 to-blue-600',
    },
    {
      icon: Mail,
      title: 'Email Support',
      value: 'support@phishguard.com',
      description: 'Response within 4 hours',
      color: 'from-green-500 to-green-600',
    },
    {
      icon: MessageCircle,
      title: 'Live Chat',
      value: 'Start Chat',
      description: 'Mon-Fri, 9 AM - 6 PM IST',
      color: 'from-purple-500 to-purple-600',
    },
  ];

  const recentTickets = [
    {
      id: '#3847',
      subject: 'API Integration Issue',
      status: 'resolved',
      date: '2025-11-10',
      priority: 'high',
    },
    {
      id: '#3846',
      subject: 'User Permission Settings',
      status: 'in-progress',
      date: '2025-11-09',
      priority: 'medium',
    },
    {
      id: '#3845',
      subject: 'Feature Request: Bulk Upload',
      status: 'pending',
      date: '2025-11-08',
      priority: 'low',
    },
  ];

  const faqs = [
    {
      question: 'How do I add new users to my organization?',
      answer: 'Navigate to Settings > User Management and click "Add User". Enter their email address and assign appropriate permissions. They will receive an invitation email to join your organization.',
    },
    {
      question: 'What is the SLA for enterprise support?',
      answer: 'Enterprise clients receive guaranteed response times: Critical issues - 1 hour, High priority - 4 hours, Medium priority - 8 hours, Low priority - 24 hours. We maintain 99.9% uptime with 24/7 monitoring.',
    },
    {
      question: 'Can I integrate PhishGuard with my existing security tools?',
      answer: 'Yes! We offer API integration with most major security platforms including SIEM tools, email gateways, and identity providers. Check our API documentation or contact our integration team for assistance.',
    },
    {
      question: 'How do I run a phishing simulation campaign?',
      answer: 'Go to the Simulation page, select a simulation type, configure your target audience, and click "Start Simulation". You can customize email templates and track results in real-time.',
    },
    {
      question: 'What reports are available for compliance?',
      answer: 'We provide comprehensive reports including scan history, threat detection rates, employee training results, and detailed audit logs. All reports can be exported in PDF, CSV, or JSON formats.',
    },
  ];

  const resources = [
    {
      icon: Book,
      title: 'Documentation',
      description: 'Comprehensive guides and API reference',
      link: '#',
    },
    {
      icon: Video,
      title: 'Video Tutorials',
      description: 'Step-by-step video walkthroughs',
      link: '#',
    },
    {
      icon: FileText,
      title: 'Knowledge Base',
      description: 'Articles and troubleshooting guides',
      link: '#',
    },
  ];

  return (
    <DashboardLayout>
      <div className="space-y-6">
        {/* Header */}
        <div>
          <h1 className="text-blue-900 dark:text-white mb-2">Enterprise Support</h1>
          <p className="text-gray-600 dark:text-gray-400">
            Get help from our dedicated support team
          </p>
        </div>

        {/* Contact Methods */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {contactMethods.map((method, index) => {
            const Icon = method.icon;
            return (
              <Card 
                key={index}
                className="bg-white/80 dark:bg-gray-800/80 backdrop-blur-lg border-blue-200 dark:border-gray-700 hover:shadow-xl transition-all cursor-pointer"
              >
                <CardContent className="pt-6">
                  <div className="space-y-3">
                    <div className={`w-12 h-12 rounded-lg bg-gradient-to-br ${method.color} flex items-center justify-center`}>
                      <Icon className="w-6 h-6 text-white" />
                    </div>
                    <div>
                      <h3 className="text-gray-900 dark:text-white mb-1">{method.title}</h3>
                      <p className="text-blue-600 dark:text-blue-400 mb-1">{method.value}</p>
                      <p className="text-sm text-gray-600 dark:text-gray-400">{method.description}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>

        {/* Submit Ticket */}
        <Card className="bg-white/80 dark:bg-gray-800/80 backdrop-blur-lg border-blue-200 dark:border-gray-700">
          <CardHeader>
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-blue-500 to-blue-600 flex items-center justify-center">
                <HeadphonesIcon className="w-5 h-5 text-white" />
              </div>
              <div>
                <CardTitle className="text-blue-900 dark:text-white">Submit Support Ticket</CardTitle>
                <CardDescription className="dark:text-gray-400">
                  Our team will respond within 4 hours
                </CardDescription>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="subject" className="dark:text-gray-300">Subject *</Label>
                  <Input
                    id="subject"
                    placeholder="Brief description of your issue"
                    value={supportForm.subject}
                    onChange={(e) => setSupportForm({ ...supportForm, subject: e.target.value })}
                    className="dark:bg-gray-900/50 dark:border-gray-700"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="priority" className="dark:text-gray-300">Priority</Label>
                  <select
                    id="priority"
                    value={supportForm.priority}
                    onChange={(e) => setSupportForm({ ...supportForm, priority: e.target.value })}
                    className="w-full h-10 px-3 rounded-md border border-gray-300 dark:border-gray-700 bg-white dark:bg-gray-900/50 text-gray-900 dark:text-white"
                  >
                    <option value="low">Low</option>
                    <option value="medium">Medium</option>
                    <option value="high">High</option>
                    <option value="critical">Critical</option>
                  </select>
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="message" className="dark:text-gray-300">Message *</Label>
                <Textarea
                  id="message"
                  placeholder="Describe your issue in detail..."
                  value={supportForm.message}
                  onChange={(e) => setSupportForm({ ...supportForm, message: e.target.value })}
                  rows={5}
                  className="dark:bg-gray-900/50 dark:border-gray-700"
                />
              </div>
              <Button onClick={handleSubmitTicket} className="w-full bg-blue-600 hover:bg-blue-700 text-white gap-2">
                <Send className="w-4 h-4" />
                Submit Ticket
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Recent Tickets */}
        <Card className="bg-white/80 dark:bg-gray-800/80 backdrop-blur-lg border-blue-200 dark:border-gray-700">
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle className="text-blue-900 dark:text-white">Recent Tickets</CardTitle>
              <Badge variant="outline">3 Active</Badge>
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {recentTickets.map((ticket) => (
                <div key={ticket.id} className="flex items-center justify-between p-4 rounded-lg bg-gray-50 dark:bg-gray-900/50">
                  <div className="flex items-center gap-4">
                    {ticket.status === 'resolved' ? (
                      <CheckCircle className="w-6 h-6 text-green-600" />
                    ) : ticket.status === 'in-progress' ? (
                      <Clock className="w-6 h-6 text-blue-600" />
                    ) : (
                      <HelpCircle className="w-6 h-6 text-gray-400" />
                    )}
                    <div>
                      <div className="flex items-center gap-2 mb-1">
                        <span className="text-sm text-gray-500 dark:text-gray-400">{ticket.id}</span>
                        <span className="text-gray-900 dark:text-white">{ticket.subject}</span>
                      </div>
                      <p className="text-sm text-gray-600 dark:text-gray-400">{ticket.date}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    <Badge 
                      variant={
                        ticket.priority === 'critical' ? 'destructive' :
                        ticket.priority === 'high' ? 'default' :
                        'outline'
                      }
                    >
                      {ticket.priority}
                    </Badge>
                    <Badge variant="secondary">{ticket.status}</Badge>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* FAQs */}
        <Card className="bg-white/80 dark:bg-gray-800/80 backdrop-blur-lg border-blue-200 dark:border-gray-700">
          <CardHeader>
            <CardTitle className="text-blue-900 dark:text-white">Frequently Asked Questions</CardTitle>
            <CardDescription className="dark:text-gray-400">Quick answers to common questions</CardDescription>
          </CardHeader>
          <CardContent>
            <Accordion type="single" collapsible className="w-full">
              {faqs.map((faq, index) => (
                <AccordionItem key={index} value={`item-${index}`}>
                  <AccordionTrigger className="text-left text-gray-900 dark:text-white hover:text-blue-600 dark:hover:text-blue-400">
                    {faq.question}
                  </AccordionTrigger>
                  <AccordionContent className="text-gray-600 dark:text-gray-400">
                    {faq.answer}
                  </AccordionContent>
                </AccordionItem>
              ))}
            </Accordion>
          </CardContent>
        </Card>

        {/* Resources */}
        <div>
          <h2 className="text-blue-900 dark:text-white mb-4">Self-Service Resources</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {resources.map((resource, index) => {
              const Icon = resource.icon;
              return (
                <Card 
                  key={index}
                  className="bg-white/80 dark:bg-gray-800/80 backdrop-blur-lg border-blue-200 dark:border-gray-700 hover:shadow-xl transition-all cursor-pointer"
                >
                  <CardContent className="pt-6">
                    <div className="text-center space-y-3">
                      <div className="inline-flex w-12 h-12 rounded-lg bg-blue-100 dark:bg-blue-900/30 items-center justify-center">
                        <Icon className="w-6 h-6 text-blue-600 dark:text-blue-400" />
                      </div>
                      <div>
                        <h3 className="text-gray-900 dark:text-white mb-1">{resource.title}</h3>
                        <p className="text-sm text-gray-600 dark:text-gray-400">{resource.description}</p>
                      </div>
                      <Button variant="outline" size="sm" className="w-full">
                        Browse
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </div>

        {/* Support Hours */}
        <Card className="bg-gradient-to-br from-green-500 to-green-600 border-0 text-white">
          <CardContent className="pt-6">
            <div className="flex items-start gap-4">
              <Clock className="w-6 h-6 flex-shrink-0 mt-1" />
              <div>
                <h3 className="mb-2">Enterprise Support Hours</h3>
                <div className="space-y-1 text-sm text-green-100">
                  <p>• 24/7 Critical Issue Support</p>
                  <p>• Live Chat: Monday - Friday, 9 AM - 6 PM IST</p>
                  <p>• Phone Support: 24/7 for Enterprise clients</p>
                  <p>• Email Support: Response within 4 hours</p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  );
}
