import { DashboardLayout } from '../components/DashboardLayout';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { 
  Shield, Search, Download, Chrome, AlertCircle, 
  CheckCircle, PlayCircle, Link2
} from 'lucide-react';
import { Button } from '../components/ui/button';

export default function Instructions() {
  const steps = [
    {
      icon: Search,
      title: 'Enter URL',
      description: 'Copy and paste any suspicious URL into the detection field on your dashboard.',
    },
    {
      icon: Shield,
      title: 'Analyze',
      description: 'Click "Detect Phishing" to start the advanced AI-powered analysis.',
    },
    {
      icon: AlertCircle,
      title: 'Review Results',
      description: 'Check the safety status and detailed threat information provided.',
    },
    {
      icon: CheckCircle,
      title: 'Take Action',
      description: 'Based on results, proceed safely or report the suspicious URL.',
    },
  ];

  const features = [
    'Real-time URL scanning and analysis',
    'AI-powered phishing detection',
    'Comprehensive threat reports',
    'Browser extension for instant protection',
    'Desktop applications for Windows & macOS',
    'Detailed analytics and statistics',
    'PDF report generation',
    'Dark mode support',
  ];

  const tips = [
    {
      title: 'Check the Domain',
      description: 'Look for misspellings or unusual domain extensions (e.g., .tk, .ml)',
    },
    {
      title: 'Look for HTTPS',
      description: 'Legitimate websites use HTTPS. However, phishing sites can also use it.',
    },
    {
      title: 'Verify Email Senders',
      description: 'Check the sender\'s email address carefully before clicking any links.',
    },
    {
      title: 'Hover Before Clicking',
      description: 'Hover over links to see the actual URL before clicking.',
    },
    {
      title: 'Trust Your Instincts',
      description: 'If something feels wrong, it probably is. When in doubt, verify directly.',
    },
  ];

  return (
    <DashboardLayout>
      <div className="space-y-6">
        {/* Header */}
        <div>
          <h1 className="text-blue-900 dark:text-white mb-2">How to Use PhishGuard</h1>
          <p className="text-gray-600 dark:text-gray-400">
            Learn how to protect yourself from phishing attacks
          </p>
        </div>

        {/* Video Placeholder */}
        <Card className="bg-white/80 dark:bg-gray-800/80 backdrop-blur-lg border-blue-200 dark:border-gray-700">
          <CardContent className="pt-6">
            <div className="aspect-video bg-gradient-to-br from-blue-500 to-blue-600 rounded-lg flex items-center justify-center relative overflow-hidden">
              <div className="absolute inset-0 bg-black/20" />
              <div className="relative text-center text-white z-10">
                <PlayCircle className="w-20 h-20 mx-auto mb-4" />
                <h3 className="mb-2">Getting Started Tutorial</h3>
                <p className="text-sm text-blue-100">Watch our comprehensive guide (Coming Soon)</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Step by Step Guide */}
        <div>
          <h2 className="text-blue-900 dark:text-white mb-4">Step-by-Step Guide</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {steps.map((step, index) => {
              const Icon = step.icon;
              return (
                <Card 
                  key={index}
                  className="bg-white/80 dark:bg-gray-800/80 backdrop-blur-lg border-blue-200 dark:border-gray-700 hover:shadow-xl transition-all"
                >
                  <CardContent className="pt-6">
                    <div className="text-center space-y-4">
                      <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-gradient-to-br from-blue-500 to-blue-600">
                        <Icon className="w-8 h-8 text-white" />
                      </div>
                      <div>
                        <div className="flex items-center justify-center gap-2 mb-2">
                          <span className="inline-flex items-center justify-center w-6 h-6 rounded-full bg-blue-100 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400 text-sm">
                            {index + 1}
                          </span>
                          <h3 className="text-gray-900 dark:text-white">{step.title}</h3>
                        </div>
                        <p className="text-sm text-gray-600 dark:text-gray-400">{step.description}</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </div>

        {/* Features */}
        <Card className="bg-white/80 dark:bg-gray-800/80 backdrop-blur-lg border-blue-200 dark:border-gray-700">
          <CardHeader>
            <CardTitle className="text-blue-900 dark:text-white">Key Features</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {features.map((feature, index) => (
                <div key={index} className="flex items-center gap-3 p-3 rounded-lg bg-blue-50 dark:bg-blue-900/20">
                  <CheckCircle className="w-5 h-5 text-blue-600 dark:text-blue-400 flex-shrink-0" />
                  <span className="text-gray-700 dark:text-gray-300">{feature}</span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Security Tips */}
        <div>
          <h2 className="text-blue-900 dark:text-white mb-4">Phishing Prevention Tips</h2>
          <div className="space-y-3">
            {tips.map((tip, index) => (
              <Card 
                key={index}
                className="bg-white/80 dark:bg-gray-800/80 backdrop-blur-lg border-blue-200 dark:border-gray-700"
              >
                <CardContent className="pt-6">
                  <div className="flex items-start gap-4">
                    <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-yellow-500 to-orange-500 flex items-center justify-center flex-shrink-0">
                      <AlertCircle className="w-5 h-5 text-white" />
                    </div>
                    <div>
                      <h3 className="text-gray-900 dark:text-white mb-1">{tip.title}</h3>
                      <p className="text-sm text-gray-600 dark:text-gray-400">{tip.description}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* Quick Actions */}
        <Card className="bg-gradient-to-br from-blue-500 to-blue-600 border-0 text-white">
          <CardContent className="pt-6">
            <div className="flex flex-col md:flex-row items-center justify-between gap-4">
              <div>
                <h3 className="mb-2">Ready to Get Started?</h3>
                <p className="text-sm text-blue-100">
                  Install our browser extension or desktop app for enhanced protection
                </p>
              </div>
              <div className="flex gap-3">
                <Button variant="secondary" size="sm" className="gap-2">
                  <Chrome className="w-4 h-4" />
                  Get Extension
                </Button>
                <Button variant="secondary" size="sm" className="gap-2">
                  <Download className="w-4 h-4" />
                  Download App
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  );
}
