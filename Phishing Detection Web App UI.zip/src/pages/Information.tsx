import { DashboardLayout } from '../components/DashboardLayout';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { Badge } from '../components/ui/badge';
import { 
  Shield, Lock, Eye, Database, Zap, Globe, 
  Award, Check, AlertTriangle, Info
} from 'lucide-react';

export default function Information() {
  const securityFeatures = [
    {
      icon: Shield,
      title: 'Advanced AI Detection',
      description: 'Our machine learning algorithms analyze millions of data points to identify phishing attempts with 98.2% accuracy.',
      color: 'from-blue-500 to-blue-600',
    },
    {
      icon: Lock,
      title: 'End-to-End Encryption',
      description: 'All data transmitted through our platform is encrypted using industry-standard AES-256 encryption.',
      color: 'from-green-500 to-green-600',
    },
    {
      icon: Eye,
      title: 'Privacy First',
      description: 'We never store or share your browsing data. All URL checks are anonymous and secure.',
      color: 'from-purple-500 to-purple-600',
    },
    {
      icon: Database,
      title: 'Real-Time Database',
      description: 'Connected to global threat intelligence networks with updates every 5 minutes.',
      color: 'from-orange-500 to-orange-600',
    },
    {
      icon: Zap,
      title: 'Lightning Fast',
      description: 'Average scan time under 2 seconds with cloud-powered processing.',
      color: 'from-yellow-500 to-yellow-600',
    },
    {
      icon: Globe,
      title: 'Global Coverage',
      description: 'Protecting users in over 150 countries with multi-language support.',
      color: 'from-pink-500 to-pink-600',
    },
  ];

  const compliance = [
    'GDPR Compliant',
    'ISO 27001 Certified',
    'SOC 2 Type II',
    'CCPA Compliant',
    'PCI DSS Level 1',
    'HIPAA Compliant',
  ];

  const versionInfo = {
    version: '2.5.1',
    releaseDate: 'November 10, 2025',
    buildNumber: '20251110',
    platform: 'Web Application',
  };

  const detectionMethods = [
    {
      method: 'URL Analysis',
      description: 'Deep inspection of domain structure, suspicious patterns, and known malicious indicators',
    },
    {
      method: 'SSL Certificate Verification',
      description: 'Validates security certificates and checks for certificate authority legitimacy',
    },
    {
      method: 'Content Analysis',
      description: 'Examines webpage content for phishing keywords and suspicious forms',
    },
    {
      method: 'Behavioral Analysis',
      description: 'Monitors redirect chains, JavaScript execution, and loading patterns',
    },
    {
      method: 'Reputation Scoring',
      description: 'Cross-references with global threat databases and user reports',
    },
    {
      method: 'Machine Learning',
      description: 'AI models trained on millions of legitimate and malicious websites',
    },
  ];

  return (
    <DashboardLayout>
      <div className="space-y-6">
        {/* Header */}
        <div>
          <h1 className="text-blue-900 dark:text-white mb-2">Information & Security</h1>
          <p className="text-gray-600 dark:text-gray-400">
            Learn about our security features, compliance, and technology
          </p>
        </div>

        {/* Version Info */}
        <Card className="bg-gradient-to-br from-blue-500 to-blue-600 border-0 text-white">
          <CardContent className="pt-6">
            <div className="flex flex-col md:flex-row items-center justify-between gap-4">
              <div className="flex items-center gap-4">
                <div className="w-16 h-16 rounded-xl bg-white/20 backdrop-blur-lg flex items-center justify-center">
                  <Shield className="w-8 h-8 text-white" />
                </div>
                <div>
                  <h2 className="text-white mb-1">PhishGuard</h2>
                  <p className="text-sm text-blue-100">Advanced Phishing Detection Platform</p>
                </div>
              </div>
              <div className="text-center md:text-right">
                <Badge variant="secondary" className="mb-2">
                  {versionInfo.version}
                </Badge>
                <p className="text-sm text-blue-100">Released: {versionInfo.releaseDate}</p>
                <p className="text-xs text-blue-200">Build: {versionInfo.buildNumber}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Security Features */}
        <div>
          <h2 className="text-blue-900 dark:text-white mb-4">Security Features</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {securityFeatures.map((feature, index) => {
              const Icon = feature.icon;
              return (
                <Card 
                  key={index}
                  className="bg-white/80 dark:bg-gray-800/80 backdrop-blur-lg border-blue-200 dark:border-gray-700 hover:shadow-xl transition-all"
                >
                  <CardContent className="pt-6">
                    <div className="space-y-3">
                      <div className={`w-12 h-12 rounded-lg bg-gradient-to-br ${feature.color} flex items-center justify-center`}>
                        <Icon className="w-6 h-6 text-white" />
                      </div>
                      <div>
                        <h3 className="text-gray-900 dark:text-white mb-2">{feature.title}</h3>
                        <p className="text-sm text-gray-600 dark:text-gray-400">{feature.description}</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </div>

        {/* Detection Methods */}
        <Card className="bg-white/80 dark:bg-gray-800/80 backdrop-blur-lg border-blue-200 dark:border-gray-700">
          <CardHeader>
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-lg bg-blue-100 dark:bg-blue-900/30 flex items-center justify-center">
                <AlertTriangle className="w-5 h-5 text-blue-600 dark:text-blue-400" />
              </div>
              <CardTitle className="text-blue-900 dark:text-white">Detection Methods</CardTitle>
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {detectionMethods.map((method, index) => (
                <div 
                  key={index}
                  className="flex items-start gap-3 p-4 rounded-lg bg-gray-50 dark:bg-gray-900/50"
                >
                  <Check className="w-5 h-5 text-blue-600 dark:text-blue-400 flex-shrink-0 mt-0.5" />
                  <div>
                    <h3 className="text-gray-900 dark:text-white mb-1">{method.method}</h3>
                    <p className="text-sm text-gray-600 dark:text-gray-400">{method.description}</p>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Compliance & Certifications */}
        <Card className="bg-white/80 dark:bg-gray-800/80 backdrop-blur-lg border-blue-200 dark:border-gray-700">
          <CardHeader>
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-lg bg-green-100 dark:bg-green-900/30 flex items-center justify-center">
                <Award className="w-5 h-5 text-green-600 dark:text-green-400" />
              </div>
              <CardTitle className="text-blue-900 dark:text-white">Compliance & Certifications</CardTitle>
            </div>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
              {compliance.map((cert, index) => (
                <div 
                  key={index}
                  className="flex items-center gap-2 p-3 rounded-lg bg-green-50 dark:bg-green-900/20 border border-green-200 dark:border-green-800"
                >
                  <Check className="w-5 h-5 text-green-600 dark:text-green-400" />
                  <span className="text-sm text-gray-900 dark:text-white">{cert}</span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Privacy Policy */}
        <Card className="bg-white/80 dark:bg-gray-800/80 backdrop-blur-lg border-blue-200 dark:border-gray-700">
          <CardHeader>
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-lg bg-purple-100 dark:bg-purple-900/30 flex items-center justify-center">
                <Lock className="w-5 h-5 text-purple-600 dark:text-purple-400" />
              </div>
              <CardTitle className="text-blue-900 dark:text-white">Privacy & Data Protection</CardTitle>
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-4 text-gray-700 dark:text-gray-300">
              <div>
                <h3 className="text-gray-900 dark:text-white mb-2">What We Collect</h3>
                <p className="text-sm">
                  We only collect minimal data necessary for service operation: scan timestamps, 
                  threat detection results (anonymized), and basic usage statistics. We never store 
                  the actual URLs you scan or any personal browsing data.
                </p>
              </div>
              <div>
                <h3 className="text-gray-900 dark:text-white mb-2">Data Storage</h3>
                <p className="text-sm">
                  All data is encrypted at rest using AES-256 encryption and stored in secure, 
                  geographically distributed data centers with regular backups and disaster recovery protocols.
                </p>
              </div>
              <div>
                <h3 className="text-gray-900 dark:text-white mb-2">Third-Party Sharing</h3>
                <p className="text-sm">
                  We never sell or share your data with third parties. Threat intelligence is shared 
                  anonymously with security partners to improve global protection.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Support Info */}
        <Card className="bg-gradient-to-br from-orange-500 to-orange-600 border-0 text-white">
          <CardContent className="pt-6">
            <div className="flex items-start gap-4">
              <Info className="w-6 h-6 flex-shrink-0 mt-1" />
              <div>
                <h3 className="mb-2">Need More Information?</h3>
                <p className="text-sm text-orange-100 mb-4">
                  Visit our documentation portal or contact our security team for detailed technical specifications 
                  and compliance reports.
                </p>
                <div className="flex flex-wrap gap-2">
                  <Badge variant="secondary">Documentation</Badge>
                  <Badge variant="secondary">API Reference</Badge>
                  <Badge variant="secondary">Security Whitepaper</Badge>
                  <Badge variant="secondary">Compliance Reports</Badge>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  );
}
