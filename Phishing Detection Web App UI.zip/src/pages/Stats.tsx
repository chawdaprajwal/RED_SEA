import { DashboardLayout } from '../components/DashboardLayout';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../components/ui/card';
import { 
  BarChart, Bar, LineChart, Line, PieChart, Pie, Cell,
  XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer
} from 'recharts';
import { TrendingUp, TrendingDown, Shield, AlertTriangle } from 'lucide-react';

export default function Stats() {
  // Mock data for charts
  const weeklyScans = [
    { day: 'Mon', scans: 45, threats: 5 },
    { day: 'Tue', scans: 52, threats: 8 },
    { day: 'Wed', scans: 38, threats: 3 },
    { day: 'Thu', scans: 61, threats: 12 },
    { day: 'Fri', scans: 48, threats: 6 },
    { day: 'Sat', scans: 25, threats: 2 },
    { day: 'Sun', scans: 18, threats: 1 },
  ];

  const monthlyTrend = [
    { month: 'Jan', safe: 450, malicious: 45 },
    { month: 'Feb', safe: 520, malicious: 38 },
    { month: 'Mar', safe: 680, malicious: 52 },
    { month: 'Apr', safe: 590, malicious: 47 },
    { month: 'May', safe: 720, malicious: 61 },
    { month: 'Jun', safe: 810, malicious: 55 },
  ];

  const threatTypes = [
    { name: 'Phishing', value: 45, color: '#ef4444' },
    { name: 'Malware', value: 23, color: '#f97316' },
    { name: 'Suspicious', value: 18, color: '#eab308' },
    { name: 'Safe', value: 314, color: '#22c55e' },
  ];

  return (
    <DashboardLayout>
      <div className="space-y-6">
        {/* Header */}
        <div>
          <h1 className="text-blue-900 dark:text-white mb-2">Statistics & Analytics</h1>
          <p className="text-gray-600 dark:text-gray-400">
            Comprehensive overview of your scanning activity
          </p>
        </div>

        {/* Quick Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Card className="bg-white/80 dark:bg-gray-800/80 backdrop-blur-lg border-blue-200 dark:border-gray-700">
            <CardContent className="pt-6">
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-sm text-gray-600 dark:text-gray-400">Total Scans</span>
                  <TrendingUp className="w-4 h-4 text-green-600" />
                </div>
                <p className="text-2xl text-blue-900 dark:text-white">287</p>
                <p className="text-xs text-green-600">+12.5% from last week</p>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-white/80 dark:bg-gray-800/80 backdrop-blur-lg border-blue-200 dark:border-gray-700">
            <CardContent className="pt-6">
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-sm text-gray-600 dark:text-gray-400">Threats Found</span>
                  <AlertTriangle className="w-4 h-4 text-red-600" />
                </div>
                <p className="text-2xl text-red-600 dark:text-red-400">37</p>
                <p className="text-xs text-red-600">+3 from last week</p>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-white/80 dark:bg-gray-800/80 backdrop-blur-lg border-blue-200 dark:border-gray-700">
            <CardContent className="pt-6">
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-sm text-gray-600 dark:text-gray-400">Safe URLs</span>
                  <Shield className="w-4 h-4 text-green-600" />
                </div>
                <p className="text-2xl text-green-600 dark:text-green-400">250</p>
                <p className="text-xs text-green-600">87.1% success rate</p>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-white/80 dark:bg-gray-800/80 backdrop-blur-lg border-blue-200 dark:border-gray-700">
            <CardContent className="pt-6">
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-sm text-gray-600 dark:text-gray-400">Detection Rate</span>
                  <TrendingDown className="w-4 h-4 text-blue-600" />
                </div>
                <p className="text-2xl text-blue-900 dark:text-white">98.2%</p>
                <p className="text-xs text-blue-600">Industry leading</p>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Charts Row 1 */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Weekly Scans */}
          <Card className="bg-white/80 dark:bg-gray-800/80 backdrop-blur-lg border-blue-200 dark:border-gray-700">
            <CardHeader>
              <CardTitle className="text-blue-900 dark:text-white">Weekly Scan Activity</CardTitle>
              <CardDescription className="dark:text-gray-400">Scans vs Threats Detected</CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={weeklyScans}>
                  <CartesianGrid strokeDasharray="3 3" className="dark:opacity-20" />
                  <XAxis dataKey="day" className="dark:text-gray-400" />
                  <YAxis className="dark:text-gray-400" />
                  <Tooltip 
                    contentStyle={{ 
                      backgroundColor: 'rgba(255, 255, 255, 0.95)', 
                      border: '1px solid #3b82f6',
                      borderRadius: '8px'
                    }} 
                  />
                  <Legend />
                  <Bar dataKey="scans" fill="#3b82f6" name="Total Scans" radius={[8, 8, 0, 0]} />
                  <Bar dataKey="threats" fill="#ef4444" name="Threats" radius={[8, 8, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          {/* Threat Distribution */}
          <Card className="bg-white/80 dark:bg-gray-800/80 backdrop-blur-lg border-blue-200 dark:border-gray-700">
            <CardHeader>
              <CardTitle className="text-blue-900 dark:text-white">URL Distribution</CardTitle>
              <CardDescription className="dark:text-gray-400">Breakdown by threat type</CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <PieChart>
                  <Pie
                    data={threatTypes}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                    outerRadius={100}
                    fill="#8884d8"
                    dataKey="value"
                  >
                    {threatTypes.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </div>

        {/* Monthly Trend */}
        <Card className="bg-white/80 dark:bg-gray-800/80 backdrop-blur-lg border-blue-200 dark:border-gray-700">
          <CardHeader>
            <CardTitle className="text-blue-900 dark:text-white">6-Month Trend Analysis</CardTitle>
            <CardDescription className="dark:text-gray-400">Safe vs Malicious URLs over time</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={350}>
              <LineChart data={monthlyTrend}>
                <CartesianGrid strokeDasharray="3 3" className="dark:opacity-20" />
                <XAxis dataKey="month" className="dark:text-gray-400" />
                <YAxis className="dark:text-gray-400" />
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: 'rgba(255, 255, 255, 0.95)', 
                    border: '1px solid #3b82f6',
                    borderRadius: '8px'
                  }} 
                />
                <Legend />
                <Line 
                  type="monotone" 
                  dataKey="safe" 
                  stroke="#22c55e" 
                  strokeWidth={3}
                  name="Safe URLs"
                  dot={{ r: 6 }}
                  activeDot={{ r: 8 }}
                />
                <Line 
                  type="monotone" 
                  dataKey="malicious" 
                  stroke="#ef4444" 
                  strokeWidth={3}
                  name="Malicious URLs"
                  dot={{ r: 6 }}
                  activeDot={{ r: 8 }}
                />
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Recent Activity */}
        <Card className="bg-white/80 dark:bg-gray-800/80 backdrop-blur-lg border-blue-200 dark:border-gray-700">
          <CardHeader>
            <CardTitle className="text-blue-900 dark:text-white">Recent Scan History</CardTitle>
            <CardDescription className="dark:text-gray-400">Last 5 URL scans</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {[
                { url: 'https://example-safe.com', status: 'safe', time: '2 mins ago' },
                { url: 'https://suspicious-link.net', status: 'danger', time: '15 mins ago' },
                { url: 'https://trusted-site.org', status: 'safe', time: '1 hour ago' },
                { url: 'https://phishing-attempt.com', status: 'danger', time: '3 hours ago' },
                { url: 'https://legitimate-business.com', status: 'safe', time: '5 hours ago' },
              ].map((scan, index) => (
                <div key={index} className="flex items-center justify-between p-4 rounded-lg bg-gray-50 dark:bg-gray-900/50">
                  <div className="flex items-center gap-3 flex-1 min-w-0">
                    {scan.status === 'safe' ? (
                      <Shield className="w-5 h-5 text-green-600 flex-shrink-0" />
                    ) : (
                      <AlertTriangle className="w-5 h-5 text-red-600 flex-shrink-0" />
                    )}
                    <div className="min-w-0 flex-1">
                      <p className="text-sm text-gray-900 dark:text-white truncate">{scan.url}</p>
                      <p className="text-xs text-gray-500 dark:text-gray-400">{scan.time}</p>
                    </div>
                  </div>
                  <span className={`px-3 py-1 rounded-full text-xs whitespace-nowrap ${
                    scan.status === 'safe' 
                      ? 'bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400' 
                      : 'bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-400'
                  }`}>
                    {scan.status === 'safe' ? 'Safe' : 'Threat'}
                  </span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  );
}
