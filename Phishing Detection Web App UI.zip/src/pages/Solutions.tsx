import { useState } from 'react';
import { DashboardLayout } from '../components/DashboardLayout';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../components/ui/card';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { Label } from '../components/ui/label';
import { Textarea } from '../components/ui/textarea';
import { Badge } from '../components/ui/badge';
import { 
  CreditCard, Check, FileText, Code, Key, 
  HelpCircle, Send, Building2, Sparkles, Crown, Rocket
} from 'lucide-react';
import { toast } from 'sonner@2.0.3';

export default function Solutions() {
  const [apiKey, setApiKey] = useState('');
  const [endpoint, setEndpoint] = useState('');
  const [contactMessage, setContactMessage] = useState('');

  const handleContractRequest = () => {
    toast.success('Contract request submitted! Our team will contact you within 24 hours.');
  };

  const handleAPIIntegration = () => {
    if (!apiKey || !endpoint) {
      toast.error('Please fill all API configuration fields');
      return;
    }
    toast.success('API integration configured successfully!');
  };

  const handleContactSupport = () => {
    if (!contactMessage) {
      toast.error('Please enter your message');
      return;
    }
    toast.success('Message sent! Our support team will respond shortly.');
    setContactMessage('');
  };

  const plans = [
    {
      name: 'Basic',
      icon: Sparkles,
      price: '₹499',
      period: '/month',
      description: 'Perfect for individuals and freelancers',
      features: [
        'Up to 100 URL scans per day',
        'Basic threat detection',
        'Email support',
        'Browser extension',
        'Mobile app access',
        'Basic analytics',
      ],
      color: 'from-blue-500 to-blue-600',
      popular: false,
    },
    {
      name: 'Pro',
      icon: Crown,
      price: '₹1,499',
      period: '/month',
      description: 'Ideal for small businesses and teams',
      features: [
        'Unlimited URL scans',
        'Advanced AI detection',
        'Priority support (24/7)',
        'All apps & extensions',
        'Advanced analytics & reports',
        'API access (10k calls/month)',
        'Team collaboration (up to 10 users)',
        'Custom integration options',
      ],
      color: 'from-purple-500 to-purple-600',
      popular: true,
    },
    {
      name: 'Enterprise',
      icon: Rocket,
      price: 'Custom',
      period: '',
      description: 'For large organizations with specific needs',
      features: [
        'Everything in Pro',
        'Unlimited API calls',
        'Dedicated account manager',
        'Custom deployment options',
        'SLA guarantees (99.99% uptime)',
        'Advanced security features',
        'Custom threat intelligence',
        'Compliance assistance',
        'White-label options',
        'On-premise deployment available',
      ],
      color: 'from-orange-500 to-red-500',
      popular: false,
    },
  ];

  return (
    <DashboardLayout>
      <div className="space-y-8">
        {/* Header */}
        <div>
          <h1 className="text-blue-900 dark:text-white mb-2">Solutions & Pricing</h1>
          <p className="text-gray-600 dark:text-gray-400">
            Choose the perfect plan for your needs
          </p>
        </div>

        {/* Subscription Plans */}
        <div>
          <h2 className="text-blue-900 dark:text-white mb-6 text-center">Subscription Plans</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {plans.map((plan, index) => {
              const Icon = plan.icon;
              return (
                <Card 
                  key={index}
                  className={`bg-white/80 dark:bg-gray-800/80 backdrop-blur-lg border-blue-200 dark:border-gray-700 hover:shadow-2xl transition-all relative ${
                    plan.popular ? 'ring-2 ring-purple-500 scale-105' : ''
                  }`}
                >
                  {plan.popular && (
                    <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                      <Badge className="bg-purple-500 text-white px-4 py-1">
                        Most Popular
                      </Badge>
                    </div>
                  )}
                  <CardHeader>
                    <div className="flex items-center justify-between mb-4">
                      <div className={`w-12 h-12 rounded-lg bg-gradient-to-br ${plan.color} flex items-center justify-center`}>
                        <Icon className="w-6 h-6 text-white" />
                      </div>
                      <div className="text-right">
                        <div className="flex items-baseline">
                          <span className="text-3xl text-blue-900 dark:text-white">{plan.price}</span>
                          <span className="text-sm text-gray-600 dark:text-gray-400">{plan.period}</span>
                        </div>
                      </div>
                    </div>
                    <CardTitle className="text-blue-900 dark:text-white">{plan.name}</CardTitle>
                    <CardDescription className="dark:text-gray-400">{plan.description}</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <ul className="space-y-3 mb-6">
                      {plan.features.map((feature, fIndex) => (
                        <li key={fIndex} className="flex items-start gap-2">
                          <Check className="w-5 h-5 text-green-600 dark:text-green-400 flex-shrink-0 mt-0.5" />
                          <span className="text-sm text-gray-700 dark:text-gray-300">{feature}</span>
                        </li>
                      ))}
                    </ul>
                    <Button 
                      className={`w-full ${plan.popular ? 'bg-purple-600 hover:bg-purple-700' : 'bg-blue-600 hover:bg-blue-700'} text-white`}
                    >
                      {plan.name === 'Enterprise' ? 'Contact Sales' : 'Subscribe Now'}
                    </Button>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </div>

        {/* Company Contract */}
        <Card className="bg-white/80 dark:bg-gray-800/80 backdrop-blur-lg border-blue-200 dark:border-gray-700">
          <CardHeader>
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-green-500 to-green-600 flex items-center justify-center">
                <FileText className="w-5 h-5 text-white" />
              </div>
              <div>
                <CardTitle className="text-blue-900 dark:text-white">Company Contract</CardTitle>
                <CardDescription className="dark:text-gray-400">
                  Request a custom enterprise contract tailored to your organization
                </CardDescription>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="companyName" className="dark:text-gray-300">Company Name</Label>
                  <div className="relative">
                    <Building2 className="absolute left-3 top-3 h-5 w-5 text-gray-400" />
                    <Input
                      id="companyName"
                      placeholder="Your Company Ltd."
                      className="pl-10 dark:bg-gray-900/50 dark:border-gray-700"
                    />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="companyEmail" className="dark:text-gray-300">Business Email</Label>
                  <Input
                    id="companyEmail"
                    type="email"
                    placeholder="contact@company.com"
                    className="dark:bg-gray-900/50 dark:border-gray-700"
                  />
                </div>
              </div>
              <Button onClick={handleContractRequest} className="w-full bg-green-600 hover:bg-green-700 text-white">
                Request Contract
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* API Integration */}
        <Card className="bg-white/80 dark:bg-gray-800/80 backdrop-blur-lg border-blue-200 dark:border-gray-700">
          <CardHeader>
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-blue-500 to-blue-600 flex items-center justify-center">
                <Code className="w-5 h-5 text-white" />
              </div>
              <div>
                <CardTitle className="text-blue-900 dark:text-white">API Integration</CardTitle>
                <CardDescription className="dark:text-gray-400">
                  Integrate PhishGuard into your own applications
                </CardDescription>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="apiKey" className="dark:text-gray-300">API Key</Label>
                <div className="relative">
                  <Key className="absolute left-3 top-3 h-5 w-5 text-gray-400" />
                  <Input
                    id="apiKey"
                    type="password"
                    placeholder="pk_live_xxxxxxxxxxxx"
                    value={apiKey}
                    onChange={(e) => setApiKey(e.target.value)}
                    className="pl-10 dark:bg-gray-900/50 dark:border-gray-700"
                  />
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="endpoint" className="dark:text-gray-300">Endpoint URL</Label>
                <Input
                  id="endpoint"
                  type="url"
                  placeholder="https://api.phishguard.com/v1/"
                  value={endpoint}
                  onChange={(e) => setEndpoint(e.target.value)}
                  className="dark:bg-gray-900/50 dark:border-gray-700"
                />
              </div>
              <div className="p-4 rounded-lg bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800">
                <p className="text-sm text-gray-700 dark:text-gray-300 mb-2">Example API Request:</p>
                <code className="text-xs bg-gray-900 text-green-400 p-3 rounded block overflow-x-auto">
                  curl -X POST https://api.phishguard.com/v1/scan \<br />
                  &nbsp;&nbsp;-H "Authorization: Bearer YOUR_API_KEY" \<br />
                  &nbsp;&nbsp;-d '{{"url": "https://example.com"}}'
                </code>
              </div>
              <Button onClick={handleAPIIntegration} className="w-full bg-blue-600 hover:bg-blue-700 text-white">
                Configure Integration
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Contact Support */}
        <Card className="bg-white/80 dark:bg-gray-800/80 backdrop-blur-lg border-blue-200 dark:border-gray-700">
          <CardHeader>
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-pink-500 to-pink-600 flex items-center justify-center">
                <HelpCircle className="w-5 h-5 text-white" />
              </div>
              <div>
                <CardTitle className="text-blue-900 dark:text-white">Contact Support</CardTitle>
                <CardDescription className="dark:text-gray-400">
                  Have questions? Our team is here to help
                </CardDescription>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="message" className="dark:text-gray-300">Your Message</Label>
                <Textarea
                  id="message"
                  placeholder="Tell us how we can help you..."
                  value={contactMessage}
                  onChange={(e) => setContactMessage(e.target.value)}
                  rows={4}
                  className="dark:bg-gray-900/50 dark:border-gray-700"
                />
              </div>
              <Button onClick={handleContactSupport} className="w-full bg-pink-600 hover:bg-pink-700 text-white gap-2">
                <Send className="w-4 h-4" />
                Send Message
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* FAQ */}
        <Card className="bg-gradient-to-br from-blue-500 to-blue-600 border-0 text-white">
          <CardContent className="pt-6">
            <h3 className="mb-4">Frequently Asked Questions</h3>
            <div className="space-y-3">
              <div>
                <p className="text-sm opacity-90">Q: Can I upgrade or downgrade my plan anytime?</p>
                <p className="text-sm text-blue-100">A: Yes, you can change your plan at any time. Changes take effect immediately.</p>
              </div>
              <div>
                <p className="text-sm opacity-90">Q: Is there a free trial available?</p>
                <p className="text-sm text-blue-100">A: Yes! All plans come with a 14-day free trial. No credit card required.</p>
              </div>
              <div>
                <p className="text-sm opacity-90">Q: What payment methods do you accept?</p>
                <p className="text-sm text-blue-100">A: We accept UPI, credit/debit cards, net banking, and for enterprise clients, invoicing is available.</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  );
}
