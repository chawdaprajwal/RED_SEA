import { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { Mail, Lock, Building2, Chrome } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { Label } from '../components/ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../components/ui/tabs';
import { toast } from 'sonner@2.0.3';

export default function Login() {
  const navigate = useNavigate();
  const { login, loginWithGoogle } = useAuth();
  const [loading, setLoading] = useState(false);

  // Regular login state
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  // Organization login state
  const [orgName, setOrgName] = useState('');
  const [workEmail, setWorkEmail] = useState('');
  const [employeeId, setEmployeeId] = useState('');
  const [orgPassword, setOrgPassword] = useState('');

  const handleRegularLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    
    try {
      const success = await login(email, password, false);
      if (success) {
        toast.success('Login successful!');
        navigate('/dashboard-user');
      } else {
        toast.error('Invalid credentials');
      }
    } catch (error) {
      toast.error('Login failed');
    } finally {
      setLoading(false);
    }
  };

  const handleOrganizationLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    
    try {
      const success = await login(workEmail, orgPassword, true);
      if (success) {
        toast.success('Organization login successful!');
        navigate('/dashboard-employee');
      } else {
        toast.error('Invalid credentials');
      }
    } catch (error) {
      toast.error('Login failed');
    } finally {
      setLoading(false);
    }
  };

  const handleGoogleLogin = async () => {
    setLoading(true);
    try {
      const success = await loginWithGoogle();
      if (success) {
        toast.success('Google login successful!');
        navigate('/dashboard-user');
      }
    } catch (error) {
      toast.error('Google login failed');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-blue-100 dark:from-gray-900 dark:via-gray-900 dark:to-blue-900/20 flex items-center justify-center p-4">
      <div className="w-full max-w-6xl grid lg:grid-cols-2 gap-8 items-center">
        {/* Left side - Branding */}
        <div className="hidden lg:block">
          <div className="space-y-6">
            <div className="flex items-center gap-4">
              <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-blue-500 to-blue-600 flex items-center justify-center shadow-xl">
                <span className="text-3xl">🛡️</span>
              </div>
              <div>
                <h1 className="text-blue-900 dark:text-white">PhishGuard</h1>
                <p className="text-blue-600 dark:text-blue-400">Advanced Phishing Detection</p>
              </div>
            </div>
            
            <div className="space-y-4 text-gray-700 dark:text-gray-300">
              <div className="flex items-start gap-3">
                <div className="w-8 h-8 rounded-full bg-blue-100 dark:bg-blue-900/30 flex items-center justify-center flex-shrink-0">
                  <span className="text-blue-600 dark:text-blue-400">✓</span>
                </div>
                <div>
                  <h3 className="text-gray-900 dark:text-white">Real-time URL Scanning</h3>
                  <p className="text-sm text-gray-600 dark:text-gray-400">Detect phishing attempts instantly</p>
                </div>
              </div>
              
              <div className="flex items-start gap-3">
                <div className="w-8 h-8 rounded-full bg-blue-100 dark:bg-blue-900/30 flex items-center justify-center flex-shrink-0">
                  <span className="text-blue-600 dark:text-blue-400">✓</span>
                </div>
                <div>
                  <h3 className="text-gray-900 dark:text-white">Advanced AI Detection</h3>
                  <p className="text-sm text-gray-600 dark:text-gray-400">Machine learning powered analysis</p>
                </div>
              </div>
              
              <div className="flex items-start gap-3">
                <div className="w-8 h-8 rounded-full bg-blue-100 dark:bg-blue-900/30 flex items-center justify-center flex-shrink-0">
                  <span className="text-blue-600 dark:text-blue-400">✓</span>
                </div>
                <div>
                  <h3 className="text-gray-900 dark:text-white">Enterprise Security</h3>
                  <p className="text-sm text-gray-600 dark:text-gray-400">Comprehensive protection for organizations</p>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Right side - Login Forms */}
        <Card className="w-full bg-white/80 dark:bg-gray-800/80 backdrop-blur-lg border-blue-200 dark:border-gray-700 shadow-2xl">
          <CardHeader>
            <CardTitle className="text-blue-900 dark:text-white">Welcome Back</CardTitle>
            <CardDescription className="dark:text-gray-400">Sign in to your account</CardDescription>
          </CardHeader>
          <CardContent>
            <Tabs defaultValue="regular" className="w-full">
              <TabsList className="grid w-full grid-cols-2 mb-6">
                <TabsTrigger value="regular">Personal Login</TabsTrigger>
                <TabsTrigger value="organization">Organization Login</TabsTrigger>
              </TabsList>

              {/* Regular Login */}
              <TabsContent value="regular">
                <form onSubmit={handleRegularLogin} className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="email" className="dark:text-gray-300">Email</Label>
                    <div className="relative">
                      <Mail className="absolute left-3 top-3 h-5 w-5 text-blue-500" />
                      <Input
                        id="email"
                        type="email"
                        placeholder="you@example.com"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        className="pl-10 dark:bg-gray-900/50 dark:border-gray-700"
                        required
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="password" className="dark:text-gray-300">Password</Label>
                    <div className="relative">
                      <Lock className="absolute left-3 top-3 h-5 w-5 text-blue-500" />
                      <Input
                        id="password"
                        type="password"
                        placeholder="••••••••"
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        className="pl-10 dark:bg-gray-900/50 dark:border-gray-700"
                        required
                      />
                    </div>
                  </div>

                  <Button
                    type="submit"
                    className="w-full bg-blue-600 hover:bg-blue-700 text-white"
                    disabled={loading}
                  >
                    {loading ? 'Signing in...' : 'Login'}
                  </Button>

                  <div className="relative my-6">
                    <div className="absolute inset-0 flex items-center">
                      <span className="w-full border-t border-gray-300 dark:border-gray-700" />
                    </div>
                    <div className="relative flex justify-center text-xs uppercase">
                      <span className="bg-white dark:bg-gray-800 px-2 text-gray-500">Or continue with</span>
                    </div>
                  </div>

                  <Button
                    type="button"
                    variant="outline"
                    onClick={handleGoogleLogin}
                    className="w-full border-blue-200 dark:border-gray-700"
                    disabled={loading}
                  >
                    <Chrome className="mr-2 h-5 w-5 text-blue-600" />
                    Login with Google
                  </Button>

                  <div className="text-center text-sm mt-4">
                    <span className="text-gray-600 dark:text-gray-400">Don't have an account? </span>
                    <Link to="/signup-user" className="text-blue-600 hover:underline">
                      Sign up
                    </Link>
                  </div>
                </form>
              </TabsContent>

              {/* Organization Login */}
              <TabsContent value="organization">
                <form onSubmit={handleOrganizationLogin} className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="orgName" className="dark:text-gray-300">Organization Name</Label>
                    <div className="relative">
                      <Building2 className="absolute left-3 top-3 h-5 w-5 text-blue-500" />
                      <Input
                        id="orgName"
                        type="text"
                        placeholder="Your Organization"
                        value={orgName}
                        onChange={(e) => setOrgName(e.target.value)}
                        className="pl-10 dark:bg-gray-900/50 dark:border-gray-700"
                        required
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="workEmail" className="dark:text-gray-300">Work Email</Label>
                    <div className="relative">
                      <Mail className="absolute left-3 top-3 h-5 w-5 text-blue-500" />
                      <Input
                        id="workEmail"
                        type="email"
                        placeholder="you@company.com"
                        value={workEmail}
                        onChange={(e) => setWorkEmail(e.target.value)}
                        className="pl-10 dark:bg-gray-900/50 dark:border-gray-700"
                        required
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="employeeId" className="dark:text-gray-300">Employee ID (Optional)</Label>
                    <Input
                      id="employeeId"
                      type="text"
                      placeholder="EMP12345"
                      value={employeeId}
                      onChange={(e) => setEmployeeId(e.target.value)}
                      className="dark:bg-gray-900/50 dark:border-gray-700"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="orgPassword" className="dark:text-gray-300">Password</Label>
                    <div className="relative">
                      <Lock className="absolute left-3 top-3 h-5 w-5 text-blue-500" />
                      <Input
                        id="orgPassword"
                        type="password"
                        placeholder="••••••••"
                        value={orgPassword}
                        onChange={(e) => setOrgPassword(e.target.value)}
                        className="pl-10 dark:bg-gray-900/50 dark:border-gray-700"
                        required
                      />
                    </div>
                  </div>

                  <Button
                    type="submit"
                    className="w-full bg-blue-600 hover:bg-blue-700 text-white"
                    disabled={loading}
                  >
                    {loading ? 'Signing in...' : 'Login as Employee'}
                  </Button>

                  <div className="text-center text-sm mt-4">
                    <span className="text-gray-600 dark:text-gray-400">Need an organization account? </span>
                    <Link to="/signup-employee" className="text-blue-600 hover:underline">
                      Sign up
                    </Link>
                  </div>
                </form>
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
