import { useState } from 'react';
import { DashboardLayout } from '../components/DashboardLayout';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../components/ui/card';
import { Button } from '../components/ui/button';
import { Badge } from '../components/ui/badge';
import { Progress } from '../components/ui/progress';
import { 
  Zap, Mail, Link2, Play, Trophy, Users, 
  Target, TrendingUp, AlertTriangle, CheckCircle, XCircle
} from 'lucide-react';
import { toast } from 'sonner@2.0.3';

export default function Simulation() {
  const [activeSimulation, setActiveSimulation] = useState<string | null>(null);
  const [simulationResults, setSimulationResults] = useState<any>(null);

  const handleStartSimulation = (type: string) => {
    setActiveSimulation(type);
    setSimulationResults(null);
    toast.success(`${type} simulation started!`);
    
    // Simulate completion after 3 seconds
    setTimeout(() => {
      const mockResults = {
        totalEmployees: 156,
        completed: 142,
        passed: 128,
        failed: 14,
        avgScore: 87,
        completionRate: 91,
      };
      setSimulationResults(mockResults);
      setActiveSimulation(null);
      toast.success('Simulation completed!');
    }, 3000);
  };

  const simulations = [
    {
      id: 'email-phishing',
      name: 'Email Phishing',
      icon: Mail,
      description: 'Test employee awareness with realistic phishing emails',
      difficulty: 'Medium',
      duration: '15 minutes',
      color: 'from-blue-500 to-blue-600',
      scenarios: 12,
    },
    {
      id: 'link-detection',
      name: 'Link Detection',
      icon: Link2,
      description: 'Challenge users to identify malicious URLs',
      difficulty: 'Easy',
      duration: '10 minutes',
      color: 'from-green-500 to-green-600',
      scenarios: 8,
    },
    {
      id: 'advanced-threats',
      name: 'Advanced Threats',
      icon: Zap,
      description: 'Complex scenarios including spear-phishing and social engineering',
      difficulty: 'Hard',
      duration: '25 minutes',
      color: 'from-red-500 to-red-600',
      scenarios: 15,
    },
  ];

  const recentSimulations = [
    {
      date: '2025-11-10',
      type: 'Email Phishing',
      participants: 156,
      avgScore: 87,
      status: 'completed',
    },
    {
      date: '2025-11-05',
      type: 'Link Detection',
      participants: 148,
      avgScore: 92,
      status: 'completed',
    },
    {
      date: '2025-10-28',
      type: 'Advanced Threats',
      participants: 142,
      avgScore: 78,
      status: 'completed',
    },
  ];

  const leaderboard = [
    { name: 'Sarah Johnson', department: 'IT Security', score: 98, rank: 1 },
    { name: 'Michael Chen', department: 'Engineering', score: 96, rank: 2 },
    { name: 'Emily Davis', department: 'HR', score: 94, rank: 3 },
    { name: 'David Wilson', department: 'Finance', score: 92, rank: 4 },
    { name: 'Lisa Anderson', department: 'Operations', score: 90, rank: 5 },
  ];

  return (
    <DashboardLayout>
      <div className="space-y-6">
        {/* Header */}
        <div>
          <h1 className="text-blue-900 dark:text-white mb-2">Phishing Simulation Training</h1>
          <p className="text-gray-600 dark:text-gray-400">
            Test and improve your team's security awareness
          </p>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Card className="bg-white/80 dark:bg-gray-800/80 backdrop-blur-lg border-blue-200 dark:border-gray-700">
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600 dark:text-gray-400">Total Simulations</p>
                  <p className="text-2xl text-blue-900 dark:text-white mt-1">28</p>
                </div>
                <div className="w-12 h-12 rounded-lg bg-blue-100 dark:bg-blue-900/30 flex items-center justify-center">
                  <Target className="w-6 h-6 text-blue-600 dark:text-blue-400" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-white/80 dark:bg-gray-800/80 backdrop-blur-lg border-blue-200 dark:border-gray-700">
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600 dark:text-gray-400">Average Score</p>
                  <p className="text-2xl text-green-600 dark:text-green-400 mt-1">87%</p>
                </div>
                <div className="w-12 h-12 rounded-lg bg-green-100 dark:bg-green-900/30 flex items-center justify-center">
                  <Trophy className="w-6 h-6 text-green-600 dark:text-green-400" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-white/80 dark:bg-gray-800/80 backdrop-blur-lg border-blue-200 dark:border-gray-700">
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600 dark:text-gray-400">Participants</p>
                  <p className="text-2xl text-purple-600 dark:text-purple-400 mt-1">156</p>
                </div>
                <div className="w-12 h-12 rounded-lg bg-purple-100 dark:bg-purple-900/30 flex items-center justify-center">
                  <Users className="w-6 h-6 text-purple-600 dark:text-purple-400" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-white/80 dark:bg-gray-800/80 backdrop-blur-lg border-blue-200 dark:border-gray-700">
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600 dark:text-gray-400">Improvement</p>
                  <p className="text-2xl text-orange-600 dark:text-orange-400 mt-1">+12%</p>
                </div>
                <div className="w-12 h-12 rounded-lg bg-orange-100 dark:bg-orange-900/30 flex items-center justify-center">
                  <TrendingUp className="w-6 h-6 text-orange-600 dark:text-orange-400" />
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Simulation Types */}
        <div>
          <h2 className="text-blue-900 dark:text-white mb-4">Available Simulations</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {simulations.map((sim) => {
              const Icon = sim.icon;
              return (
                <Card 
                  key={sim.id}
                  className="bg-white/80 dark:bg-gray-800/80 backdrop-blur-lg border-blue-200 dark:border-gray-700 hover:shadow-xl transition-all"
                >
                  <CardHeader>
                    <div className={`w-12 h-12 rounded-lg bg-gradient-to-br ${sim.color} flex items-center justify-center mb-3`}>
                      <Icon className="w-6 h-6 text-white" />
                    </div>
                    <div className="flex items-center justify-between mb-2">
                      <CardTitle className="text-blue-900 dark:text-white">{sim.name}</CardTitle>
                      <Badge 
                        variant={sim.difficulty === 'Easy' ? 'default' : sim.difficulty === 'Medium' ? 'secondary' : 'destructive'}
                      >
                        {sim.difficulty}
                      </Badge>
                    </div>
                    <CardDescription className="dark:text-gray-400">{sim.description}</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      <div className="flex items-center justify-between text-sm">
                        <span className="text-gray-600 dark:text-gray-400">Duration:</span>
                        <span className="text-gray-900 dark:text-white">{sim.duration}</span>
                      </div>
                      <div className="flex items-center justify-between text-sm">
                        <span className="text-gray-600 dark:text-gray-400">Scenarios:</span>
                        <span className="text-gray-900 dark:text-white">{sim.scenarios}</span>
                      </div>
                      <Button
                        onClick={() => handleStartSimulation(sim.name)}
                        disabled={activeSimulation !== null}
                        className="w-full bg-blue-600 hover:bg-blue-700 text-white gap-2"
                      >
                        <Play className="w-4 h-4" />
                        {activeSimulation === sim.name ? 'Running...' : 'Start Simulation'}
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </div>

        {/* Simulation Results */}
        {simulationResults && (
          <Card className="bg-white/80 dark:bg-gray-800/80 backdrop-blur-lg border-blue-200 dark:border-gray-700">
            <CardHeader>
              <CardTitle className="text-blue-900 dark:text-white">Latest Results</CardTitle>
              <CardDescription className="dark:text-gray-400">Simulation performance summary</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                  <div className="text-center p-4 rounded-lg bg-blue-50 dark:bg-blue-900/20">
                    <p className="text-sm text-gray-600 dark:text-gray-400 mb-1">Total Employees</p>
                    <p className="text-2xl text-blue-900 dark:text-white">{simulationResults.totalEmployees}</p>
                  </div>
                  <div className="text-center p-4 rounded-lg bg-green-50 dark:bg-green-900/20">
                    <p className="text-sm text-gray-600 dark:text-gray-400 mb-1">Passed</p>
                    <p className="text-2xl text-green-600">{simulationResults.passed}</p>
                  </div>
                  <div className="text-center p-4 rounded-lg bg-red-50 dark:bg-red-900/20">
                    <p className="text-sm text-gray-600 dark:text-gray-400 mb-1">Failed</p>
                    <p className="text-2xl text-red-600">{simulationResults.failed}</p>
                  </div>
                  <div className="text-center p-4 rounded-lg bg-purple-50 dark:bg-purple-900/20">
                    <p className="text-sm text-gray-600 dark:text-gray-400 mb-1">Average Score</p>
                    <p className="text-2xl text-purple-600">{simulationResults.avgScore}%</p>
                  </div>
                </div>

                <div>
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-sm text-gray-600 dark:text-gray-400">Completion Rate</span>
                    <span className="text-sm text-gray-900 dark:text-white">{simulationResults.completionRate}%</span>
                  </div>
                  <Progress value={simulationResults.completionRate} className="h-3" />
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Recent Simulations */}
        <Card className="bg-white/80 dark:bg-gray-800/80 backdrop-blur-lg border-blue-200 dark:border-gray-700">
          <CardHeader>
            <CardTitle className="text-blue-900 dark:text-white">Recent Simulations</CardTitle>
            <CardDescription className="dark:text-gray-400">Last 3 simulation campaigns</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {recentSimulations.map((sim, index) => (
                <div key={index} className="flex items-center justify-between p-4 rounded-lg bg-gray-50 dark:bg-gray-900/50">
                  <div className="flex items-center gap-4">
                    {sim.avgScore >= 85 ? (
                      <CheckCircle className="w-6 h-6 text-green-600" />
                    ) : sim.avgScore >= 70 ? (
                      <AlertTriangle className="w-6 h-6 text-yellow-600" />
                    ) : (
                      <XCircle className="w-6 h-6 text-red-600" />
                    )}
                    <div>
                      <p className="text-gray-900 dark:text-white">{sim.type}</p>
                      <p className="text-sm text-gray-600 dark:text-gray-400">
                        {sim.date} • {sim.participants} participants
                      </p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="text-gray-900 dark:text-white">Score: {sim.avgScore}%</p>
                    <Badge variant="outline" className="mt-1">
                      {sim.status}
                    </Badge>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Leaderboard */}
        <Card className="bg-white/80 dark:bg-gray-800/80 backdrop-blur-lg border-blue-200 dark:border-gray-700">
          <CardHeader>
            <div className="flex items-center gap-3">
              <Trophy className="w-6 h-6 text-yellow-500" />
              <CardTitle className="text-blue-900 dark:text-white">Top Performers</CardTitle>
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {leaderboard.map((person) => (
                <div 
                  key={person.rank}
                  className="flex items-center justify-between p-4 rounded-lg bg-gradient-to-r from-gray-50 to-transparent dark:from-gray-900/50 dark:to-transparent"
                >
                  <div className="flex items-center gap-4">
                    <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                      person.rank === 1 ? 'bg-yellow-500' :
                      person.rank === 2 ? 'bg-gray-400' :
                      person.rank === 3 ? 'bg-orange-600' :
                      'bg-blue-500'
                    }`}>
                      <span className="text-white text-sm">{person.rank}</span>
                    </div>
                    <div>
                      <p className="text-gray-900 dark:text-white">{person.name}</p>
                      <p className="text-sm text-gray-600 dark:text-gray-400">{person.department}</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="text-lg text-blue-900 dark:text-white">{person.score}%</p>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  );
}
