import { DashboardLayout } from '../components/DashboardLayout';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../components/ui/card';
import { Button } from '../components/ui/button';
import { Badge } from '../components/ui/badge';
import { 
  Download, Chrome, Apple, Monitor, Shield, 
  CheckCircle, Star, Users
} from 'lucide-react';
import { toast } from 'sonner@2.0.3';

export default function Downloads() {
  const handleDownload = (platform: string) => {
    toast.success(`Downloading PhishGuard for ${platform}...`);
  };

  const downloads = [
    {
      name: 'Windows Desktop',
      icon: Monitor,
      description: 'Full-featured desktop application for Windows 10/11',
      version: 'v2.5.1',
      size: '45 MB',
      platform: 'windows',
      features: [
        'Real-time URL scanning',
        'System tray integration',
        'Automatic updates',
        'Offline detection mode',
      ],
      color: 'from-blue-500 to-blue-600',
    },
    {
      name: 'macOS Desktop',
      icon: Apple,
      description: 'Native macOS application with Touch Bar support',
      version: 'v2.5.1',
      size: '38 MB',
      platform: 'macos',
      features: [
        'Touch Bar shortcuts',
        'Menu bar integration',
        'Notification center alerts',
        'Optimized for Apple Silicon',
      ],
      color: 'from-gray-600 to-gray-800',
    },
    {
      name: 'Chrome Extension',
      icon: Chrome,
      description: 'Browser extension for instant URL protection',
      version: 'v1.8.2',
      size: '2.5 MB',
      platform: 'chrome',
      features: [
        'One-click URL checking',
        'Real-time website alerts',
        'Password manager integration',
        'Works on all Chromium browsers',
      ],
      color: 'from-green-500 to-green-600',
    },
  ];

  const stats = [
    { label: 'Total Downloads', value: '500K+', icon: Download },
    { label: 'Active Users', value: '250K+', icon: Users },
    { label: 'Average Rating', value: '4.8/5', icon: Star },
    { label: 'Threats Blocked', value: '2M+', icon: Shield },
  ];

  return (
    <DashboardLayout>
      <div className="space-y-6">
        {/* Header */}
        <div>
          <h1 className="text-blue-900 dark:text-white mb-2">Downloads</h1>
          <p className="text-gray-600 dark:text-gray-400">
            Get PhishGuard on all your devices for maximum protection
          </p>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {stats.map((stat, index) => {
            const Icon = stat.icon;
            return (
              <Card 
                key={index}
                className="bg-white/80 dark:bg-gray-800/80 backdrop-blur-lg border-blue-200 dark:border-gray-700"
              >
                <CardContent className="pt-6">
                  <div className="text-center space-y-2">
                    <Icon className="w-6 h-6 text-blue-600 dark:text-blue-400 mx-auto" />
                    <p className="text-2xl text-blue-900 dark:text-white">{stat.value}</p>
                    <p className="text-xs text-gray-600 dark:text-gray-400">{stat.label}</p>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>

        {/* Download Cards */}
        <div className="space-y-6">
          {downloads.map((download, index) => {
            const Icon = download.icon;
            return (
              <Card 
                key={index}
                className="bg-white/80 dark:bg-gray-800/80 backdrop-blur-lg border-blue-200 dark:border-gray-700 hover:shadow-xl transition-all"
              >
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <div className="flex items-center gap-4">
                      <div className={`w-16 h-16 rounded-xl bg-gradient-to-br ${download.color} flex items-center justify-center`}>
                        <Icon className="w-8 h-8 text-white" />
                      </div>
                      <div>
                        <div className="flex items-center gap-2 mb-1">
                          <CardTitle className="text-blue-900 dark:text-white">{download.name}</CardTitle>
                          <Badge variant="outline" className="text-xs">
                            {download.version}
                          </Badge>
                        </div>
                        <CardDescription className="dark:text-gray-400">
                          {download.description}
                        </CardDescription>
                        <p className="text-xs text-gray-500 dark:text-gray-500 mt-1">
                          Size: {download.size}
                        </p>
                      </div>
                    </div>
                    <Button
                      onClick={() => handleDownload(download.name)}
                      className="bg-blue-600 hover:bg-blue-700 text-white gap-2"
                    >
                      <Download className="w-4 h-4" />
                      Download
                    </Button>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                    {download.features.map((feature, fIndex) => (
                      <div key={fIndex} className="flex items-center gap-2 text-sm">
                        <CheckCircle className="w-4 h-4 text-green-600 dark:text-green-400 flex-shrink-0" />
                        <span className="text-gray-700 dark:text-gray-300">{feature}</span>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>

        {/* System Requirements */}
        <Card className="bg-white/80 dark:bg-gray-800/80 backdrop-blur-lg border-blue-200 dark:border-gray-700">
          <CardHeader>
            <CardTitle className="text-blue-900 dark:text-white">System Requirements</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div>
                <h3 className="text-gray-900 dark:text-white mb-3">Windows</h3>
                <ul className="space-y-2 text-sm text-gray-600 dark:text-gray-400">
                  <li>• Windows 10 or later</li>
                  <li>• 4GB RAM minimum</li>
                  <li>• 100MB free space</li>
                  <li>• Internet connection</li>
                </ul>
              </div>
              <div>
                <h3 className="text-gray-900 dark:text-white mb-3">macOS</h3>
                <ul className="space-y-2 text-sm text-gray-600 dark:text-gray-400">
                  <li>• macOS 11.0 or later</li>
                  <li>• 4GB RAM minimum</li>
                  <li>• 80MB free space</li>
                  <li>• Internet connection</li>
                </ul>
              </div>
              <div>
                <h3 className="text-gray-900 dark:text-white mb-3">Browser Extension</h3>
                <ul className="space-y-2 text-sm text-gray-600 dark:text-gray-400">
                  <li>• Chrome 90+</li>
                  <li>• Edge 90+</li>
                  <li>• Brave 1.20+</li>
                  <li>• Opera 76+</li>
                </ul>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Help Section */}
        <Card className="bg-gradient-to-br from-purple-500 to-purple-600 border-0 text-white">
          <CardContent className="pt-6">
            <div className="text-center space-y-3">
              <h3 className="mb-2">Need Help Installing?</h3>
              <p className="text-sm text-purple-100 max-w-2xl mx-auto">
                Check our detailed installation guides or contact our support team for assistance
              </p>
              <div className="flex justify-center gap-3 pt-2">
                <Button variant="secondary" size="sm">
                  View Installation Guide
                </Button>
                <Button variant="secondary" size="sm">
                  Contact Support
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  );
}
