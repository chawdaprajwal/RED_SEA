import { useState } from 'react';
import { Menu } from 'lucide-react';
import { Sidebar } from './Sidebar';
import { ThemeToggle } from './ThemeToggle';
import { Button } from './ui/button';

interface DashboardLayoutProps {
  children: React.ReactNode;
}

export const DashboardLayout = ({ children }: DashboardLayoutProps) => {
  const [sidebarOpen, setSidebarOpen] = useState(false);

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-blue-50 dark:from-gray-900 dark:via-gray-900 dark:to-blue-900/20">
      <Sidebar isOpen={sidebarOpen} onClose={() => setSidebarOpen(false)} />
      
      <div className="lg:ml-64">
        {/* Top bar for mobile */}
        <div className="lg:hidden fixed top-0 right-0 left-0 h-16 bg-white/80 dark:bg-gray-900/80 backdrop-blur-lg border-b border-blue-200 dark:border-gray-700 z-30 flex items-center justify-between px-4">
          <Button
            variant="ghost"
            size="icon"
            onClick={() => setSidebarOpen(true)}
            className="text-blue-600 dark:text-blue-400"
          >
            <Menu className="w-6 h-6" />
          </Button>
          <ThemeToggle />
        </div>

        {/* Main content */}
        <div className="pt-16 lg:pt-0">
          <div className="p-4 lg:p-8">
            <div className="hidden lg:flex justify-end mb-4">
              <ThemeToggle />
            </div>
            {children}
          </div>
        </div>
      </div>
    </div>
  );
};
