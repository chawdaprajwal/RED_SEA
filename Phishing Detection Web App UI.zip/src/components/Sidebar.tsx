import { Link, useLocation, useNavigate } from 'react-router-dom';
import { Home, BarChart3, BookOpen, Download, Info, LogOut, Zap, HeadphonesIcon, CreditCard } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { Button } from './ui/button';

interface SidebarProps {
  isOpen: boolean;
  onClose: () => void;
}

export const Sidebar = ({ isOpen, onClose }: SidebarProps) => {
  const location = useLocation();
  const navigate = useNavigate();
  const { user, logout } = useAuth();

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  const userLinks = [
    { name: 'Dashboard', path: '/dashboard-user', icon: Home },
    { name: 'Statistics', path: '/stats', icon: BarChart3 },
    { name: 'Instructions', path: '/instructions', icon: BookOpen },
    { name: 'Downloads', path: '/downloads', icon: Download },
    { name: 'Information', path: '/information', icon: Info },
    { name: 'Solutions', path: '/solutions', icon: CreditCard },
  ];

  const employeeLinks = [
    { name: 'Dashboard', path: '/dashboard-employee', icon: Home },
    { name: 'Statistics', path: '/stats', icon: BarChart3 },
    { name: 'Instructions', path: '/instructions', icon: BookOpen },
    { name: 'Downloads', path: '/downloads', icon: Download },
    { name: 'Information', path: '/information', icon: Info },
    { name: 'Simulation', path: '/simulation', icon: Zap },
    { name: 'Support', path: '/support', icon: HeadphonesIcon },
  ];

  const links = user?.role === 'employee' ? employeeLinks : userLinks;

  return (
    <>
      {/* Overlay for mobile */}
      {isOpen && (
        <div
          className="fixed inset-0 bg-black/50 backdrop-blur-sm z-40 lg:hidden"
          onClick={onClose}
        />
      )}

      {/* Sidebar */}
      <aside
        className={`fixed top-0 left-0 h-full w-64 bg-white/80 dark:bg-gray-900/80 backdrop-blur-lg border-r border-blue-200 dark:border-gray-700 z-50 transform transition-transform duration-300 ease-in-out ${
          isOpen ? 'translate-x-0' : '-translate-x-full'
        } lg:translate-x-0`}
      >
        <div className="flex flex-col h-full">
          {/* Logo/Header */}
          <div className="p-6 border-b border-blue-200 dark:border-gray-700">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-blue-500 to-blue-600 flex items-center justify-center">
                <span className="text-white">🛡️</span>
              </div>
              <div>
                <h2 className="text-blue-900 dark:text-white">PhishGuard</h2>
                <p className="text-xs text-blue-600 dark:text-blue-400">
                  {user?.role === 'employee' ? 'Enterprise' : 'Personal'}
                </p>
              </div>
            </div>
          </div>

          {/* Navigation Links */}
          <nav className="flex-1 p-4 overflow-y-auto">
            <ul className="space-y-2">
              {links.map((link) => {
                const Icon = link.icon;
                const isActive = location.pathname === link.path;
                return (
                  <li key={link.path}>
                    <Link
                      to={link.path}
                      onClick={onClose}
                      className={`flex items-center gap-3 px-4 py-3 rounded-lg transition-all ${
                        isActive
                          ? 'bg-blue-500 text-white shadow-lg shadow-blue-500/30'
                          : 'text-gray-700 dark:text-gray-300 hover:bg-blue-50 dark:hover:bg-gray-800'
                      }`}
                    >
                      <Icon className="w-5 h-5" />
                      <span>{link.name}</span>
                    </Link>
                  </li>
                );
              })}
            </ul>
          </nav>

          {/* User Info and Logout */}
          <div className="p-4 border-t border-blue-200 dark:border-gray-700">
            <div className="mb-3 p-3 rounded-lg bg-blue-50 dark:bg-gray-800">
              <p className="text-sm text-gray-700 dark:text-gray-300">{user?.name}</p>
              <p className="text-xs text-gray-500 dark:text-gray-400">{user?.email}</p>
            </div>
            <Button
              onClick={handleLogout}
              variant="outline"
              className="w-full justify-start gap-3 border-red-200 text-red-600 hover:bg-red-50 dark:border-red-800 dark:text-red-400 dark:hover:bg-red-900/20"
            >
              <LogOut className="w-5 h-5" />
              Logout
            </Button>
          </div>
        </div>
      </aside>
    </>
  );
};
