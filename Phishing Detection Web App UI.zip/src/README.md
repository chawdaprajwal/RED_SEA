# PhishGuard - Phishing Detection Web Application

A comprehensive, modern phishing detection platform with separate dashboards for users and enterprise employees. Built with React, TypeScript, and Tailwind CSS.

## 🌟 Features

### For Users
- **URL Phishing Detection** - Real-time scanning with AI-powered analysis
- **PDF Report Generation** - Download detailed scan reports
- **Statistics & Analytics** - Track your scanning history and protection metrics
- **Subscription Plans** - Choose from Basic, Pro, or Enterprise plans (INR pricing)
- **API Integration** - Integrate phishing detection into your applications
- **Multi-Platform Apps** - Desktop apps for Windows/macOS and Chrome extension

### For Enterprise Employees
- **Advanced Dashboard** - Organization-wide analytics and metrics
- **Phishing Simulations** - Run security awareness training campaigns
- **Enterprise Support** - 24/7 dedicated support with SLA guarantees
- **Team Management** - Manage users and track team performance
- **Custom Reporting** - Generate compliance and audit reports

### Global Features
- 🌓 **Dark/Light Theme** - Toggle between themes
- 📱 **Fully Responsive** - Works on mobile, tablet, and desktop
- 🎨 **Glassmorphism UI** - Modern, clean design with beautiful effects
- 🔐 **Secure Authentication** - Email/password and Google OAuth login
- 📧 **OTP Verification** - Email verification during signup
- 🔔 **Real-time Notifications** - Toast notifications for user actions

## 🚀 Getting Started

### Prerequisites
- Node.js 18+ installed
- npm or yarn package manager

### Installation

1. **Clone or download the project**

2. **Install dependencies**
```bash
npm install
```

3. **Start the development server**
```bash
npm run dev
```

4. **Open your browser**
Navigate to `http://localhost:5173` (or the port shown in your terminal)

## 📁 Project Structure

```
/
├── App.tsx                      # Main app with routing
├── context/
│   ├── AuthContext.tsx          # Authentication state management
│   └── ThemeContext.tsx         # Theme (dark/light) management
├── components/
│   ├── DashboardLayout.tsx      # Shared dashboard layout
│   ├── Sidebar.tsx              # Navigation sidebar
│   ├── ThemeToggle.tsx          # Dark/light mode toggle
│   └── ui/                      # Shadcn UI components
├── pages/
│   ├── Login.tsx                # Login page (personal & organization)
│   ├── SignupUser.tsx           # User registration
│   ├── SignupEmployee.tsx       # Enterprise employee registration
│   ├── DashboardUser.tsx        # User dashboard
│   ├── DashboardEmployee.tsx    # Employee dashboard
│   ├── Stats.tsx                # Statistics & analytics
│   ├── Instructions.tsx         # How to use guide
│   ├── Downloads.tsx            # App downloads page
│   ├── Information.tsx          # Security & compliance info
│   ├── Solutions.tsx            # Subscription plans (users)
│   ├── Simulation.tsx           # Phishing simulations (employees)
│   └── Support.tsx              # Support center (employees)
└── styles/
    └── globals.css              # Global styles
```

## 🎯 User Flows

### Personal User Flow
1. **Signup** → SignupUser page → OTP verification
2. **Login** → Personal login tab
3. **Dashboard** → Access URL scanner, stats, and quick actions
4. **Features** → Stats, Instructions, Downloads, Information, Solutions

### Enterprise Employee Flow
1. **Signup** → SignupEmployee page → Organization details → OTP verification
2. **Login** → Organization login tab
3. **Dashboard** → Enterprise metrics and tools
4. **Features** → Stats, Instructions, Downloads, Information, Simulation, Support

## 🔑 Key Features Explained

### URL Detection
- Enter any URL in the detection field
- Click "Detect Phishing" to scan
- View results with detailed threat analysis
- Generate PDF reports of scan results

### Subscription Plans (Users Only)
- **Basic** - ₹499/month - Individual protection
- **Pro** - ₹1,499/month - Small business (Most Popular)
- **Enterprise** - Custom pricing - Large organizations

### Phishing Simulation (Employees Only)
- Run security awareness campaigns
- Choose from Email Phishing, Link Detection, or Advanced Threats
- Track participant performance
- View leaderboards and analytics

### Theme Toggle
- Click the sun/moon icon in the top right
- Seamlessly switch between light and dark modes
- Preference saved to localStorage

## 🎨 Design System

- **Primary Color**: Blue (#3b82f6)
- **Success**: Green (#22c55e)
- **Warning**: Yellow/Orange
- **Danger**: Red (#ef4444)
- **Typography**: System fonts with responsive sizing
- **Effects**: Glassmorphism, smooth transitions, hover effects

## 🔐 Authentication (Mock)

Currently uses mock authentication for demo purposes:
- Any email/password combination works
- Google login simulated
- OTP verification mocked (displays OTP in toast)
- User role determined by login type

## 📊 Mock Data

The application includes realistic mock data for:
- Scan statistics and history
- Threat detection results
- User analytics
- Simulation results
- Support tickets
- Leaderboards

## 🛠️ Technologies Used

- **React 18** - UI framework
- **TypeScript** - Type safety
- **Tailwind CSS v4** - Styling
- **React Router** - Navigation
- **Recharts** - Charts and graphs
- **Lucide React** - Icons
- **Shadcn/ui** - UI components
- **jsPDF** - PDF generation
- **Sonner** - Toast notifications

## 📱 Responsive Breakpoints

- Mobile: < 768px
- Tablet: 768px - 1024px
- Desktop: > 1024px

## 🌐 Browser Support

- Chrome/Edge 90+
- Firefox 88+
- Safari 14+
- Opera 76+

## 🔮 Future Enhancements

- Real backend API integration
- Actual phishing detection algorithms
- User authentication with JWT
- Database integration (PostgreSQL/Supabase)
- Real-time websocket notifications
- Advanced reporting and exports
- Multi-language support
- Mobile native apps

## 📝 Notes

- All API calls are currently mocked with setTimeout
- OTP verification displays the code in a toast for testing
- PDF reports are generated client-side
- Theme preference persists in localStorage
- Responsive design tested on multiple devices

## 🤝 Support

For questions or issues:
- Email: support@phishguard.com (demo)
- Phone: +91 1800-123-4567 (demo)
- Documentation: Available in the app

## 📄 License

This is a demonstration project created for educational purposes.

---

**Built with ❤️ using React + Tailwind CSS**
