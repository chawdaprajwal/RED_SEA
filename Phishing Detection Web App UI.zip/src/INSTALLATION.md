# Installation & Setup Guide

## Quick Start

Follow these simple steps to get the PhishGuard application running on your machine.

### Step 1: Prerequisites

Make sure you have the following installed:
- **Node.js** version 18 or higher ([Download here](https://nodejs.org/))
- **npm** (comes with Node.js) or **yarn**

To check if you have Node.js installed, open your terminal/command prompt and run:
```bash
node --version
npm --version
```

### Step 2: Install Dependencies

Open your terminal in the project directory and run:

```bash
npm install
```

This will install all required packages including:
- React
- TypeScript
- Tailwind CSS
- React Router
- Recharts (for charts)
- Shadcn/ui components
- And more...

### Step 3: Start Development Server

Once installation is complete, start the development server:

```bash
npm run dev
```

You should see output similar to:
```
  VITE v5.x.x  ready in xxx ms

  ➜  Local:   http://localhost:5173/
  ➜  Network: use --host to expose
```

### Step 4: Open in Browser

Open your web browser and navigate to:
```
http://localhost:5173
```

You should see the PhishGuard login page!

## Testing the Application

### Login Options

**For Personal Users:**
1. Click "Personal Login" tab
2. Enter any email (e.g., `user@example.com`)
3. Enter any password (e.g., `password`)
4. Click "Login"
5. You'll be redirected to the User Dashboard

**For Organization Employees:**
1. Click "Organization Login" tab
2. Fill in organization details
3. Enter any email and password
4. Click "Login as Employee"
5. You'll be redirected to the Employee Dashboard

**Using Google Login:**
1. Click "Login with Google" button
2. This will simulate a Google login
3. You'll be automatically logged in as a user

### Signup Process

**User Signup:**
1. Go to `/signup-user`
2. Fill in your details
3. Click "Send OTP to Email"
4. The OTP will be shown in a notification (e.g., "123456")
5. Enter the OTP shown
6. Click "Verify & Create Account"

**Employee Signup:**
1. Go to `/signup-employee`
2. Fill in organization details
3. Select a department
4. Click "Send OTP to Business Email"
5. Enter the OTP shown in notification
6. Click "Verify & Create Account"

## Features to Try

### As a User:
- ✅ Scan URLs for phishing (try adding "phish" in URL to see it detected as dangerous)
- ✅ Generate PDF reports
- ✅ View statistics and charts
- ✅ Explore subscription plans (INR pricing)
- ✅ Check downloads page
- ✅ Toggle dark/light theme

### As an Employee:
- ✅ Access enterprise dashboard
- ✅ Run phishing simulations
- ✅ View team leaderboards
- ✅ Access enterprise support
- ✅ All user features plus more!

## Troubleshooting

### Port Already in Use
If port 5173 is already in use:
```bash
npm run dev -- --port 3000
```

### Dependencies Not Installing
Try clearing npm cache:
```bash
npm cache clean --force
npm install
```

### Build Errors
Make sure you're using Node.js 18+:
```bash
node --version
```

If using an older version, upgrade Node.js.

### Dark Mode Not Working
The theme preference is stored in localStorage. If it's not working:
1. Open browser DevTools (F12)
2. Go to Application/Storage → Local Storage
3. Clear the storage
4. Refresh the page

## Building for Production

To create a production build:

```bash
npm run build
```

This creates an optimized build in the `dist` folder.

To preview the production build:

```bash
npm run preview
```

## Project Structure Overview

```
src/
├── App.tsx                    # Main app component
├── context/                   # React contexts
│   ├── AuthContext.tsx        # User authentication
│   └── ThemeContext.tsx       # Theme management
├── components/                # Reusable components
│   ├── DashboardLayout.tsx    # Dashboard wrapper
│   ├── Sidebar.tsx            # Navigation sidebar
│   ├── ThemeToggle.tsx        # Theme switcher
│   └── ui/                    # Shadcn components
├── pages/                     # Page components
│   ├── Login.tsx
│   ├── DashboardUser.tsx
│   ├── DashboardEmployee.tsx
│   └── ... (other pages)
└── styles/
    └── globals.css            # Global styles
```

## Default Credentials (Mock)

Since this is a demo app with mock authentication:
- **Any email/password combination works**
- **Google login is simulated**
- **OTP is displayed in toast notifications**

Example credentials you can use:
- Email: `user@example.com`
- Password: `password123`

Or:
- Email: `employee@company.com`
- Password: `enterprise123`

## Next Steps

1. **Explore the UI** - Navigate through different pages
2. **Test Features** - Try URL scanning, simulations, etc.
3. **Toggle Theme** - Switch between light and dark modes
4. **Check Responsive** - Resize browser or use mobile view
5. **Generate Reports** - Try PDF generation feature

## Need Help?

- Check the README.md for detailed feature information
- Look at individual component files for implementation details
- All components are well-commented for clarity

## Happy Testing! 🎉

The application is now ready to use. Enjoy exploring the PhishGuard Phishing Detection Platform!
