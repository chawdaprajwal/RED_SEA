import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider, useAuth } from './context/AuthContext';
import { ThemeProvider } from './context/ThemeContext';
import { Toaster } from 'sonner@2.0.3';
import Login from './pages/Login';
import SignupUser from './pages/SignupUser';
import SignupEmployee from './pages/SignupEmployee';
import DashboardUser from './pages/DashboardUser';
import DashboardEmployee from './pages/DashboardEmployee';
import Stats from './pages/Stats';
import Instructions from './pages/Instructions';
import Downloads from './pages/Downloads';
import Information from './pages/Information';
import Solutions from './pages/Solutions';
import Simulation from './pages/Simulation';
import Support from './pages/Support';
import './styles/globals.css';

// Protected Route Component
function ProtectedRoute({ children, requiredRole }: { children: React.ReactNode; requiredRole?: string }) {
  const { user } = useAuth();
  
  if (!user) {
    return <Navigate to="/login" replace />;
  }
  
  if (requiredRole && user.role !== requiredRole) {
    return <Navigate to={user.role === 'employee' ? '/dashboard-employee' : '/dashboard-user'} replace />;
  }
  
  return <>{children}</>;
}

function App() {
  return (
    <ThemeProvider>
      <AuthProvider>
        <Router>
          <Toaster position="top-right" richColors />
          <Routes>
            <Route path="/login" element={<Login />} />
            <Route path="/signup-user" element={<SignupUser />} />
            <Route path="/signup-employee" element={<SignupEmployee />} />
            
            {/* User Routes */}
            <Route path="/dashboard-user" element={
              <ProtectedRoute requiredRole="user">
                <DashboardUser />
              </ProtectedRoute>
            } />
            <Route path="/solutions" element={
              <ProtectedRoute requiredRole="user">
                <Solutions />
              </ProtectedRoute>
            } />
            
            {/* Employee Routes */}
            <Route path="/dashboard-employee" element={
              <ProtectedRoute requiredRole="employee">
                <DashboardEmployee />
              </ProtectedRoute>
            } />
            <Route path="/simulation" element={
              <ProtectedRoute requiredRole="employee">
                <Simulation />
              </ProtectedRoute>
            } />
            <Route path="/support" element={
              <ProtectedRoute requiredRole="employee">
                <Support />
              </ProtectedRoute>
            } />
            
            {/* Shared Routes */}
            <Route path="/stats" element={
              <ProtectedRoute>
                <Stats />
              </ProtectedRoute>
            } />
            <Route path="/instructions" element={
              <ProtectedRoute>
                <Instructions />
              </ProtectedRoute>
            } />
            <Route path="/downloads" element={
              <ProtectedRoute>
                <Downloads />
              </ProtectedRoute>
            } />
            <Route path="/information" element={
              <ProtectedRoute>
                <Information />
              </ProtectedRoute>
            } />
            
            <Route path="/" element={<Navigate to="/login" replace />} />
          </Routes>
        </Router>
      </AuthProvider>
    </ThemeProvider>
  );
}

export default App;