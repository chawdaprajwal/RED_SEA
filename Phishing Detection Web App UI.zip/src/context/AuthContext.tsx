import React, { createContext, useContext, useState, ReactNode } from 'react';

interface User {
  id: string;
  name: string;
  email: string;
  role: 'user' | 'employee';
  organization?: string;
  employeeId?: string;
}

interface AuthContextType {
  user: User | null;
  login: (email: string, password: string, isOrganization?: boolean) => Promise<boolean>;
  loginWithGoogle: () => Promise<boolean>;
  signup: (data: any, role: 'user' | 'employee') => Promise<boolean>;
  logout: () => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within AuthProvider');
  }
  return context;
};

export const AuthProvider = ({ children }: { children: ReactNode }) => {
  const [user, setUser] = useState<User | null>(null);

  // Mock login function
  const login = async (email: string, password: string, isOrganization = false): Promise<boolean> => {
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    // Mock user data
    if (email && password) {
      const mockUser: User = {
        id: '1',
        name: isOrganization ? 'Employee User' : 'Regular User',
        email,
        role: isOrganization ? 'employee' : 'user',
        organization: isOrganization ? 'TechCorp Inc.' : undefined,
        employeeId: isOrganization ? 'EMP001' : undefined,
      };
      setUser(mockUser);
      return true;
    }
    return false;
  };

  // Mock Google login
  const loginWithGoogle = async (): Promise<boolean> => {
    await new Promise(resolve => setTimeout(resolve, 1000));
    const mockUser: User = {
      id: '2',
      name: 'Google User',
      email: 'user@gmail.com',
      role: 'user',
    };
    setUser(mockUser);
    return true;
  };

  // Mock signup function
  const signup = async (data: any, role: 'user' | 'employee'): Promise<boolean> => {
    await new Promise(resolve => setTimeout(resolve, 1500));
    
    const mockUser: User = {
      id: Math.random().toString(),
      name: data.name || data.organizationName,
      email: data.email,
      role,
      organization: role === 'employee' ? data.organizationName : undefined,
      employeeId: role === 'employee' ? data.employeeId : undefined,
    };
    setUser(mockUser);
    return true;
  };

  const logout = () => {
    setUser(null);
  };

  return (
    <AuthContext.Provider value={{ user, login, loginWithGoogle, signup, logout }}>
      {children}
    </AuthContext.Provider>
  );
};
