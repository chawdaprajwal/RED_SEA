# PhishGuard - Complete Usage Guide

## Table of Contents
1. [Getting Started](#getting-started)
2. [User Journey](#user-journey)
3. [Employee Journey](#employee-journey)
4. [Feature Details](#feature-details)
5. [Tips & Tricks](#tips--tricks)

---

## Getting Started

### First Time Setup
1. Open the application in your browser
2. You'll see the Login page
3. Choose whether you want a Personal or Organization account
4. Click "Sign up" to create an account

---

## User Journey

### 1. Creating a Personal Account

**Step 1: Navigate to Signup**
- From login page, click "Sign up"
- You'll be redirected to `/signup-user`

**Step 2: Fill Details**
- Enter your full name
- Enter email (Gmail preferred but any works)
- Create a strong password
- Confirm your password
- Watch the password strength indicator change

**Step 3: OTP Verification**
- Click "Send OTP to Email"
- A 6-digit OTP will be displayed in a notification
- Enter the OTP
- Click "Verify & Create Account"
- You're now logged in!

**Alternative: Google Signup**
- Click "Sign up with Google"
- Instant account creation (simulated)

### 2. User Dashboard Overview

Once logged in as a user, you'll see:

**Top Section:**
- Quick URL scanner
- Real-time phishing detection
- PDF report generation

**Stats Cards:**
- URLs Scanned: 127
- Threats Blocked: 23
- Protection Rate: 98.2%

**Quick Access Cards:**
- Statistics
- Instructions
- Downloads
- Information
- Solutions (Subscription)

### 3. Using URL Scanner

**To Scan a URL:**
1. Enter any URL in the input field
2. Click "Detect Phishing"
3. Wait 2 seconds for analysis
4. View result (Safe ✅ or Danger ❌)

**Testing Tips:**
- URLs with "phish", "scam", or "fake" → Detected as dangerous
- Regular URLs → Marked as safe
- Try: `https://phishing-site.com` (will be flagged)
- Try: `https://google.com` (will be safe)

**Generate PDF Report:**
1. After scanning, click "Generate PDF Report"
2. A PDF file will download automatically
3. Contains: URL, timestamp, verdict, details

### 4. Viewing Statistics

Navigate to **Statistics** page to see:
- Weekly scan activity (bar chart)
- Threat distribution (pie chart)
- 6-month trend analysis (line chart)
- Recent scan history
- Performance metrics

### 5. Subscription Plans

Navigate to **Solutions** page:

**Available Plans:**

**Basic - ₹499/month**
- 100 scans/day
- Basic detection
- Email support
- Browser extension

**Pro - ₹1,499/month** ⭐ Most Popular
- Unlimited scans
- Advanced AI detection
- 24/7 priority support
- API access
- Team collaboration (10 users)

**Enterprise - Custom Pricing**
- Everything in Pro
- Unlimited API
- Dedicated manager
- Custom deployment
- 99.99% SLA
- On-premise option

**Other Features:**
- Company contract requests
- API integration setup
- Contact support form

---

## Employee Journey

### 1. Creating an Enterprise Account

**Step 1: Navigate to Employee Signup**
- From login page, click "Sign up"
- Then go to `/signup-employee`

**Step 2: Fill Organization Details**
- Organization name
- Business email
- Select department (IT, HR, Finance, etc.)
- Phone number (optional)
- Create password

**Step 3: OTP Verification**
- Same process as user signup
- Receive OTP via business email

### 2. Employee Dashboard Overview

**Enterprise Stats:**
- Total Scans: 3,547
- Threats Blocked: 342
- Active Users: 156
- Uptime: 99.9%

**Enterprise Tools:**
- Statistics
- Instructions
- Downloads
- Information
- **Simulation** (Employee-only)
- **Support** (Employee-only)

### 3. Phishing Simulations

Navigate to **Simulation** page:

**Available Simulations:**

**Email Phishing (Medium)**
- Duration: 15 minutes
- 12 scenarios
- Tests email awareness

**Link Detection (Easy)**
- Duration: 10 minutes
- 8 scenarios
- URL identification practice

**Advanced Threats (Hard)**
- Duration: 25 minutes
- 15 scenarios
- Spear-phishing & social engineering

**Running a Simulation:**
1. Click "Start Simulation"
2. Wait for completion (3 seconds in demo)
3. View results:
   - Total participants
   - Pass/fail rates
   - Average score
   - Completion rate

**Leaderboard:**
- Top 5 performers
- By department
- Score rankings

### 4. Enterprise Support

Navigate to **Support** page:

**Contact Methods:**
- 24/7 Phone: +91 1800-123-4567
- Email: support@phishguard.com
- Live Chat: Mon-Fri, 9 AM - 6 PM IST

**Submit Ticket:**
1. Enter subject
2. Select priority (Low/Medium/High/Critical)
3. Describe issue
4. Click "Submit Ticket"
5. Receive ticket number

**View Recent Tickets:**
- Track ticket status
- See priority levels
- Monitor resolution progress

**FAQs:**
- Quick answers to common questions
- Expandable sections
- Self-service help

---

## Feature Details

### Theme Toggle
- Click sun/moon icon (top right)
- Switches between light and dark mode
- Preference saved automatically
- Works across all pages

### Navigation
- **Desktop:** Sidebar always visible
- **Mobile:** Hamburger menu (top left)
- Click any menu item to navigate
- Active page highlighted in blue

### Logout
- Click "Logout" at bottom of sidebar
- Returns to login page
- Session cleared

### Responsive Design
- **Mobile:** Single column layout
- **Tablet:** 2-column grid
- **Desktop:** 3-4 column grid
- All features accessible on all devices

---

## Tips & Tricks

### Testing Phishing Detection
```
Safe URLs:
- https://google.com
- https://example.com
- https://github.com

Dangerous URLs (will be flagged):
- https://phishing-site.com
- https://scam-alert.com
- https://fake-bank.com
```

### Password Strength
For strong password:
- At least 8 characters
- Mix of upper and lowercase
- Include numbers
- Add special characters
- Example: `MyP@ssw0rd123`

### Best Performance
- Use Chrome/Edge for best compatibility
- Enable JavaScript
- Allow cookies for theme preference
- Use desktop for full experience

### Data Persistence
- Theme preference: Saved in localStorage
- Login state: Session-based (cleared on logout)
- Mock data resets on page refresh

### Keyboard Shortcuts
- `Tab`: Navigate between form fields
- `Enter`: Submit forms
- `Esc`: Close modals (where applicable)

### Developer Mode
- Press `F12` to open DevTools
- Check console for any errors
- View network requests
- Inspect responsive design

---

## Common Questions

**Q: Why does any email/password work for login?**
A: This is a demo with mock authentication. In production, it would connect to a real backend.

**Q: Where is my data stored?**
A: All data is mock/simulated. Nothing is saved to a real database.

**Q: Can I integrate this with my real systems?**
A: The frontend is ready. You would need to build a backend API and connect it.

**Q: Why do I see the OTP in a notification?**
A: For demo purposes, we display the OTP so you can test without actual email.

**Q: How do I switch between user and employee views?**
A: Logout and login again using the appropriate login type.

**Q: Can I customize the theme colors?**
A: Yes! Edit `/styles/globals.css` to change color variables.

---

## Support & Resources

- **Documentation:** Available in `/instructions` page
- **Video Tutorials:** Coming soon
- **API Docs:** Check `/information` page
- **Knowledge Base:** In-app FAQs

---

## Next Steps

1. ✅ Create your account
2. ✅ Scan your first URL
3. ✅ Generate a PDF report
4. ✅ Explore all features
5. ✅ Try both user and employee dashboards
6. ✅ Test dark mode
7. ✅ Check responsive design on mobile

**Enjoy using PhishGuard! 🛡️**
