
  # Phishing Detection Web App UI

  This is a code bundle for Phishing Detection Web App UI. The original project is available at https://www.figma.com/design/Bzc3nw0OAbAZoKo1Vmpvus/Phishing-Detection-Web-App-UI.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  